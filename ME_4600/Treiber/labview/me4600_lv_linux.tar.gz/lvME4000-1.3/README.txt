lvME4000
--------
This package contains LabView VIs to access the Meilhaus ME-4000 API
under the GNU Linux OS.

Project Homepage: http://sourceforge.net/projects/meilhaus
(C) 2004 Guenter Gebhardt <g.gebhardt@meilhaus.de>


Features
--------
- function based interface to the ME-4000 API on Linux.

Requirements
------------
- LabView 6i or newer
- Meilhaus Linux shared object 2.0.0 with ME-4000 API or newer

References
----------
- National instruments: http://www.ni.com
- Meilhaus Electronic GmbH: http://www.meilhaus.com
