#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>
#include <linux/param.h>
#include <time.h>

#include "../me4000.h"

#define REPETITIONS 1000


int average(int fd, int repetitions, unsigned short range, unsigned short ending){
	int err;
	int i;
	int offset = 0;
	int max = -32768 - 1;
	int min = 32768;
	short *data;
	me4000_ai_config_t config;
	unsigned long entry;
	unsigned long timeout = 0;

	config.timer.pre_chan = 3300;
	config.timer.chan = 3300;
	config.timer.scan_low = 0;
	config.timer.scan_high = 0;

	entry = range | ending | ME4000_AI_LIST_LAST_ENTRY;
	config.channel_list.count = 1;
	config.channel_list.list = &entry;

	config.sh = 0;

	data = malloc(sizeof(short) * repetitions);
	if(!data){
		perror("average():Cannot allocate buffer for data\n");
		return 1;
	}

	err = ioctl(fd, ME4000_AI_CONFIG, &config);
	if(err){
		perror("Cannot configure device");
		return 1;
	}

	err = ioctl(fd, ME4000_AI_START, &timeout);
	if(err){
		perror("Cannot start conversion");
		return 1;
	}

	err = read(fd, data, sizeof(short) * repetitions);
	if(err != (sizeof(short) * repetitions)){
		perror("Cannot read from device");
		return 1;
	}

	err = ioctl(fd, ME4000_AI_IMMEDIATE_STOP);
	if(err){
		perror("Cannot stop conversion");
		return 1;
	}

	for(i = 0; i < repetitions; i++){
		if(data[i] > max) max = data[i];
		if(data[i] < min) min = data[i];

		offset += data[i];
	}

	printf("Minimum | Maximum [%d|%d]\n", min, max);
	printf("Average= %d\n", offset / i);

	return (offset /= i);

}



int main(void){
	int fd;
	int err = 0;
	char *path = "/dev/me4000_0_ai_cont_sw";
	me4000_eeprom_t eeprom;
	me4000_user_info_t info;
	struct tm *cd;
	time_t ct;

	printf("%c%3s", 27, "[2J");
	printf("<<<--- Application to calibrate a ME-4000 --->>>\n\n");

	printf("Open path %s\n", path);
	fd = open(path, O_RDWR, 0);
	if(fd < 0){
		perror("Cannot open path");
		return 1;
	}

	/*=========================================================================
	  Clear eeprom contents
	  =======================================================================*/

	memset(&eeprom, 0, sizeof(me4000_eeprom_t));

	printf("Clear eeprom contents\n");
	err = ioctl(fd, ME4000_AI_EEPROM_WRITE, &eeprom);
	if(err){
		perror("Cannot clear eeprom contents");
		return 1;
	}

	printf("Get Version of board\n");
	err = ioctl(fd, ME4000_GET_USER_INFO, &info);
	if(err){
		perror("Cannot get user info");
		return 1;
	}

	printf("Board Version = %X\n", info.device_id);


	/*=========================================================================
	  Offset adjustment
	  =======================================================================*/

	if(info.device_id != 0x4610){
		printf("Measure the offset in gain 1 unipolar single ended mode\n");
		printf("Please apply %fV to channel 0 and press ENTER\n", ME4000_AI_GAIN_1_UNI_OFFSET);
		getchar();

		eeprom.uni_10_offset = average(
				fd, 
				REPETITIONS, 
				ME4000_AI_LIST_RANGE_UNIPOLAR_10, 
				ME4000_AI_LIST_INPUT_SINGLE_ENDED);

		printf("Measure the offset in gain 4 unipolar single ended mode\n");
		printf("Please apply %fV to channel 0 and press ENTER\n", ME4000_AI_GAIN_4_UNI_OFFSET);
		getchar();

		eeprom.uni_2_5_offset = average(
				fd, 
				REPETITIONS, 
				ME4000_AI_LIST_RANGE_UNIPOLAR_2_5, 
				ME4000_AI_LIST_INPUT_SINGLE_ENDED);
	}

	printf("Measure the offset in gain 1 bipolar single ended mode\n");
	printf("Please apply %fV to channel 0 and press ENTER\n", ME4000_AI_GAIN_1_BI_OFFSET);
	getchar();

	eeprom.bi_10_offset = average(
			fd, 
			REPETITIONS, 
			ME4000_AI_LIST_RANGE_BIPOLAR_10, 
			ME4000_AI_LIST_INPUT_SINGLE_ENDED);

	if((info.device_id != 0x4650) && (info.device_id != 0x4610)){
		printf("Measure the offset in gain 1 bipolar differential mode\n");
		printf("Please apply %fV to channel 0 and press ENTER\n", ME4000_AI_GAIN_1_BI_OFFSET);
		getchar();

		eeprom.diff_10_offset = average(
				fd, 
				REPETITIONS, 
				ME4000_AI_LIST_RANGE_BIPOLAR_10, 
				ME4000_AI_LIST_INPUT_DIFFERENTIAL);
	}

	if(info.device_id != 0x4610){
		printf("Measure the offset in gain 4 bipolar single ended mode\n");
		printf("Please apply %fV to channel 0 and press ENTER\n", ME4000_AI_GAIN_4_BI_OFFSET);
		getchar();

		eeprom.bi_2_5_offset = average(
				fd, 
				REPETITIONS, 
				ME4000_AI_LIST_RANGE_BIPOLAR_2_5, 
				ME4000_AI_LIST_INPUT_SINGLE_ENDED);

		if(info.device_id != 0x4650){
			printf("Measure the offset in gain 4 bipolar differential mode\n");
			printf("Please apply %fV to channel 0 and press ENTER\n", ME4000_AI_GAIN_4_BI_OFFSET);
			getchar();

			eeprom.diff_2_5_offset = average(
					fd, 
					REPETITIONS, 
					ME4000_AI_LIST_RANGE_BIPOLAR_2_5, 
					ME4000_AI_LIST_INPUT_DIFFERENTIAL);
		}
	}


	/*=========================================================================
	  Full scale adjustment
	  =======================================================================*/

	if(info.device_id != 0x4610){
		printf("Measure the fullscale in gain 1 unipolar single ended mode\n");
		printf("Please apply %fV to channel 0 and press ENTER\n", ME4000_AI_GAIN_1_UNI_FULLSCALE);
		getchar();

		eeprom.uni_10_fullscale = average(
				fd, 
				REPETITIONS, 
				ME4000_AI_LIST_RANGE_UNIPOLAR_10, 
				ME4000_AI_LIST_INPUT_SINGLE_ENDED);
	}

	printf("Measure the fullscale in gain 1 bipolar single ended mode\n");
	printf("Please apply %fV to channel 0 and press ENTER\n", ME4000_AI_GAIN_1_BI_FULLSCALE);
	getchar();

	eeprom.bi_10_fullscale = average(
			fd, 
			REPETITIONS, 
			ME4000_AI_LIST_RANGE_BIPOLAR_10, 
			ME4000_AI_LIST_INPUT_SINGLE_ENDED);

	if((info.device_id != 0x4650) && (info.device_id != 0x4610)){
		printf("Measure the fullscale in gain 1 bipolar differential mode\n");
		printf("Please apply %fV to channel 0 and press ENTER\n", ME4000_AI_GAIN_1_BI_FULLSCALE);
		getchar();

		eeprom.diff_10_fullscale = average(
				fd, 
				REPETITIONS, 
				ME4000_AI_LIST_RANGE_BIPOLAR_10, 
				ME4000_AI_LIST_INPUT_DIFFERENTIAL);
	}

	if(info.device_id != 0x4610){
		printf("Measure the fullscale in gain 4 unipolar single ended mode\n");
		printf("Please apply %fV to channel 0 and press ENTER\n", ME4000_AI_GAIN_4_UNI_FULLSCALE);
		getchar();

		eeprom.uni_2_5_fullscale = average(
				fd, 
				REPETITIONS, 
				ME4000_AI_LIST_RANGE_UNIPOLAR_2_5, 
				ME4000_AI_LIST_INPUT_SINGLE_ENDED);

		printf("Measure the fullscale in gain 4 bipolar single ended mode\n");
		printf("Please apply %fV to channel 0 and press ENTER\n", ME4000_AI_GAIN_4_BI_FULLSCALE);
		getchar();

		eeprom.bi_2_5_fullscale = average(
				fd, 
				REPETITIONS, 
				ME4000_AI_LIST_RANGE_BIPOLAR_2_5, 
				ME4000_AI_LIST_INPUT_SINGLE_ENDED);

		if(info.device_id != 0x4650){
			printf("Measure the fullscale in gain 4 bipolar differential mode\n");
			printf("Please apply %fV to channel 0 and press ENTER\n", ME4000_AI_GAIN_4_BI_FULLSCALE);
			getchar();

			eeprom.diff_2_5_fullscale = average(
					fd, 
					REPETITIONS, 
					ME4000_AI_LIST_RANGE_BIPOLAR_2_5, 
					ME4000_AI_LIST_INPUT_DIFFERENTIAL);
		}
	}

	/* Calculate date for eeprom */
	ct = time(NULL);

	cd = gmtime(&ct);
	if(!cd){
		perror("Cannot get current time");
		return 1;
	}
	eeprom.date = cd->tm_mon;
	eeprom.date <<= 16;
	eeprom.date += cd->tm_year + 1900;

	printf("\nMeasurement results:\n");
	printf("--------------------\n");
	printf("Date                        = 0x%lX\n", eeprom.date);
	printf("Unipolar 10V offset         = %d\n", eeprom.uni_10_offset);
	printf("Unipolar 10V fullscale      = %d\n", eeprom.uni_10_fullscale);
	printf("Unipolar 2,5V offset        = %d\n", eeprom.uni_2_5_offset);
	printf("Unipolar 2,5V fullscale     = %d\n", eeprom.uni_2_5_fullscale);
	printf("Bipolar 10V offset          = %d\n", eeprom.bi_10_offset);
	printf("Bipolar 10V fullscale       = %d\n", eeprom.bi_10_fullscale);
	printf("Bipolar 2,5V offset         = %d\n", eeprom.bi_2_5_offset);
	printf("Bipolar 2,5V fullscale      = %d\n", eeprom.bi_2_5_fullscale);
	printf("Differential 10V offset     = %d\n", eeprom.diff_10_offset);
	printf("Differential 10V fullscale  = %d\n", eeprom.diff_10_fullscale);
	printf("Differential 2,5V offset    = %d\n", eeprom.diff_2_5_offset);
	printf("Differential 2,5V fullscale = %d\n", eeprom.diff_2_5_fullscale);

	printf("Write results to EEPROM\n");
	err = ioctl(fd, ME4000_AI_EEPROM_WRITE, &eeprom);
	if(err){
		perror("Cannot write eeprom contents");
		return 1;
	}

	memset(&eeprom, 0, sizeof(me4000_eeprom_t));

	printf("\nRead back eeprom contents\n");
	err = ioctl(fd, ME4000_AI_EEPROM_READ, &eeprom);
	if(err){
		perror("Cannot read eeprom");
		return 1;
	}

	printf("Measurement results in EEPROM:\n");
	printf("-----------------------------\n");
	printf("Date                        = 0x%lX\n", eeprom.date);
	printf("Unipolar 10V offset         = %d\n", eeprom.uni_10_offset);
	printf("Unipolar 10V fullscale      = %d\n", eeprom.uni_10_fullscale);
	printf("Unipolar 2,5V offset        = %d\n", eeprom.uni_2_5_offset);
	printf("Unipolar 2,5V fullscale     = %d\n", eeprom.uni_2_5_fullscale);
	printf("Bipolar 10V offset          = %d\n", eeprom.bi_10_offset);
	printf("Bipolar 10V fullscale       = %d\n", eeprom.bi_10_fullscale);
	printf("Bipolar 2,5V offset         = %d\n", eeprom.bi_2_5_offset);
	printf("Bipolar 2,5V fullscale      = %d\n", eeprom.bi_2_5_fullscale);
	printf("Differential 10V offset     = %d\n", eeprom.diff_10_offset);
	printf("Differential 10V fullscale  = %d\n", eeprom.diff_10_fullscale);
	printf("Differential 2,5V offset    = %d\n", eeprom.diff_2_5_offset);
	printf("Differential 2,5V fullscale = %d\n", eeprom.diff_2_5_fullscale);


	/*-------------------------------- END ------------------------------*/

	/* Try to close all possible pathes */
	printf("Close path %s ...\n", path);
	if(close(fd)) perror("Cannot close path");

	printf("End of Testprogram\n");

	return 0;
}
