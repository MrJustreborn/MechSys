#!/bin/bash
#
# This script is responsible for deinstalling a meilhaus driver
#


if [ -z ${NAME} ] ; then
    echo "No script name for deinstallation defined."
    exit 1
fi

# Only root can deinstall the driver
if [ $(whoami) != root ] ; then
    echo "You must be root to deinstall the device driver."
    exit 1
fi

################################
# Actually do the deinstallation
#

echo "Removing header files from /usr/include."
rm -f /usr/include/${NAME}.h
rm -f /usr/include/lib${NAME}.h
rm -f /usr/include/lib${NAME}net.h

# Remove the server stuff
if [ -x /usr/sbin/rc${NAME}_srv ] ; then
    rc${NAME}_srv stop
    /sbin/insserv -r ${NAME}_srv
    rm -f /usr/sbin/rc${NAME}_srv
    rm -f /etc/init.d/${NAME}_srv
    rm -f /usr/sbin/${NAME}_srv
fi

# Remove the lookup server stuff
if [ -x /usr/sbin/rc${NAME}_lookup_srv ] ; then
    rc${NAME}_lookup_srv stop
    /sbin/insserv -r ${NAME}_lookup_srv
    rm -f /usr/sbin/rc${NAME}_lookup_srv
    rm -f /etc/init.d/${NAME}_lookup_srv
    rm -f /usr/sbin/${NAME}_lookup_srv
fi

# Remove the standard library links
if ls /usr/lib/lib${NAME}.so* &> /dev/null ; then
    echo "Removing symbolic links to standard library in /usr/lib."
    rm -f /usr/lib/lib${NAME}.so*
    echo "Run ldconfig on /usr/lib."
    /sbin/ldconfig /usr/lib
fi


# Remove the network library links
if ls /usr/lib/lib${NAME}net.so* &> /dev/null ; then
    echo "Removing symbolic links to network library in /usr/lib."
    rm -f /usr/lib/lib${NAME}net.so*
    echo "Run ldconfig on /usr/lib."
    /sbin/ldconfig /usr/lib
fi


# Remove the driver module stuff
if [ -x /usr/sbin/rc${NAME} ] ; then
    rc${NAME} stop
    /sbin/insserv -r ${NAME}
    rm -f /usr/sbin/rc${NAME}
    rm -f /etc/init.d/${NAME}
    echo "Removing driver objects in /lib/modules."
    find /lib/modules -name ${NAME}.o -exec rm {} \;
    find /lib/modules -name ${NAME}.ko -exec rm {} \;
    echo "Call depmod in order to update module dependencies."
    /sbin/depmod -a
fi
