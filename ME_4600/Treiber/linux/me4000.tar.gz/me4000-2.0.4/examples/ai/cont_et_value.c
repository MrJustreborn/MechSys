#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <string.h>
#include <stdlib.h>
#include <linux/param.h>

#include "../../me4000.h"


#define LIST_SIZE 4
#define BUFFER_SIZE (1 * 1024)
#define BUFFER_COUNT (BUFFER_SIZE / 2)
#define TIME_OUT (0*HZ)



int main(void){
  me4000_ai_config_t config;
  int fd;
  FILE *file;
  int err;
  int i;
  unsigned short *values;
  me4000_ai_trigger_t trigger;
  unsigned long timeout = TIME_OUT;


  printf("%c%3s", 27, "[2J");
  printf("<<<--- EXAMPLE FOR AI CONTINUOUS EXTERNAL TRIGGER ONE VALUE MODE --->>>\n\n");

  printf("Open path /dev/me4000_0_ai_cont_et_value\n");
  fd = open("/dev/me4000_0_ai_cont_et_value", O_RDWR, 0);
  if(fd < 0){
    perror("Cannot open path");
    return 1;
  }

  /* Prepare channel list */
  config.channel_list.count = LIST_SIZE;
  config.channel_list.list = malloc(sizeof(unsigned int) * config.channel_list.count);
  for(i = 0; i < config.channel_list.count; i++){
    config.channel_list.list[i] = ME4000_AI_LIST_INPUT_SINGLE_ENDED | ME4000_AI_LIST_RANGE_BIPOLAR_10 | i;
  }
  config.channel_list.list[config.channel_list.count - 1] |= ME4000_AI_LIST_LAST_ENTRY;

  /* Set timer */
  config.timer.chan = 66;
  config.timer.pre_chan = 66;
  config.timer.scan_low = 0;
  config.timer.scan_high = 0;

  /* Set sample and hold */
  config.sh = 0;

  err = ioctl(fd, ME4000_AI_CONFIG, &config);
  if(err){
    perror("Can't configure board");
    return 1;
  }

  printf("Setup external trigger\n");
  trigger.mode = ME4000_AI_TRIGGER_EXT_DIGITAL;
  trigger.edge = ME4000_AI_TRIGGER_EXT_EDGE_RISING;

  err = ioctl(fd, ME4000_AI_EX_TRIG_SETUP, &trigger);
  if(err){
    perror("Can't setup trigger");
    return 1;
  }

  printf("Enable external trigger\n");
  err = ioctl(fd, ME4000_AI_EX_TRIG_ENABLE);
  if(err){
    perror("Can't enable external trigger");
    return 1;
  }

  printf("Start conversion\n");
  err = ioctl(fd, ME4000_AI_START, &timeout);
  if(err){
    perror("Can't start conversation");
    return 1;
  }
  printf("Conversion started\n");

  values = malloc(BUFFER_SIZE);
  memset(values, 0, BUFFER_SIZE);

  err = read(fd, values, BUFFER_SIZE);
  if(err != BUFFER_SIZE){
    perror("Can't read all values");
    return 1;
  }
  printf("Read %d bytes\n", err);


  printf("Stop conversion immediately\n");
  err = ioctl(fd, ME4000_AI_IMMEDIATE_STOP);
  if(err){
    perror("Can't stop conversation");
    return 1;
  }


  file = fopen("./data.txt", "w");
  if(file == NULL){
    perror("Cannot open data.txt");
    return 1;
  }

  for(i = 0; i < BUFFER_COUNT; i++){
    fprintf(file, "Value %d = 0x%04X\n", i, values[i]);
  }

  /*-------------------------------- END ------------------------------*/

  printf("Close path /dev/me4000_ai_0_one_sample_ex\n");
  if(close(fd)) perror("Cannot close path");

  printf("End of Testprogram\n");

  return 0;
}
