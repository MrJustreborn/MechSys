#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <string.h>
#include <stdlib.h>

#include "../../me4000.h"

/* 
 * Configuration section starts here 
 */

#define ME4000_PATH "/dev/me4000_0_ai_cont_sw"

#define BUFFER_COUNT (16)
#define BUFFER_SIZE ((BUFFER_COUNT) * sizeof(short))
#define LIST_SIZE 2

#define CHANNEL_DIVISOR 330
#define CHANNEL_PRE_DIVISOR 66
#define SCAN_DIVISOR_LOW 0
#define SCAN_DIVISOR_HIGH 0

#define SAMPLE_AND_HOLD 0

#define SCALE ME4000_AI_LIST_RANGE_BIPOLAR_10
#define ENDING ME4000_AI_LIST_INPUT_SINGLE_ENDED



int calc_point(
	unsigned int chan_divisor, 
	unsigned int scan_divisor_low, 
	unsigned int scan_divisor_high, 
	unsigned int list_size,
	unsigned int count, 
	int scale, 
	short data, 
	double *time, 
	double *volts) {
    unsigned long long scan_divisor;
    double t1, t2;
    double f = 33E6;

    scan_divisor = scan_divisor_low + ((unsigned long long) scan_divisor_high << 32);

    /* calculate time offset */
    if(scan_divisor){
	t1 = chan_divisor / f * (count % list_size);
	t2 = scan_divisor / f * (count / list_size);
	*time = t1 + t2;
    }
    else{
	t1 = chan_divisor / f * count;
	*time = t1;
    }

    /* calculate voltage */
    switch(scale){
	case ME4000_AI_LIST_RANGE_BIPOLAR_10:
	    *volts = 10.0 / 32768.0 * data;
	    break;
	case ME4000_AI_LIST_RANGE_BIPOLAR_2_5:
	    *volts = 2.5 / 32768.0 * data;
	    break;
	case ME4000_AI_LIST_RANGE_UNIPOLAR_10:
	    *volts = 10.0 / 65536.0 * data + 5.0;
	    break;
	case ME4000_AI_LIST_RANGE_UNIPOLAR_2_5:
	    *volts = 2.5 / 65536.0 * data + 1.25;
	    break;
	default:
	    return 1;
    }

    return 0;
}



int main(void){
    me4000_ai_config_t config;
    int fd;
    FILE *file;
    int err;
    int i;
    short *values;

    printf("%c%3s", 27, "[2J");
    printf("<<<--- EXAMPLE FOR AI CONTINUOUS SOFTWARE TRIGGER --->>>\n\n");

    printf("Open path "ME4000_PATH" ...\n\n");
    fd = open(""ME4000_PATH"", O_RDWR, 0);
    if(fd < 0){
	perror("Cannot open path");
	return 1;
    }

    /* Prepare channel list */
    config.channel_list.count = LIST_SIZE;
    config.channel_list.list = malloc(sizeof(unsigned int) * config.channel_list.count);
    for(i = 0; i < config.channel_list.count; i++){
	config.channel_list.list[i] = ENDING | SCALE | i;
    }
    config.channel_list.list[config.channel_list.count - 1] |= ME4000_AI_LIST_LAST_ENTRY;

    printf("Channel list size = %d\n\n", LIST_SIZE);

    /* Set timer */
    config.timer.chan = CHANNEL_DIVISOR;
    config.timer.pre_chan = CHANNEL_PRE_DIVISOR;
    config.timer.scan_low = SCAN_DIVISOR_LOW;
    config.timer.scan_high = SCAN_DIVISOR_HIGH;

    printf("Timer setup:\n");
    printf("Channel timer divisor    = %d\n", CHANNEL_DIVISOR);
    printf("Channel pretimer divisor = %d\n", CHANNEL_PRE_DIVISOR);
    printf("Scan timer low divisor   = %d\n", SCAN_DIVISOR_LOW);
    printf("Scan timer high divisor  = %d\n\n", SCAN_DIVISOR_HIGH);

    /* Setup sample and hold */
    config.sh = SAMPLE_AND_HOLD;
    printf("Sample and Hold = %d\n\n", SAMPLE_AND_HOLD);

    err = ioctl(fd, ME4000_AI_CONFIG, &config);
    if(err){
	perror("Can't configure board");
	return 1;
    }

    printf("Start conversion\n");
    err = ioctl(fd, ME4000_AI_START);
    if(err){
	perror("Can't start conversation");
	return 1;
    }

    values = malloc(BUFFER_SIZE);
    memset(values, 0, BUFFER_SIZE);

    err = read(fd, values, BUFFER_SIZE);
    if(err != BUFFER_SIZE){
	perror("Can't read all values");
	return 1;
    }
    printf("%d bytes read\n", err);


    printf("Stop conversion for "ME4000_PATH"\n");
    err = ioctl(fd, ME4000_AI_IMMEDIATE_STOP);
    if(err){
	perror("Can't stop conversion");
	return 1;
    }


    file = fopen("./data.txt", "w");
    if(file == NULL){
	perror("Cannot open data.txt");
	return 1;
    }


    for(i = 0; i < BUFFER_COUNT; i++){
	double t, v;
	if(calc_point(CHANNEL_DIVISOR, SCAN_DIVISOR_LOW, SCAN_DIVISOR_HIGH, LIST_SIZE, i, SCALE, values[i], &t, &v)){
	    printf("Error while calc_point\n");
	    return 1;
	}

	fprintf(file, "Time: %e Voltage: %e No: %d Data: %d\n", t, v, i, values[i]);
    }

    /*-------------------------------- END ------------------------------*/

    /* Try to close all possible pathes */
    printf("Close path\n");
    if(close(fd)) perror("Cannot close path");

    printf("End of Testprogram\n");

    return 0;
}
