#define _POSIX_SOURCE
#define _POSIX_C_SOURCE 200112

#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <string.h>
#include <stdlib.h>
#include <aio.h>

#include "../../me4000.h"

#ifndef _POSIX_VERSION
#error (Posix not supported)
#endif

#ifndef _POSIX_ASYNCHRONOUS_IO
#error (Posix Asynchronous I/O is not supported)
#endif

#ifndef _POSIX_REALTIME_SIGNALS
#error (Posix realtime signals are not supported)
#endif

#define BUFFER_COUNT (16 * 1024)
#define BUFFER_SIZE ((BUFFER_COUNT) * sizeof(short))
#define LIST_SIZE 4

#define CHANNEL_DIVISOR 3300
#define CHANNEL_PRE_DIVISOR 66
#define SCAN_DIVISOR_LOW 0
#define SCAN_DIVISOR_HIGH 0

#define SAMPLE_AND_HOLD 0

#define RANGE ME4000_AI_LIST_RANGE_BIPOLAR_10
#define ENDING ME4000_AI_LIST_INPUT_SINGLE_ENDED

int done;


int calc_point(
    unsigned int chan_divisor, 
    unsigned int scan_divisor_low, 
    unsigned int scan_divisor_high, 
    unsigned int list_size,
    unsigned int count, 
    int scale, 
    short data, 
    double *time, 
    double *volts) {
  unsigned long long scan_divisor;
  double t1, t2;
  double f = 33E6;

  scan_divisor = scan_divisor_low + ((unsigned long long) scan_divisor_high << 32);
  /* calculate time offset */
  if(scan_divisor){
    t1 = chan_divisor / f * (count % list_size);
    t2 = scan_divisor / f * (count / list_size);
    *time = t1 + t2;
  }
  else{
    t1 = chan_divisor / f * count;
    *time = t1;
  }

  /* calculate voltage */
  switch(scale){
    case ME4000_AI_LIST_RANGE_BIPOLAR_10:
      *volts = 20.0 / 65536.0 * data;
      break;
    case ME4000_AI_LIST_RANGE_BIPOLAR_2_5:
      *volts = 5.0 / 65536.0 * data;
      break;
    case ME4000_AI_LIST_RANGE_UNIPOLAR_10:
      *volts = 10.0 / 65536.0 * data + 5.0;
      break;
    case ME4000_AI_LIST_RANGE_UNIPOLAR_2_5:
      *volts = 2.5 / 65536.0 * data + 1.25;
      break;
    default:
      return 1;
  }

  return 0;
}



void io_complete_handler(int signo, siginfo_t *info, void *ignored){
  int err;
  struct aiocb *ai;
  FILE *file;
  unsigned int count;
  short *values;
  int i;

  ai = info->si_value.sival_ptr;

  count = ai->aio_nbytes / 2;
  values = (short *) ai->aio_buf;

  printf("Asynchronous I/O completed\n");

  /* Check for error */
  if(aio_error(ai)){
    perror("Unexpected error after asynchronous read");
    return;
  }

  printf("Return value of asynchronous read is %d\n", aio_return(ai));

  err = ioctl(ai->aio_fildes, ME4000_AI_IMMEDIATE_STOP);
  if(err){
    perror("Can't stop conversion");
    return;
  }

  file = fopen("./data.txt", "w");
  if(file == NULL){
    perror("Cannot open cont_sw.dat");
    return;
  }

  for(i = 0; i < BUFFER_COUNT; i++){
    double t, v;
    if(calc_point(CHANNEL_DIVISOR, SCAN_DIVISOR_LOW, SCAN_DIVISOR_HIGH, LIST_SIZE, i, RANGE, values[i], &t, &v)){
      printf("Error while calc_point\n");
    }

    fprintf(file, "Time: %e Voltage: %e No: %d Data: %d\n", t, v, i, values[i]);
  }
  done = 1;
}


int main(void){
  me4000_ai_config_t config;
  int fd;
  int err;
  int i;
  unsigned short *values;
  struct aiocb ai;
  struct sigaction sa;
  sigset_t nmask, omask;


  printf("%c%3s", 27, "[2J");
  printf("<<<--- EXAMPLE FOR AI CONTINUOUS SOFTWARE TRIGGER MODE --->>>\n\n");

  printf("Open path /dev/me4000_0_ai_cont_sw\n");
  fd = open("/dev/me4000_0_ai_cont_sw", O_RDWR, 0);
  if(fd < 0){
    perror("Cannot open path");
    return 1;
  }

  /* Setup signal handler */
  sa.sa_handler = NULL;
  sa.sa_sigaction = io_complete_handler;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = SA_SIGINFO;
  if(sigaction(SIGRTMAX, &sa, NULL)){
    perror("sigaction");
    exit(1);
  }

  /* Block delivery until sigsuspend is reached */
  sigemptyset(&nmask);
  sigaddset(&nmask, SIGRTMAX);
  sigprocmask(SIG_BLOCK, &nmask, &omask);

  /* Prepare channel list */
  config.channel_list.count = LIST_SIZE;
  config.channel_list.list = malloc(sizeof(unsigned int) * config.channel_list.count);
  for(i = 0; i < config.channel_list.count; i++){
    config.channel_list.list[i] = ENDING | RANGE | i;
  }
  config.channel_list.list[config.channel_list.count - 1] |= ME4000_AI_LIST_LAST_ENTRY;

  /* Set timer */
  config.timer.chan = CHANNEL_DIVISOR;
  config.timer.pre_chan = CHANNEL_PRE_DIVISOR;
  config.timer.scan_low = SCAN_DIVISOR_LOW;
  config.timer.scan_high = SCAN_DIVISOR_HIGH;

  /* Setup sample and hold */
  config.sh = SAMPLE_AND_HOLD;

  err = ioctl(fd, ME4000_AI_CONFIG, &config);
  if(err){
    perror("Can't configure board");
    return 1;
  }

  printf("Start conversion\n");
  err = ioctl(fd, ME4000_AI_START);
  if(err){
    perror("Can't start conversation");
    return 1;
  }

  values = malloc(BUFFER_SIZE);
  memset(values, 0, BUFFER_SIZE);

  ai.aio_fildes = fd;
  ai.aio_offset = 0;
  ai.aio_buf = values;
  ai.aio_nbytes = BUFFER_SIZE;
  ai.aio_lio_opcode = 0;
  ai.aio_reqprio = 0;

  ai.aio_sigevent.sigev_notify = SIGEV_SIGNAL;
  ai.aio_sigevent.sigev_value.sival_ptr = &ai;
  ai.aio_sigevent.sigev_signo = SIGRTMAX;

  printf("Read %d bytes asynchronous\n", BUFFER_SIZE);
  err = aio_read(&ai);
  if(err){
    perror("Can't init asynchronous read\n");
    return 1;
  }

  while(!done){
    sigsuspend(&omask);
  }

  printf("Signal handler terminated\n");

  /*-------------------------------- END ------------------------------*/

  /* Try to close all possible pathes */
  printf("Close path /dev/me4000_ai_0_cont_sw\n");
  if(close(fd)) perror("Cannot close path");

  printf("End of Testprogram\n");

  return 0;
}
