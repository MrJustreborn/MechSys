#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>
#include <linux/param.h>
#include <time.h>

#include "../../../me4000.h"

#undef EX_TRIG



int main(void){
    me4000_ai_single_t cmd;
    double voltage;
    int fd;
    int err;
    char *path = "/dev/me4000_0_ai_single";

    printf("%c%3s", 27, "[2J");
    printf("<<<--- EXAMPLE FOR AI SINGLE MODE --->>>\n\n");

    printf("Open path %s\n", path);
    fd = open(path, O_RDWR, 0);
    if(fd < 0){
	perror("Cannot open path");
	return 1;
    }

    cmd.mode = ME4000_AI_LIST_INPUT_DIFFERENTIAL;
    cmd.range = ME4000_AI_LIST_RANGE_BIPOLAR_10;
    cmd.timeout = 5 * HZ; // Used anly when external trigger is enabled

#ifdef EX_TRIG
    err = ioctl(fd, ME4000_AI_EX_TRIG_ENABLE);
    if(err){
	perror("Cannot enable external trigger");
	return 1;
    }
#endif

    cmd.channel = 0;

    err = ioctl(fd, ME4000_AI_SINGLE, &cmd);
    if(err){
	perror("Cannot read single value");
	return 1;
    }

    voltage = 10.0 / 32768.0 * cmd.value;
    printf("Channel %d: Digits = %d, Voltage = %f V\n", cmd.channel, cmd.value, voltage);

    /*-------------------------------- END ------------------------------*/

    /* Try to close all possible pathes */
    printf("Close path %s\n", path);
    if(close(fd)) perror("Cannot close path");

    printf("End of Testprogram\n");

    return 0;
}
