#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>
#include <stdlib.h>
#include <linux/param.h>

/* 
 * This must be included in order
 * to have access to the ME-4000
 * specific definitions
 */
#include "../../me4000.h"

/* 
 * Opens on the first board
 * the first analog output 
 * in continuous mode
 */
#define PATH "/dev/me4000_0_ao_0_cont"

/*
 * If this is defined, fsync() is
 * called after the last write. fsync()
 * will block until the last value is converted.
 * In addition -EPIPE (Broken Pipe) is returned if the
 * conversion flow was interrupted.
 */
#define SYNCHRONIZE

/*
 * Instead of the call to fsync() you can specify the
 * O_SYNC flag in the open() system call.
 */
#ifndef SYNCHRONIZE
#  define MY_SYNC O_SYNC
#else
#  define MY_SYNC 0
#endif

/* 
 * Divisor for the 
 * internal 33MHz sample clock 
 */
#define TICKS 330

/*
 * Here you can specify the
 * size of the buffer to be written
 * to the analog outputs
 */
#define BUFFER_COUNT (128 * 1024)

#define TIME_OUT (0*HZ)


int main(void){
  unsigned short *values;
  int err;
  int m, i;
  unsigned int divisor = TICKS;
  int flags;
  unsigned long timeout = TIME_OUT;

  int fd;

  printf("%c%3s", 27, "[2J");
  printf("<<<--- EXAMPLE FOR AO CONTINUOUS MODE --->>>\n\n");

  /* Open the device */
  printf("Open path %s\n", PATH);
  fd = open(PATH, O_RDWR | MY_SYNC, 0);
  if(fd < 0){
    perror("Cannot open path");
    return 1;
  }

  /* Prepare values to write */
  values = (unsigned short *) malloc(2 * BUFFER_COUNT);
  memset(values, 0, 2 * BUFFER_COUNT);
  for (i = 0; i < BUFFER_COUNT; i += 2){
    *(values + i) = 0xFFFF;
  }

  /* Prepare timer */
  printf("Set timer divisor for %s to %d\n", PATH, divisor);
  err = ioctl(fd, ME4000_AO_TIMER_SET_DIVISOR, &divisor);
  if(err){
    perror("Cannot set divisor");
    return 1;
  }

  /* Preload the FIFO */
  printf("Try to preload %d values to %s\n", BUFFER_COUNT, PATH);
  m = write(fd, values, 2 * BUFFER_COUNT);
  if(m < 0){
    perror("Cannot preload");
    return 1;
  }
  printf("%d values preloaded to %s\n", m/2, PATH);

  /* Get the flags of the file */
  flags = fcntl(fd, F_GETFL, 0);

  /* Set O_APPEND in order to do normal writes */
  flags |= O_APPEND;
  fcntl(fd, F_SETFL, flags);
      
  /* After we have preloaded the analog output we are able to start it */
  printf("Start conversion for %s\n", PATH);
  err = ioctl(fd, ME4000_AO_START, &timeout);
  if(err){ 
    perror("Can't start conversion\n");
    return 1;
  }

  /* Do normal writes */
  printf("Try to write %d values to %s\n", BUFFER_COUNT - m/2, PATH);
  m = write(fd, values + m/2, 2 * BUFFER_COUNT - m);
  if(m < 0){
    perror("Cannot write to path");
    return 1;
  }
  printf("Wrote %d values to %s\n", m / 2, PATH);

#ifdef SYNCHRONIZE
  /* 
   * This function block until all values were converted.
   * In addition it check whether the conversion flow was interrupted
   */
  printf("Synchronize with %s\n", PATH);
  err = fsync(fd);
  if(err < 0){
    perror("Can't synchronize\n");
    return 1;
  }
#endif

  /* Close the path */
  printf("Close path %s\n", PATH);
  err = close(fd);
  if(err){
    perror("Cannot close path");
    return 1;
  }

  printf("Type return to terminate the program\n");
  getchar();


  /*-------------------------------- END ------------------------------*/

  printf("End of program\n");

  return 0;
}

