#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <string.h>
#include <linux/param.h>

/* 
 * This must be included in order
 * to have access to the ME-4000
 * specific definitions
 */
#include "../../me4000.h"

/* 
 * Divisor for the 
 * internal 33MHz sample clock 
 */
#define TICKS 330

/*
 * Here you can specify the
 * size of the buffer to be written
 * to the analog outputs
 */
#define BUFFER_COUNT (32 * 1024)

/* 
 * Define this to enable the 
 * external trigger 
 */
#undef EX_TRIGGER


#define TIME_OUT (0*HZ)



int main(void){
    unsigned short *values;
    double dvalue;
    int m, i, j, err;
    unsigned int divisor = TICKS;
    int flags;
    unsigned long timeout = TIME_OUT;

    int fd_vec[] = {0, 0, 0, 0};
    int fd_count[] = {0, 0, 0, 0};
    char path[100];

    fd_set writefds;

    printf("%c%3s", 27, "[2J");
    printf("<<<--- EXAMPLE FOR AO CONTINUOUS MODE (nonblocking) --->>>\n\n");

    /* Try to open all possible pathes */
    for(i = 0; i < 4; i++){
	printf("Open path /dev/me4000_0_ao_%d_cont\n", i);
	sprintf(path, "/dev/me4000_0_ao_%d_cont", i);
	fd_vec[i] = open(path, O_RDWR | O_NONBLOCK, 0);
	if(fd_vec[i] < 0){
	    perror("Cannot open path");
	    return 1;
	}
    }

    /* Prepare values to write */
    values = (unsigned short *) malloc(2 * BUFFER_COUNT);
    if(!values){
	perror("Cannot allocate buffer for values");
	return 1;
    }
    memset(values, 0, 2 * BUFFER_COUNT);
    for(j = 0; j < BUFFER_COUNT / ME4000_AO_FIFO_COUNT; j++){
	for (i = 0; i < ME4000_AO_FIFO_COUNT; i++){
	    dvalue = 65536.0 /  ME4000_AO_FIFO_COUNT * i;
	    *(values + (i + j * ME4000_AO_FIFO_COUNT)) = (unsigned short) dvalue;
	}
    }

    /* Set the sample rate */
    for(i = 0; i < 4; i++){
	printf("Set timer for /dev/me4000_0_ao_%d_cont to %d\n", i, divisor);
	m = ioctl(fd_vec[i], ME4000_AO_TIMER_SET_DIVISOR, &divisor);
	if(m){
	    perror("Cannot set divisor");
	    return 1;
	}
    }

#ifdef EX_TRIGGER
    for(i = 0; i < 4; i++){
	int edge = ME4000_AO_TRIGGER_EXT_RISING;
	printf("Enable external trigger for /dev/me4000_0_ao_%d_cont\n", i);
	err = ioctl(fd_vec[i], ME4000_AO_EX_TRIG_SETUP, &edge);
	if(err){
	    perror("Cannot set external trigger");
	    return 1;
	}
	err = ioctl(fd_vec[i], ME4000_AO_EX_TRIG_ENABLE);
	if(err){
	    perror("Cannot enable external trigger");
	    return 1;
	}
    }
#endif

    /* Preload the fifos */
    for(i = 0; i < 4; i++){
	printf("Try to preload %d values to /dev/me4000_0_ao_%d_cont\n", BUFFER_COUNT, i);
	m = write(fd_vec[i], values, 2 * BUFFER_COUNT);
	if(m < 0){
	    perror("Cannot write all values to path");
	    return 1;
	}
	printf("Wrote %d values to /dev/me4000_0_ao_%d_cont\n", m/2, i);

	fd_count[i] += (m / 2);

	/* Get the flags for the file */
	flags = fcntl(fd_vec[i], F_GETFL, 0);

	/* Clear O_APPEND in order to do normal writes */
	flags |= O_APPEND;
	fcntl(fd_vec[i], F_SETFL, flags);
    }

    for(i = 0; i < 4; i++){
	printf("Start conversion for /dev/me4000_0_ao_%d_cont\n", i);
	err = ioctl(fd_vec[i], ME4000_AO_START, &timeout);
	if(err){
	    perror("Can't start conversion");
	    return 1;
	}
    }

    /* prepare the writefds */
    FD_ZERO(&writefds);
    while(1){
	for(i = 0; i < 4; i++){
	    FD_SET(fd_vec[i], &writefds);
	}

	err = select(10, NULL, &writefds, NULL, NULL);
	if(err < 0){
	    perror("Error while select");
	    break;
	}

	for(i = 0; i < 4; i++){
	    if(fd_count[i] < BUFFER_COUNT){
		if(FD_ISSET(fd_vec[i], &writefds)){
		    m = write(fd_vec[i], values + fd_count[i], 2 * (BUFFER_COUNT - fd_count[i]));
		    if(m < 0){
			perror("Cannot write to path");
			return 1;
		    }
		    fd_count[i] += (m / 2);
		}
	    }
	}
	if(fd_count[0] == BUFFER_COUNT && fd_count[1] == BUFFER_COUNT && 
		fd_count[2] == BUFFER_COUNT && fd_count[3] == BUFFER_COUNT) break;
    }


    for(i = 0; i < 4; i++){
	/* 
	 * This function block until all values were converted.
	 * In addition it check whether the conversion flow was interrupted
	 */
	printf("Synchronize with /dev/me4000_0_ao_%d_cont\n", i);
	err = fsync(fd_vec[i]);
	if(err < 0){
	    perror("Can't synchronize");
	    return 1;
	}
    }

    printf("Type return to terminate the program\n");
    getchar();


    /*-------------------------------- END ------------------------------*/

    /* Try to close all possible pathes */
    for(i = 0; i < 4; i++){
	printf("Close path /dev/me4000_0_ao_%d_cont\n", i);
	if(close(fd_vec[i])) perror("Cannot close path");
    }

    printf("End of Testprogram\n");

    return 0;
}

