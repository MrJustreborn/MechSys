#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>

/* 
 * This must be included in order
 * to have access to the ME-4000
 * specific definitions
 */
#include "../../me4000.h"

int main(void){
    unsigned short value;
    int error;
    int i;
    me4000_ao_channel_list_t channels;

    int fd0;
    int fd1;

    printf("%c%3s", 27, "[2J");
    printf("<<<--- EXAMPLE FOR AO SIMULTANEOUS SOFTWARE MODE --->>>\n\n");

    printf("Open path /dev/me4000_0_ao_0_sing\n");
    fd0 = open("/dev/me4000_0_ao_0_sing", O_WRONLY, 0);
    if(fd0 < 0){
	perror("Cannot open path");
	return 1;
    }

    printf("Open path /dev/me4000_0_ao_1_sing\n");
    fd1 = open("/dev/me4000_0_ao_1_sing", O_WRONLY, 0);
    if(fd1 < 0){
	perror("Cannot open path");
	return 1;
    }

    error = ioctl(fd0, ME4000_AO_SIMULTANEOUS_SW);
    if(error){
	perror("Cannot enable simultaneous");
	return 1;
    }
    error = ioctl(fd1, ME4000_AO_SIMULTANEOUS_SW);
    if(error){
	perror("Cannot enable simultaneous");
	return 1;
    }

    value = 0x0;
    error = write(fd0, &value, sizeof(value));
    if(error != sizeof(value)){
	perror("Cannot write to path");
	return 1;
    }
    value = 0xFFFF;
    error = write(fd1, &value, sizeof(value));
    if(error != sizeof(value)){
	perror("Cannot write to path");
	return 1;
    }

    printf("Please press ENTER to update the channels\n");
    getchar();

    channels.count = 2;
    channels.list = malloc(sizeof(unsigned long) * channels.count);
    for(i = 0; i < channels.count; i++){
	channels.list[i] = i;
    }
    error = ioctl(fd0, ME4000_AO_SIMULTANEOUS_UPDATE, &channels);
    if(error){
	perror("Cannot update channels");
	return 1;
    }

    /*-------------------------------- END ------------------------------*/

    printf("Please press ENTER to terminate the program\n");
    getchar();

    printf("End of Testprogram\n");

    return 0;
}
