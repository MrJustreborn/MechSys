#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>

/* 
 * This must be included in order
 * to have access to the ME-4000
 * specific definitions
 */
#include "../../me4000.h"

/* 
 * Opens on the first board
 * the first analog output 
 * in single mode
 */
#define PATH "/dev/me4000_0_ao_0_sing"


/* 
 * Digits to write to the analog output 
 * 0x0000 = -10 V
 * 0xFFFF =  10 V - 20 V / 65536
 */
#define DIGITS 0xF000


int main(void){
    unsigned short value;
    int error;
    me4000_user_info_t info;

    int fd;

    printf("%c%3s", 27, "[2J");
    printf("<<<--- EXAMPLE FOR AO SINGLE MODE --->>>\n\n");

    printf("Open path %s\n", PATH);
    fd = open(PATH, O_WRONLY, 0);
    if(fd < 0){
	perror("Cannot open path");
	return 1;
    }

    /* Get the user information related to this board */
    printf("Get user information from path %s\n", PATH);
    error = ioctl(fd, ME4000_GET_USER_INFO, &info);
    if(error){
	perror("Cannot get user info");
	return 1;
    }

    printf("\nUSER INFO :\n");
    printf("-----------\n");
    printf("board_count = %d\n", info.board_count);
    printf("vendor_id = 0x%X\n", info.vendor_id);
    printf("device_id = 0x%X\n", info.device_id);
    printf("plx_regbase = 0x%lX\n", info.plx_regbase);
    printf("plx_regbase_size = 0x%lX\n", info.plx_regbase_size);
    printf("me4000_regbase = 0x%lX\n", info.me4000_regbase);
    printf("me4000_regbase_size = 0x%lX\n", info.me4000_regbase_size);
    printf("serial_no = 0x%lX\n", info.serial_no);
    printf("hw_revision = 0x%X\n", info.hw_revision);
    printf("pci_bus_no = %d\n", info.pci_bus_no);
    printf("pci_dev_no = %d\n", info.pci_dev_no);
    printf("pci_func_no = %d\n", info.pci_func_no);
    printf("irq = %d\n", info.irq);
    printf("irq_count = %d\n", info.irq_count);
    printf("ao_number = %d\n", info.ao_count);
    printf("ao_fifo_number = %d\n", info.ao_fifo_count);
    printf("driver_version = 0x%X\n\n", info.driver_version);

    /* Prepare value to write */
    value = DIGITS;

    printf("Set voltage on path %s to %f V\n", PATH, 20.0 / 65536 * value - 10.0);
    error = write(fd, &value, sizeof(value));
    if(error != sizeof(value)){
	perror("Cannot write to path");
	return 1;
    }

    /*-------------------------------- END ------------------------------*/

    printf("Please press ENTER to terminate the program\n");
    getchar();

    /* Close the path */
    printf("Close path %s\n", PATH);
    if(close(fd)){
	perror("Cannot close path");
	return 1;
    }

    printf("End of Testprogram\n");

    return 0;
}
