#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>
#include <linux/param.h>

/* 
 * This must be included in order
 * to have access to the ME-4000
 * specific definitions
 */
#include "../../me4000.h"

/* 
 * Divisor for the 
 * internal 33MHz sample clock 
 */
#define TICKS 330


int main(void){
    unsigned short *values;
    int err;
    unsigned int divisor = TICKS;
    unsigned long timeout = 0;
    int n, m, i;

    int fd0;
    int fd1;

    printf("%c%3s", 27, "[2J");
    printf("<<<--- ME4000 EXAMPLE FOR SYNCHRONOUS SOFTWARE MODE --->>>\n\n");

    printf("Open path /dev/me4000_0_ao_0_wrap\n");
    fd0 = open("/dev/me4000_0_ao_0_wrap", O_RDWR, 0);
    if(fd0 < 0){
	perror("Cannot open path");
	return 1;
    }

    printf("Open path /dev/me4000_0_ao_1_wrap\n");
    fd1 = open("/dev/me4000_0_ao_1_wrap", O_RDWR, 0);
    if(fd1 < 0){
	perror("Cannot open path");
	return 1;
    }

    /* Prepare values to write */
    n = 2;
    values = (unsigned short *) malloc(2 * n);
    memset(values, 0, 2 * n);
    for (i = 0; i < n; i += 2){
	*(values + i) = 0xFFFF;
    }

    err = ioctl(fd0, ME4000_AO_SYNCHRONOUS_SW);
    if(err){
	perror("Cannot set preload bit");
	return 1;
    }

    err = ioctl(fd1, ME4000_AO_SYNCHRONOUS_SW);
    if(err){
	perror("Cannot set preload bit");
	return 1;
    }

    printf("Set timer divisor for /dev/me4000_0_ao_0_wrap to %d\n", divisor);
    err = ioctl(fd0, ME4000_AO_TIMER_SET_DIVISOR, &divisor);
    if(err){
	perror("Cannot set timer divisor");
	return 1;
    }

    printf("Set timer divisor for /dev/me4000_0_ao_1_wrap to %d\n", divisor);
    err = ioctl(fd1, ME4000_AO_TIMER_SET_DIVISOR, &divisor);
    if(err){
	perror("Cannot set timer divisor");
	return 1;
    }

    printf("Try to write %d bytes to /dev/me4000_0_ao_0_wrap\n", 2 * n);
    m = write(fd0, values, 2 * n);
    if(m != 2 * n){
	perror("Cannot write to path");
	return 1;
    }

    printf("Try to write %d bytes to /dev/me4000_0_ao_1_wrap\n", 2 * n);
    m = write(fd1, values, 2 * n);
    if(m != 2 * n){
	perror("Cannot write to path");
	return 1;
    }

    printf("Type return to start the conversion for /dev/me4000_0_ao_0_wrap\n");
    getchar();

    err = ioctl(fd0, ME4000_AO_START, &timeout);
    if(err){
	perror("Cannot start conversion");
	return 1;
    }

    printf("Type return to stop the conversion\n");
    getchar();

    printf("Stop conversion for /dev/me4000_0_ao_0_wrap\n");
    err = ioctl(fd0, ME4000_AO_STOP);
    if(err){
	perror("Cannot stop conversion");
	return 1;
    }

    printf("Stop conversion for /dev/me4000_0_ao_1_wrap\n");
    err = ioctl(fd1, ME4000_AO_STOP);
    if(err){
	perror("Cannot stop conversion");
	return 1;
    }

    printf("Type return to terminate the program\n");
    getchar();

    printf("End of program\n");

    return 0;
}

