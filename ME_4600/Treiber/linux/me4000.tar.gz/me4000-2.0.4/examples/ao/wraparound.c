#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>
#include <linux/param.h>

/* 
 * This must be included in order
 * to have access to the ME-4000
 * specific definitions
 */
#include "../../me4000.h"

/* 
 * Opens on the first board
 * the first analog output 
 * in wraparound mode
 */
#define PATH "/dev/me4000_0_ao_0_wrap"

/* 
 * Define this to enable 
 * external trigger 
 */
#undef EX_TRIGGER

/* 
 * Divisor for the 
 * internal 33MHz sample clock 
 */
#define TICKS 330

#define TIME_OUT (3*HZ)

int main(void){
    unsigned short *values;
    int err;
    unsigned int divisor = TICKS;
    int n, m, i;
    unsigned long timeout = TIME_OUT;

    int fd;

    printf("%c%3s", 27, "[2J");
    printf("<<<--- ME4000 EXAMPLE FOR WRAPAROUND MODE --->>>\n\n");

    printf("Open path %s\n", PATH);
    fd = open(PATH, O_RDWR, 0);
    if(fd < 0){
	perror("Cannot open path");
	return 1;
    }

    /* Prepare values to write */
    n = 2;
    values = (unsigned short *) malloc(2 * n);
    memset(values, 0, 2 * n);
    for (i = 0; i < n; i += 2){
	*(values + i) = 0xFFFF;
    }

    printf("Set timer divisor for %s to %d\n", PATH, divisor);
    err = ioctl(fd, ME4000_AO_TIMER_SET_DIVISOR, &divisor);
    if(err){
	perror("Cannot set timer divisor");
	return 1;
    }

    printf("Try to write %d bytes to %s\n", 2 * n, PATH);
    m = write(fd, values, 2 * n);
    if(m != 2 * n){
	perror("Cannot write to path");
	return 1;
    }

#ifdef EX_TRIGGER
    {
	int edge = ME4000_AO_TRIGGER_EXT_EDGE_RISING;
	printf("Setup external trigger for path %s\n", PATH);
	err = ioctl(fd, ME4000_AO_EX_TRIG_SETUP, &edge);
	if(err){
	    perror("Cannot setup external trigger");
	    return 1;
	}
	printf("Enable external trigger for path %s\n", PATH);
	err = ioctl(fd, ME4000_AO_EX_TRIG_ENABLE);
	if(err){
	    perror("Cannot enable external trigger");
	    return 1;
	}
    }
#endif

    printf("Type return to start the conversion for %s\n", PATH);
    getchar();

    err = ioctl(fd, ME4000_AO_START, &timeout);
    if(err){
	perror("Cannot start conversion");
	return 1;
    }

    printf("Type return to stop the conversion\n");
    getchar();

    printf("Stop conversion for %s\n", PATH);
    err = ioctl(fd, ME4000_AO_STOP);
    if(err){
	perror("Cannot stop conversion");
	return 1;
    }

    printf("Type return to terminate the program\n");
    getchar();


    /*-------------------------------- END ------------------------------*/

    printf("Close path %s\n", PATH);
    if(close(fd)){
	perror("Cannot close path");
	return 1;
    }

    printf("End of program\n");

    return 0;
}

