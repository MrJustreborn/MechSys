#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>
#include <linux/param.h>
#include <time.h>

#include "../../me4000.h"

#define COUNTER ME4000_CNT_COUNTER_0
#define DIVISOR 2


int main(void){
    me4000_cnt_config_t config;
    me4000_cnt_t count;
    int fd;
    int err;
    char *path = "/dev/me4000_0_cnt";

    printf("%c%3s", 27, "[2J");
    printf("<<<--- EXAMPLE FOR COUNTER --->>>\n\n");

    printf("Open path %s\n", path);
    fd = open(path, O_RDWR, 0);
    if(fd < 0){
	perror("Cannot open path");
	return 1;
    }

    config.counter = COUNTER;
    config.mode = ME4000_CNT_MODE_3;

    printf("Counter mode = %d\n", config.mode);

    err = ioctl(fd, ME4000_CNT_CONFIG, &config);
    if(err){
	perror("Can't configure counter");
	return 1;
    }

    count.counter = COUNTER;
    count.value = DIVISOR;

    printf("Count = %d\n", count.value);

    err = ioctl(fd, ME4000_CNT_WRITE, &count);
    if(err){
	perror("Cannot write to counter");
	return 1;
    }

    /*-------------------------------- END ------------------------------*/

    printf("Please press ENTER to terminate the program\n");
    getchar();

    /* Try to close all possible pathes */
    printf("Close path %s\n", path);
    if(close(fd)) perror("Cannot close path");

    printf("End of Testprogram\n");

    return 0;
}
