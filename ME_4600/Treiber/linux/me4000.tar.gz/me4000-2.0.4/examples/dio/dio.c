#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>
#include <linux/param.h>
#include <time.h>

#include "../../me4000.h"



int main(void){
    me4000_dio_config_t config;
    me4000_dio_byte_t byte;
    int fd;
    int err;
    int i;
    char *path = "/dev/me4000_0_dio";

    printf("%c%3s", 27, "[2J");
    printf("<<<--- EXAMPLE FOR DIGITAL I/O --->>>\n\n");

    printf("Open path %s\n", path);
    fd = open(path, O_RDWR, 0);
    if(fd < 0){
	perror("Cannot open path");
	return 1;
    }

    config.port = 0;
    config.mode = ME4000_DIO_PORT_INPUT;
    config.function = 0; // Doesn't matter

    err = ioctl(fd, ME4000_DIO_CONFIG, &config);
    if(err){
	perror("Can't configure DIO");
	return 1;
    }

    printf("Read from port 0\n");

    byte.port = 0;
    err = ioctl(fd, ME4000_DIO_GET_BYTE, &byte);
    if(err){
	perror("Cannot read byte from DIO");
	return 1;
    }
    printf("Byte = 0x%02X\n", byte.byte);

    config.port = 1;
    config.mode = ME4000_DIO_PORT_OUTPUT;
    config.function = 0; // Doesn't matter

    err = ioctl(fd, ME4000_DIO_CONFIG, &config);
    if(err){
	perror("Can't configure DIO");
	return 1;
    }

    printf("Write to port 1\n");

    for(i = 0; i < 8; i++){
	byte.port = 1;
	byte.byte = 1 << i;

	err = ioctl(fd, ME4000_DIO_SET_BYTE, &byte);
	if(err){
	    perror("Cannot set byte");
	    return 1;
	}
	sleep(1);
    }

    /*-------------------------------- END ------------------------------*/

    printf("Please press ENTER to terminate the program\n");
    getchar();

    /* Try to close all possible pathes */
    printf("Close path %s\n", path);
    if(close(fd)) perror("Cannot close path");

    printf("End of Testprogram\n");

    return 0;
}
