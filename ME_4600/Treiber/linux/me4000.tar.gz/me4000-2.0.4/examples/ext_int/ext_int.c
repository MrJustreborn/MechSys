/*
 * Author: GG (Guenter Gebhardt)                                 
 *                                                                     
 * Description:                                                        
 *   With this program you can test the external interrupt. The program
 *   installs a signal handler, which is executed, when the external
 *   interrupt occures. This program waits for 32 interrupts, 
 *   then the program is aborted.
 */

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <time.h>
#include <string.h>

#include "../../me4000.h"

void signal_handler(int);

/* Count of signal handler execution */
int volatile i = 0;

int file_handle = -1;

int main(void){
    int oflags = 0;
    int err = 0;

    printf("%c%3s", 27, "[2J");
    printf("<<<--- EXAMPLE FOR EXTERNAL INTERRUPT --->>>\n\n");

    printf("Open path /dev/me4000_0_ext_int\n");

    file_handle = open("/dev/me4000_0_ext_int", O_RDWR, 0);
    if(file_handle < 0){
	printf("Cannot open path\n");
	return 1;
    }

    err = ioctl(file_handle, ME4000_EXT_INT_ENABLE);
    if(err){
	printf("Cannot enable interrupt\n");
	return err;
    }

    /* Install signal handler */
    signal(SIGIO, signal_handler);

    /* Register process as owner of the path */
    fcntl(file_handle, F_SETOWN, getpid());

    /* Ask for the flags set in the path */
    oflags = fcntl(file_handle, F_GETFL);

    /* Set the current process to the asuncronous queue of the driver */
    fcntl(file_handle, F_SETFL, oflags | FASYNC); 

    printf("<<<--- WAITING FOR INTERRUPTS --->>>\n\n");

    /* execute programm until 0x1f interrupt will be occured */
    while(i < 16){
    }

    err = ioctl(file_handle, ME4000_EXT_INT_DISABLE);
    if(err){
	printf("Cannot enable interrupt\n");
	return err;
    }

    printf("Close path\n");
    err = close(file_handle);
    if(err){
	perror("Cannot close path");
	return 1;
    }

    return 0;
}


void signal_handler(int sig){
    unsigned int count;
    int err;

    i++;

    printf("<<<--- ME4000 SIGNAL HANDLER CALLED --->>>\n");
    printf("Execution = %d\n", i);

    err = ioctl(file_handle, ME4000_EXT_INT_COUNT, &count);
    if(err) perror("Cannot get interrupt count\n");

    printf("Interrupt count = %d\n", count);

    return;
}




