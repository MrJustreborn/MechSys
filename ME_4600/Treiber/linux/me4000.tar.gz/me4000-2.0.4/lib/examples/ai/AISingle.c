#include <unistd.h>
#include <stdio.h>
#include <ctype.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"



void usage(void){
	printf("AISingle - Program to test the digital inputs\n\n");
	printf("Usage: AISingle [arguments]\n\n");
	printf("Arguments:\n\n");
	printf("-h                     Print this help and exit.\n");
	printf("-b <board number>      Use <board number> board (Default 0).\n");
	printf("-l <line number>       Use <line number> analog output (Default 0).\n");
	printf("-r <range>             Use range BIPOLAR_10, BIPOLAR_2_5, UNIPOLAR_10 or UNIPOLAR_2_5 (Default BIPOLAR_10).\n");
	printf("-s <SD mode>           Set the line ending to SINGLE or DIFFERENTIAL (Default SINGLE).\n");
	printf("-t <trigger>           Set the trigger to <trigger>. This must be one of the following:\n");
	printf("                       'SOFTWARE', 'EXT_DIGITAL' or 'EXT_ANALOG' (Default 'SOFTWARE').\n");
	printf("-e <edge>              Set the trigger to <edge>. This must be one of the following:\n");
	printf("                       'RISING', 'FALLING' or 'BOTH' (Default 'BOTH').\n");
	printf("-o <timeout>           Timeout when external trigger is used (Default 0).\n");
}



int main(int argc, char *argv[]){
	int err;
	int c;
	char errStr[256] = {0};
	unsigned int board = 0;
	unsigned int line = 0;
	int range = ME4000_AI_RANGE_BIPOLAR_10;
	int SDMode = ME4000_AI_INPUT_SINGLE_ENDED;
	int trigger = ME4000_AI_TRIGGER_SOFTWARE;
	int edge = ME4000_AI_TRIGGER_EXT_EDGE_BOTH;
	unsigned long timeout = 0;
	short value = 0;
	double dValue = 0;

	/* Parse the command line arguments */
	while((c = getopt(argc, argv, "hb:l:r:s:t:e:o:")) != -1){
		switch(c){
			case 'h':
				usage();
				exit(0);
			case 'b':
				board = atoi(optarg);
				break;
			case 'l':
				line = atoi(optarg);
				break;
			case 'r':
				if(!strcmp(optarg, "BIPOLAR_10")){
					range = ME4000_AI_RANGE_BIPOLAR_10;
				}
				else if (!strcmp(optarg, "BIPOLAR_2_5")){
					range = ME4000_AI_RANGE_BIPOLAR_2_5;
				}
				else if (!strcmp(optarg, "UNIPOLAR_10")){
					range = ME4000_AI_RANGE_UNIPOLAR_10;
				}
				else if (!strcmp(optarg, "UNIPOLAR_2_5")){
					range = ME4000_AI_RANGE_BIPOLAR_2_5;
				}
				else{
					fprintf(stderr, "%s: Invalid option argument for option '-t'.\n", argv[0]);
					usage();
					exit(2);
				}
				break;
			case 's':
				if(!strcmp(optarg, "SINGLE_ENDED")){
					SDMode = ME4000_AI_INPUT_SINGLE_ENDED;
				}
				else if (!strcmp(optarg, "DIFFERENTIAL")){
					SDMode = ME4000_AI_INPUT_DIFFERENTIAL;
				}
				else{
					fprintf(stderr, "%s: Invalid option argument for option '-t'.\n", argv[0]);
					usage();
					exit(2);
				}
				break;
			case 't':
				if(!strcmp(optarg, "SOFTWARE")){
					trigger = ME4000_AI_TRIGGER_SOFTWARE;
				}
				else if (!strcmp(optarg, "EXT_DIGITAL")){
					trigger = ME4000_AI_TRIGGER_EXT_DIGITAL;
				}
				else if (!strcmp(optarg, "EXT_ANALOG")){
					trigger = ME4000_AI_TRIGGER_EXT_ANALOG;
				}
				else{
					fprintf(stderr, "%s: Invalid option argument for option '-t'.\n", argv[0]);
					usage();
					exit(2);
				}
				break;
			case 'e':
				if (!strcmp(optarg, "RISING")){
					edge = ME4000_AI_TRIGGER_EXT_EDGE_RISING;
				}
				else if (!strcmp(optarg, "FALLING")){
					edge = ME4000_AI_TRIGGER_EXT_EDGE_FALLING;
				}
				else if (!strcmp(optarg, "BOTH")){
					edge = ME4000_AI_TRIGGER_EXT_EDGE_BOTH;
				}
				else{
					fprintf(stderr, "%s: Invalid option argument for option '-t'.\n", argv[0]);
					usage();
					exit(2);
				}
				break;
			case 'o':
				timeout = atol(optarg);
				break;
			default:
				usage();
				exit(2);
		}
	}

	if(optind != argc){
		fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
		usage();
		exit(2);
	}

	printf("Open analog input on board %d in single mode\n", board);
	err = me4000AIOpen(board, ME4000_AI_ACQ_MODE_SINGLE);
	if(err){
		me4000ErrorGetMessage(err, errStr, sizeof(errStr));
		fprintf(stderr, "ERROR: %s.\n", errStr);
		exit(1);
	}

	err = me4000AISingle(
			board, 
			line,
			range,
			SDMode,
			trigger,
			edge, 
			timeout,
			&value);
	if(err){
		me4000ErrorGetMessage(err, errStr, sizeof(errStr));
		fprintf(stderr, "ERROR: %s.\n", errStr);
		exit(1);
	}

	err = me4000AIDigitToVolt(
			value,
			range,
			&dValue);
	if(err){
		me4000ErrorGetMessage(err, errStr, sizeof(errStr));
		fprintf(stderr, "ERROR: %s.\n", errStr);
		exit(1);
	}

	printf("Voltage on channel %d is %.2f V.\n", line, dValue);

	printf("Close analog input on board %d.\n", board);
	err = me4000AIClose(board);
	if(err){
		me4000ErrorGetMessage(err, errStr, sizeof(errStr));
		fprintf(stderr, "ERROR: %s.\n", errStr);
		exit(1);
	}

	return 0;
}
