#include <unistd.h>
#include <stdio.h>
#include <ctype.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"



void usage(void){
    printf("AITimer - Program to test the digital inputs\n\n");
    printf("Usage: AITimer [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-b <board number>      Use <board number> board (Default 0).\n");
    printf("-l <line count>        Use <line count> analog inputs (Default 1).\n");
    printf("-r <range>             Use range BIPOLAR_10, BIPOLAR_2_5, UNIPOLAR_10 or UNIPOLAR_2_5 (Default BIPOLAR_10).\n");
    printf("-s <SD mode>           Set the line ending to SINGLE or DIFFERENTIAL (Default SINGLE).\n");
    printf("-a <acq mode>          Set the acquisition mode. This must be one of the following:\n");
    printf("                       'SOFTWARE', 'EXT', 'EXT_SINGLE_VALUE' or 'EXT_SINGLE_CHANLIST' (Default 'SOFTWARE').\n");
    printf("-t <trigger>           Set the trigger to <trigger>. This must be one of the following:\n");
    printf("                       'SOFTWARE', 'EXT_DIGITAL' or 'EXT_ANALOG' (Default 'SOFTWARE').\n");
    printf("-e <edge>              Set the trigger to <edge>. This must be one of the following:\n");
    printf("                       'RISING', 'FALLING' or 'BOTH' (Default 'BOTH').\n");
    printf("-i <interval>          Use <interval> seconds between two samples (Default 1E-3).\n");
    printf("-o <timeout>           Timeout when external trigger is used (Default 0).\n");
    printf("-n <number>            Read <number> of values from the analog input (Default 100).\n");
    printf("-m <mode>              Set the acquisition type to 'CONTINUOUS' or 'SCAN' (Default 'CONTINUOUS').\n");
}



int main(int argc, char *argv[]){
    int err;
    int c;
    int i;
    char errStr[256] = {0};
    unsigned int board = 0;
    unsigned int line = 1;
    int range = ME4000_AI_RANGE_BIPOLAR_10;
    int SDMode = ME4000_AI_INPUT_SINGLE_ENDED;
    int acqMode = ME4000_AI_ACQ_MODE_SOFTWARE;
    int trigger = ME4000_AI_TRIGGER_SOFTWARE;
    int edge = ME4000_AI_TRIGGER_EXT_EDGE_BOTH;
    unsigned long timeout = 0;
    double interval = 1E-3;
    unsigned char *pucChanlist = NULL;
    unsigned long ticksHigh = 0;
    unsigned long ticks = 66;
    unsigned long number = 100;
    unsigned long read;
    int lastErr;
    short *buffer = NULL;
    short *chanBuffer = NULL;
    int mode = 0; // Continuous

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "hb:l:r:s:t:e:i:o:n:m:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 'b':
		board = atoi(optarg);
		break;
	    case 'l':
		line = atoi(optarg);
		break;
	    case 'r':
		if(!strcmp(optarg, "BIPOLAR_10")){
		    range = ME4000_AI_RANGE_BIPOLAR_10;
		}
		else if (!strcmp(optarg, "BIPOLAR_2_5")){
		    range = ME4000_AI_RANGE_BIPOLAR_2_5;
		}
		else if (!strcmp(optarg, "UNIPOLAR_10")){
		    range = ME4000_AI_RANGE_UNIPOLAR_10;
		}
		else if (!strcmp(optarg, "UNIPOLAR_2_5")){
		    range = ME4000_AI_RANGE_BIPOLAR_2_5;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-r'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 's':
		if(!strcmp(optarg, "SINGLE_ENDED")){
		    SDMode = ME4000_AI_INPUT_SINGLE_ENDED;
		}
		else if (!strcmp(optarg, "DIFFERENTIAL")){
		    SDMode = ME4000_AI_INPUT_DIFFERENTIAL;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-s'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 't':
		if(!strcmp(optarg, "SOFTWARE")){
		    trigger = ME4000_AI_TRIGGER_SOFTWARE;
		}
		else if (!strcmp(optarg, "EXT_DIGITAL")){
		    trigger = ME4000_AI_TRIGGER_EXT_DIGITAL;
		}
		else if (!strcmp(optarg, "EXT_ANALOG")){
		    trigger = ME4000_AI_TRIGGER_EXT_ANALOG;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-t'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 'e':
		if (!strcmp(optarg, "RISING")){
		    edge = ME4000_AI_TRIGGER_EXT_EDGE_RISING;
		}
		else if (!strcmp(optarg, "FALLING")){
		    edge = ME4000_AI_TRIGGER_EXT_EDGE_FALLING;
		}
		else if (!strcmp(optarg, "BOTH")){
		    edge = ME4000_AI_TRIGGER_EXT_EDGE_BOTH;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-e'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 'i':
		interval = atof(optarg);
		break;
	    case 'o':
		timeout = atol(optarg);
		break;
	    case 'n':
		number = atol(optarg);
		break;
	    case 'm':
		if (!strcmp(optarg, "CONTINUOUS")){
		    mode = 0;
		}
		else if (!strcmp(optarg, "SCAN")){
		    mode = 1;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-m'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    printf("Open analog input on board %d\n", board);
    err = me4000AIOpen(board, acqMode);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    /*-------------------------------------------------------------------------
      Create channel list
      -----------------------------------------------------------------------*/

    pucChanlist = malloc(sizeof(unsigned char) * line);
    if(!pucChanlist){
	perror("Cannot allocate memory for channel list");
	exit(1);
    }

    for(i = 0; i < line; i++){
	err = me4000AIMakeChannelListEntry(
		i, 
		range, 
		&pucChanlist[i]);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
    }

    /*-------------------------------------------------------------------------
      Configure analog input
      -----------------------------------------------------------------------*/

    printf("Calculate ticks between two successive samples.\n");
    err = me4000TimeToTicks(interval, &ticks, &ticksHigh, &interval);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    printf("Configure analog input.\n");
    err = me4000AIConfig(
	    board, 
	    pucChanlist, 
	    line, 
	    SDMode, 
	    ME4000_AI_SIMULTANEOUS_DISABLE, 
	    0,
	    ticks, 
	    0, 
	    0, 
	    acqMode,
	    trigger, 
	    edge);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    printf("Allocate buffer for data.\n");
    buffer = malloc(sizeof(short) * number);
    if(!buffer){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    if(!mode){ // Continuous selected
	printf("Prepare for continuous conversion.\n");
	err = me4000AIContinuous(
		board, 
		NULL, 
		NULL, 
		ME4000_VALUE_NOT_USED, 
		timeout);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
    }
    else{ // Scan selected
	printf("Prepare for scan conversion.\n");
	err = me4000AIScan(
		board,
		ME4000_VALUE_NOT_USED, // Not used in Linux
		buffer,
		number,
		ME4000_AI_SCAN_BLOCKING,
		ME4000_POINTER_NOT_USED,
		ME4000_POINTER_NOT_USED,
		ME4000_VALUE_NOT_USED,
		ME4000_POINTER_NOT_USED,
		ME4000_POINTER_NOT_USED,
		ME4000_VALUE_NOT_USED);
    }

    /*-------------------------------------------------------------------------
      Start the conversion
      -----------------------------------------------------------------------*/

    printf("Start acquisition on board %d.\n", board);
    err = me4000AIStart(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    if(!mode){
	printf("Read %lu values from the analog input.\n", number);
	err = me4000AIGetNewValues(
		board,
		buffer,
		number,
		ME4000_AI_GET_NEW_VALUES_BLOCKING,
		&read,
		&lastErr);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
	printf("Read %lu values from the analog input.\n", read);

	printf("Stop acquisition on board %d.\n", board);
	err = me4000AIStop(board, 0);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
    }

    chanBuffer = malloc(sizeof(short) * number);
    if(!chanBuffer){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    for(i = 0; i < line; i++){
	unsigned long dataCount;
	double dValue;

	printf("Extract channel results from buffer for channel %d.\n", i);
	err = me4000AIExtractValues(
		i,
		buffer,
		number,
		pucChanlist,
		line,
		chanBuffer,
		number,
		&dataCount);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}

	printf("%li Values were extracted from channel %d.\n", dataCount, i);
	for(c = 0; c < dataCount; c++){
	    err = me4000AIDigitToVolt(
		    chanBuffer[c],
		    range,
		    &dValue);
	    if(err){
		me4000ErrorGetMessage(err, errStr, sizeof(errStr));
		fprintf(stderr, "ERROR: %s.\n", errStr);
		exit(1);
	    }
	    printf("Channel %02i: Voltage %d = %2.2f V.\n", i, c, dValue);

	}
    }

    /*-------------------------------------------------------------------------
      Close the analog input.
      -----------------------------------------------------------------------*/

    printf("Close analog input on board %d\n", board);
    err = me4000AIClose(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    return 0;
}
