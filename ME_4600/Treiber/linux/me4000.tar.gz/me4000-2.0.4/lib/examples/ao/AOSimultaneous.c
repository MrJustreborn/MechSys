#include <unistd.h>
#include <stdio.h>
#include <ctype.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"



void usage(void){
    printf("AOSingleSimultaneous - Program to test the analog outputs\n\n");
    printf("Usage: AOSingleSimultaneous [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-b <board number>      Use <board number> board (Default 0).\n");
    printf("-t <trigger>           Set the trigger to <trigger>. This must be one of the following:\n");
    printf("                       'SOFTWARE' or external trigger with 'RISING', 'FALLING' or 'BOTH' edges (Default 'SOFTWARE').\n");
    printf("-e <enable>            Enables the external trigger on channel <enable>. 0 to 3 is valid (Default 0)\n");
    printf("-o <timeout>           Timeout when external trigger is used (Default 0).\n");
}



int main(int argc, char *argv[]){
    int err;
    int c;
    int i;
    char errStr[256] = {0};
    unsigned int board = 0;
    int enabled = 0;
    int trigger = ME4000_AO_TRIGGER_SOFTWARE;
    int edge = ME4000_AO_TRIGGER_EXT_EDGE_BOTH;
    unsigned long timeout = 0;
    unsigned short values[4] = {0, 0, 0, 0};
    unsigned int channels[4] = {0, 1, 2, 3};
    unsigned int enable[4] = {
	ME4000_AO_TRIGGER_EXT_DISABLE,
       	ME4000_AO_TRIGGER_EXT_DISABLE,
       	ME4000_AO_TRIGGER_EXT_DISABLE,
       	ME4000_AO_TRIGGER_EXT_DISABLE};
    unsigned int edges[4] = {
	ME4000_AO_TRIGGER_EXT_EDGE_BOTH,
	ME4000_AO_TRIGGER_EXT_EDGE_BOTH,
       	ME4000_AO_TRIGGER_EXT_EDGE_BOTH,
       	ME4000_AO_TRIGGER_EXT_EDGE_BOTH};

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "hb:t:e:o:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 'b':
		board = atoi(optarg);
		break;
	    case 't':
		if(!strcmp(optarg, "SOFTWARE")){
		    trigger = ME4000_AO_TRIGGER_SOFTWARE;
		}
		else if (!strcmp(optarg, "RISING")){
		    trigger = ME4000_AO_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_AO_TRIGGER_EXT_EDGE_RISING;
		}
		else if (!strcmp(optarg, "FALLING")){
		    trigger = ME4000_AO_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_AO_TRIGGER_EXT_EDGE_FALLING;
		}
		else if (!strcmp(optarg, "BOTH")){
		    trigger = ME4000_AO_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_AO_TRIGGER_EXT_EDGE_BOTH;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-t'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 'e':
		enabled = atoi(optarg);
		if(enabled < 0 || enabled > 3){
		    fprintf(stderr, "%s: Invalid trigger source specified '-e'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 'o':
		timeout = atol(optarg);
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    enable[enabled] = ME4000_AO_TRIGGER_EXT_ENABLE;
    edges[enabled] = edge;

    for(i = 0; i < 4; i++){
	printf("Open on board %d analog output %d.\n", board, i);
	err = me4000AOOpen(board, i, ME4000_AO_CONV_MODE_SINGLE);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
    }

    for(i = 0; i < 4; i++){
	printf("Reset voltage to -10V on analog output %d.\n", i);
	err = me4000AOSingle(
		board, 
		i,
		ME4000_AO_TRIGGER_SOFTWARE,
		ME4000_VALUE_NOT_USED, 
		ME4000_VALUE_NOT_USED,
		ME4000_VALUE_NOT_USED);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
    }

    for(i = 0; i < 4; i++){
	err = me4000AOVoltToDigit(i + 1, &values[i]);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
	printf("Voltage for analog output %d is %dV.\n", i, i + 1);
    }

    printf("Write simultaneously to all channels.\n");
    err = me4000AOSingleSimultaneous(
	    board, 
	    channels, 
	    4, 
	    trigger, 
	    enable, 
	    edges, 
	    timeout,
	    values);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    for(i = 0; i < 4; i++){
	printf("Close analog output %d.\n", i);
	err = me4000AOClose(board, i);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
    }

    return 0;
}
