#include <unistd.h>
#include <stdio.h>
#include <ctype.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"



void usage(void){
    printf("AOSingle - Program to test the digital outputs\n\n");
    printf("Usage: AOSingle [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-b <board number>      Use <board number> board (Default 0).\n");
    printf("-l <line number>       Use <line number> analog output (Default 0).\n");
    printf("-v <voltage>           Set the voltage <voltage> on the analog output line (Default 0.0V).\n");
    printf("-t <trigger>           Set the trigger to <trigger>. This must be one of the following:\n");
    printf("                       'SOFTWARE' or external trigger with 'RISING', 'FALLING' or 'BOTH' edges (Default 'SOFTWARE').\n");
    printf("-o <timeout>           Timeout when external trigger is used (Default 0).\n");
}



int main(int argc, char *argv[]){
    int err;
    int c;
    char errStr[256] = {0};
    unsigned int board = 0;
    unsigned int line = 0;
    double voltage = 0.0;
    unsigned short value;
    int trigger = ME4000_AO_TRIGGER_SOFTWARE;
    int edge = ME4000_AO_TRIGGER_EXT_EDGE_BOTH;
    unsigned long timeout = 0;

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "hb:l:v:t:o:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 'b':
		board = atoi(optarg);
		break;
	    case 'l':
		line = atoi(optarg);
		break;
	    case 'v':
		voltage = atof(optarg);
		break;
	    case 't':
		if(!strcmp(optarg, "SOFTWARE")){
		    trigger = ME4000_AO_TRIGGER_SOFTWARE;
		}
		else if (!strcmp(optarg, "RISING")){
		    trigger = ME4000_AO_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_AO_TRIGGER_EXT_EDGE_RISING;
		}
		else if (!strcmp(optarg, "FALLING")){
		    trigger = ME4000_AO_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_AO_TRIGGER_EXT_EDGE_FALLING;
		}
		else if (!strcmp(optarg, "BOTH")){
		    trigger = ME4000_AO_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_AO_TRIGGER_EXT_EDGE_BOTH;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-t'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 'o':
		timeout = atol(optarg);
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    printf("Open on board %d analog output %d in single mode\n", board, line);
    err = me4000AOOpen(board, line, ME4000_AO_CONV_MODE_SINGLE);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    printf("Write %f volts to analog output.\n", voltage);
    err = me4000AOVoltToDigit(voltage, &value);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    err = me4000AOSingle(
	    board, 
	    line,
	    trigger,
	    edge, 
	    timeout,
	    value);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    printf("Close on board %d analog output %d.\n", board, line);
    err = me4000AOClose(board, line);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    return 0;
}
