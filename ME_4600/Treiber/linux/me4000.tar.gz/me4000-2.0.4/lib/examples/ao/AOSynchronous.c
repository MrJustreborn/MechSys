#include <unistd.h>
#include <stdio.h>
#include <ctype.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"



void usage(void){
    printf("aoSynchronous - Program to test the analog output with synchronous start\n\n");
    printf("Usage: aoSynchronous [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-b <board number>      Use <board number> board (Default 0).\n");
    printf("-m <mode>              Sets the conversion mode to either 'WRAPAROUND',\n");
    printf("                       'CONTINUOUS' or 'RESET' (Default 'WRAPAROUND').\n");
    printf("-t <trigger>           Sets the trigger to either 'SOFTWARE' or external 'RISING',\n");
    printf("                       'FALLING' or 'BOTH' edges (Default 'SOFTWARE').\n");
    printf("-e <enable>            Enables the external trigger on channel <enable>. 0 to 3 is valid (Default 0)\n");
    printf("-o <timeout>           Timeout when external trigger is used (Default 0).\n");
    printf("-i <interval>          Time interval between two successive values (Default 1E-3).\n");
}



int main(int argc, char *argv[]){
    int err;
    char errStr[256] = {0};
    int c;
    int i;
    unsigned int board = 0;
    unsigned int channels[4] = {0, 1, 2, 3};
    int mode = ME4000_AO_CONV_MODE_WRAPAROUND;
    int trigger = ME4000_AO_TRIGGER_SOFTWARE;
    int edge = ME4000_AO_TRIGGER_EXT_EDGE_RISING;
    int enabled = 0;
    unsigned int enable[4] = {
	ME4000_AO_TRIGGER_EXT_DISABLE,
       	ME4000_AO_TRIGGER_EXT_DISABLE,
       	ME4000_AO_TRIGGER_EXT_DISABLE,
       	ME4000_AO_TRIGGER_EXT_DISABLE};
    unsigned int edges[4] = {
	ME4000_AO_TRIGGER_EXT_EDGE_BOTH,
	ME4000_AO_TRIGGER_EXT_EDGE_BOTH,
       	ME4000_AO_TRIGGER_EXT_EDGE_BOTH,
       	ME4000_AO_TRIGGER_EXT_EDGE_BOTH};
    unsigned long sample = 33000;
    unsigned long timeout = 0;
    int reset = 0;
    unsigned short *values;
    unsigned long written[4] = {0, 0, 0, 0};

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "hb:m:t:i:o:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 'b':
		board = atoi(optarg);
		break;
	    case 'm':
		if(!strcmp(optarg, "WRAPAROUND")){
		    mode = ME4000_AO_CONV_MODE_WRAPAROUND;
		}
		else if(!strcmp(optarg, "CONTINUOUS")){
		    mode = ME4000_AO_CONV_MODE_CONTINUOUS;
		}
		else if(!strcmp(optarg, "RESET")){
		    mode = ME4000_AO_CONV_MODE_WRAPAROUND;
		    reset = 1;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-c'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 't':
		if(!strcmp(optarg, "SOFTWARE")){
		    trigger = ME4000_AO_TRIGGER_SOFTWARE;
		}
		else if (!strcmp(optarg, "RISING")){
		    trigger = ME4000_AO_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_AO_TRIGGER_EXT_EDGE_RISING;
		}
		else if (!strcmp(optarg, "FALLING")){
		    trigger = ME4000_AO_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_AO_TRIGGER_EXT_EDGE_FALLING;
		}
		else if (!strcmp(optarg, "BOTH")){
		    trigger = ME4000_AO_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_AO_TRIGGER_EXT_EDGE_BOTH;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-t'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 'e':
		enabled = atoi(optarg);
		if(enabled < 0 || enabled > 3){
		    fprintf(stderr, "%s: Invalid trigger source specified '-e'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 'i':
		{
		    unsigned long high;
		    double achieved;
		    double freq = atof(optarg);
		    err = me4000TimeToTicks(freq, &sample, &high, &achieved);
		    if(err){
			me4000ErrorGetLastMessage(errStr, sizeof(errStr));
			fprintf(stderr, "ERROR while me4000TimeToTicks():%s\n", errStr);
			exit(1);
		    }
		}
		break;
	    case 'o':
		timeout = atoi(optarg);
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    enable[enabled] = ME4000_AO_TRIGGER_EXT_ENABLE;
    edges[enabled] = edge;

    for(i = 0; i < 4; i++){
	printf("Open analog output %d on board %d\n", i, board);
	err = me4000AOOpen(board, i, mode);
	if(err){
	    me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR while me4000AOOpen():%s\n", errStr);
	    exit(1);
	}
    }

    if(reset == 0){
	for(i = 0; i < 4; i++){
	    printf("Stop any previously started conversion on analog output %d.\n", i);
	    err = me4000AOStop(board, i, ME4000_AO_STOP_MODE_IMMEDIATE);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000AOStop():%s\n", errStr);
		exit(1);
	    }
	}

	for(i = 0; i < 4; i++){
	    printf("Configure analog output %d.\n", i);
	    err = me4000AOConfig(
		    board, 
		    i,
		    sample, 
		    0, 
		    0);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000AOConfig():%s\n", errStr);
		exit(1);
	    }
	}

	if(mode == ME4000_AO_CONV_MODE_WRAPAROUND){ // Wraparound
	    values = malloc(2 * sizeof(unsigned short));
	    if(!values){
		perror("Cannot get buffer for output values");
		exit(1);
	    }
	    values[0] = 0x00;
	    values[1] = 0xFFFF;

	    for(i = 0; i < 4; i++){
		printf("Write values for wraparound conversion to analog output %d.\n", i);
		err = me4000AOWraparound(
			board, 
			i,
			values, 
			2, 
			ME4000_AO_WRAPAROUND_INFINITE,
			ME4000_AO_WRAPAROUND_ASYNCHRONOUS,
			ME4000_POINTER_NOT_USED,
			ME4000_POINTER_NOT_USED,
			0);
		if(err){
		    me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		    printf("ERROR while me4000AOWrapAround():%s\n", errStr);
		    exit(1);
		}
	    }

	    printf("Start synchronous conversion.\n");
	    err = me4000AOStartSynchronous(
		    board,
		    channels,
		    4,
		    trigger,
		    enable,
		    edges,
		    timeout);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000AOStartSynchronous():%s\n", errStr);
		exit(1);
	    }
	}
	else{ // Continuous
	    unsigned long count = ME4000_AO_BUFFER_COUNT + ME4000_AO_FIFO_COUNT + 64;
	    int k;

	    values = malloc(count * sizeof(unsigned short));
	    if(!values){
		perror("Cannot get buffer for output values");
		exit(1);
	    }
	    memset(values, 0, count * sizeof(unsigned short));

	    for(k = 0; k < count; k = k + 2){
		values[k] = 0xFFFF;
	    }

	    for(i = 0; i < 4; i++){
		printf("Prepare continuous conversion on analog output %d.\n", i);
		err = me4000AOContinuous(
			board,
			i,
			values, 
			count, 
			ME4000_POINTER_NOT_USED,
			ME4000_POINTER_NOT_USED,
			0,
			&written[i]);
		if(err){
		    me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		    printf("ERROR while me4000AOContinuous():%s\n", errStr);
		    exit(1);
		}
	    }

	    printf("Start synchronous conversion.\n");
	    err = me4000AOStartSynchronous(
		    board,
		    channels,
		    4,
		    trigger,
		    enable,
		    edges,
		    timeout);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000AOStartSynchronous():%s\n", errStr);
		exit(1);
	    }

	    for(i = 0; i < 4; i++){
		printf("Append remaining %lu values on analog output %d.\n", count - written[i], i);
		err = me4000AOAppendNewValues(
			board,
			i,
			&values[written[i]],
			count - written[i],
			ME4000_AO_APPEND_NEW_VALUES_BLOCKING,
			&written[i]);
		if(err){
		    me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		    printf("ERROR while me4000AOAppendNewValues():%s\n", errStr);
		    exit(1);
		}
	    }
	}
    }
    else{
	for(i = 0; i < 4; i++){
	    printf("Reset analog output %d.\n", i);
	    err = me4000AOReset(board, i);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000AOReset():%s\n", errStr);
		exit(1);
	    }
	}
    }

    for(i = 0; i < 4; i++){
	printf("Close analog output %d\n", i);
	err = me4000AOClose(board, i);
	if(err){
	    me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR while me4000AOClose():%s\n", errStr);
	    exit(1);
	}
    }

    return 0;
}
