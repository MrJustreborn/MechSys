#include <unistd.h>
#include <stdio.h>
#include <ctype.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"



void usage(void){
    printf("aoTimer - Program to test the timer controlled analog output\n\n");
    printf("Usage: aoTimer [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-b <board number>      Use <board number> board (Default 0).\n");
    printf("-l <line number>       Use <line number> analog output (Default 0).\n");
    printf("-m <mode>              Sets the conversion mode to either 'WRAPAROUND',\n");
    printf("                       'CONTINUOUS' or 'RESET' (Default 'WRAPAROUND').\n");
    printf("-t <trigger>           Sets the trigger to either 'SOFTWARE' or external 'RISING',\n");
    printf("                       'FALLING' or 'BOTH' edges (Default 'SOFTWARE').\n");
    printf("-o <timeout>           Timeout when external trigger is used (Default 0).\n");
    printf("-i <interval>          Time interval between two successive values (Default 1E-3).\n");
}



int main(int argc, char *argv[]){
    int err;
    char errStr[256] = {0};
    int c;
    unsigned int board = 0;
    unsigned int line = 0;
    int mode = ME4000_AO_CONV_MODE_WRAPAROUND;
    int trigger = ME4000_AO_TRIGGER_SOFTWARE;
    int edge = ME4000_AO_TRIGGER_EXT_EDGE_RISING;
    unsigned long sample = 33000;
    unsigned long timeout = 0;
    int reset = 0;

    unsigned short *values;

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "hb:m:t:i:o:l:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 'b':
		board = atoi(optarg);
		break;
	    case 'l':
		line = atoi(optarg);
		break;
	    case 'm':
		if(!strcmp(optarg, "WRAPAROUND")){
		    mode = ME4000_AO_CONV_MODE_WRAPAROUND;
		}
		else if(!strcmp(optarg, "CONTINUOUS")){
		    mode = ME4000_AO_CONV_MODE_CONTINUOUS;
		}
		else if(!strcmp(optarg, "RESET")){
		    mode = ME4000_AO_CONV_MODE_WRAPAROUND;
		    reset = 1;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-c'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 't':
		if(!strcmp(optarg, "SOFTWARE")){
		    trigger = ME4000_AO_TRIGGER_SOFTWARE;
		}
		else if (!strcmp(optarg, "RISING")){
		    trigger = ME4000_AO_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_AO_TRIGGER_EXT_EDGE_RISING;
		}
		else if (!strcmp(optarg, "FALLING")){
		    trigger = ME4000_AO_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_AO_TRIGGER_EXT_EDGE_FALLING;
		}
		else if (!strcmp(optarg, "BOTH")){
		    trigger = ME4000_AO_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_AO_TRIGGER_EXT_EDGE_BOTH;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-t'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 'i':
		{
		    unsigned long high;
		    double achieved;
		    double freq = atof(optarg);
		    err = me4000TimeToTicks(freq, &sample, &high, &achieved);
		    if(err){
			me4000ErrorGetLastMessage(errStr, sizeof(errStr));
			fprintf(stderr, "ERROR while me4000TimeToTicks():%s\n", errStr);
			exit(1);
		    }
		}
		break;
	    case 'o':
		timeout = atoi(optarg);
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    printf("Open analog output %d on board %d\n", line, board);
    err = me4000AOOpen(board, line, mode);
    if(err){
	me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	fprintf(stderr, "ERROR while me4000AOOpen():%s\n", errStr);
	exit(1);
    }

    if(reset == 0){
	printf("Stop any previously started conversion.\n");
	err = me4000AOStop(board, line, ME4000_AO_STOP_MODE_IMMEDIATE);
	if(err){
	    me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	    printf("ERROR while me4000AOStop():%s\n", errStr);
	    exit(1);
	}

	printf("Configure analog output.\n");
	err = me4000AOConfig(
		board, 
		line,
		sample, 
		trigger, 
		edge);
	if(err){
	    me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	    printf("ERROR while me4000AOConfig():%s\n", errStr);
	    exit(1);
	}

	if(mode == ME4000_AO_CONV_MODE_WRAPAROUND){ // Wraparound
	    values = malloc(2 * sizeof(unsigned short));
	    if(!values){
		perror("Cannot get buffer for output values");
		exit(1);
	    }
	    values[0] = 0x00;
	    values[1] = 0xFFFF;

	    printf("Write values for wraparound conversion.\n");
	    err = me4000AOWraparound(
		    board, 
		    line,
		    values, 
		    2, 
		    ME4000_AO_WRAPAROUND_INFINITE,
		    ME4000_AO_WRAPAROUND_ASYNCHRONOUS,
		    ME4000_POINTER_NOT_USED,
		    ME4000_POINTER_NOT_USED,
		    timeout);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000AOWrapAround():%s\n", errStr);
		exit(1);
	    }

	    printf("Start conversion.\n");
	    err = me4000AOStart(board, line);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000AOStart():%s\n", errStr);
		exit(1);
	    }
	}
	else{ // Continuous
	    unsigned long written = 0;
	    unsigned long count = ME4000_AO_BUFFER_COUNT + ME4000_AO_FIFO_COUNT + 64;
	    int k;

	    values = malloc(count * sizeof(unsigned short));
	    if(!values){
		perror("Cannot get buffer for output values");
		exit(1);
	    }
	    memset(values, 0, count * sizeof(unsigned short));

	    for(k = 0; k < count; k = k + 2){
		values[k] = 0xFFFF;
	    }

	    printf("Prepare for continuous conversion.\n");
	    err = me4000AOContinuous(
		    board,
		    line,
		    values, 
		    count, 
		    ME4000_POINTER_NOT_USED,
		    ME4000_POINTER_NOT_USED,
		    timeout,
		    &written);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000AOContinuous():%s\n", errStr);
		exit(1);
	    }

	    printf("Start conversion.\n");
	    err = me4000AOStart(board, line);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000AOStart():%s\n", errStr);
		exit(1);
	    }

	    printf("Append remaining %lu values.\n", count - written);
	    err = me4000AOAppendNewValues(
		    board,
		    line,
		    &values[written],
		    count - written,
		    ME4000_AO_APPEND_NEW_VALUES_BLOCKING,
		    &written);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000AOAppendNewValues():%s\n", errStr);
		exit(1);
	    }
	}
    }
    else{
	printf("Reset analog output.\n");
	err = me4000AOReset(board, line);
	if(err){
	    me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	    printf("ERROR while me4000AOReset():%s\n", errStr);
	    exit(1);
	}
    }

    printf("Close analog output\n");
    err = me4000AOClose(board, line);
    if(err){
	me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	fprintf(stderr, "ERROR while me4000AOClose():%s\n", errStr);
	exit(1);
    }

    return 0;
}

