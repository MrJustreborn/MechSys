#include <unistd.h>
#include <stdio.h>
#include <ctype.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"



void usage(void){
    printf("cntSingle - Program to test a single counter\n\n");
    printf("Usage: cntSingle [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-b <number>            Use board <number> (Default is 0).\n");
    printf("-c <number>            Use counter <number>. 0 to 2 is valid (Default is 0).\n");
    printf("-m <mode>              Use 82C54 mode <mode>.\n");
    printf("                       0 to 5 is valid (Default is 3).\n");
    printf("-v <value>             Write <value> to counter (Default is 2).\n");
    printf("-r                     If set the value is read from the counter.\n");
}



int main(int argc, char *argv[]){
    int err;
    char errStr[256] = {0};
    unsigned int board = 0;
    unsigned int counter = 0;
    int hcounter;
    int mode = 3;
    int hmode;
    unsigned short value = 2;
    int read = 0;
    int c = 0;

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "hrb:c:m:v:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 'b':
		board = atoi(optarg);
		break;
	    case 'c':
		counter = atoi(optarg);
		break;
	    case 'm':
		mode = atoi(optarg);
		break;
	    case 'v':
		value = atoi(optarg);
		break;
	    case 'r':
		read = 1;
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    printf("Open counters on board %d.\n", board);
    err = me4000CntOpen(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    switch(mode){
	case 0:
	    hmode = ME4000_CNT_MODE_0;
	    break;
	case 1:
	    hmode = ME4000_CNT_MODE_1;
	    break;
	case 2:
	    hmode = ME4000_CNT_MODE_2;
	    break;
	case 3:
	    hmode = ME4000_CNT_MODE_3;
	    break;
	case 4:
	    hmode = ME4000_CNT_MODE_4;
	    break;
	case 5:
	    hmode = ME4000_CNT_MODE_5;
	    break;
	default:
	    fprintf(stderr, "ERROR: Invalid mode specified.\n");
	    usage();
	    exit(1);
    }

    switch(counter){
	case 0:
	    hcounter = ME4000_CNT_COUNTER_0;
	    break;
	case 1:
	    hcounter = ME4000_CNT_COUNTER_1;
	    break;
	case 2:
	    hcounter = ME4000_CNT_COUNTER_2;
	    break;
	default:
	    fprintf(stderr, "ERROR: Invalid counter specified.\n");
	    usage();
	    exit(1);
    }

    if(read){
	printf("Read from counter %d.\n", counter);
	err = me4000CntRead(board, hcounter, &value);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
	printf("Read %d.\n", value);
    }
    else{
	printf("Write to counter %d in mode %d value %d.\n", counter, mode, value);
	err = me4000CntWrite(board, hcounter, hmode, value);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
    }

    printf("Close counters on board %d.\n", board);
    err = me4000CntClose(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    exit(0);
}
