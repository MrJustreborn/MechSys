#include <unistd.h>
#include <stdio.h>
#include <ctype.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000net.h"
#include "../../libme4000.h"



void usage(void){
    printf("cntPWM - Program to test counters in pwm mode\n\n");
    printf("Usage: cntPWM [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-s <server address>    Use <server address> IP address to connect to\n");
    printf("-b <number>            Use board <number> (Default is 0).\n");
    printf("-p <value>             Use prescaler <value> (Default is 2).\n");
    printf("-d <value>             Use duty cycle <value> (Default is 50).\n");
    printf("-i                     If set the PWM is stopped.\n");
}



int main(int argc, char *argv[]){
    int err;
    char errStr[256] = {0};
    char *server = "127.0.0.1";
    unsigned int board = 0;
    int prescaler = 2;
    int duty = 50;
    int stop = 0;
    int c = 0;

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "his:b:p:d:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 's':
		server = optarg;
		break;
	    case 'b':
		board = atoi(optarg);
		break;
	    case 'p':
		prescaler = atoi(optarg);
		break;
	    case 'd':
		duty = atoi(optarg);
		break;
	    case 'i':
		stop = 1;
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    printf("Connect to ME-4000 server with address %s.\n", server);
    err = me4000NetConnect(server);
    if(err){
	me4000NetErrorGetMessage(err, errStr, sizeof(errStr));
	printf("%s\n", errStr);
	exit(1);
    }

    printf("Open counters on board %d.\n", board);
    err = me4000NetCntOpen(server, board);
    if(err){
	me4000NetErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    if(stop){
	printf("Stop PWM.\n");
	err = me4000NetCntPWMStop(server, board);
	if(err){
	    me4000NetErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
    }
    else{
	printf("Setup PWM with prescaler %d and duty cycle %d.\n", prescaler, duty);
	err = me4000NetCntPWMStart(server, board, prescaler, duty);
	if(err){
	    me4000NetErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
    }

    printf("Close counters on board %d.\n", board);
    err = me4000NetCntClose(server, board);
    if(err){
	me4000NetErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    printf("Shut down connection to ME-4000 server with address %s.\n", server);
    err = me4000NetDisconnect(server);
    if(err){
	me4000NetErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    exit(0);
}
