#include <unistd.h>
#include <stdio.h>
#include <ctype.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"



void usage(void){
    printf("dioByte - Program to test digital I/O\n\n");
    printf("Usage: dioByte [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-b <board number>      Use <board number> board (Default is 0).\n");
    printf("-p <port number>       Use <port number> port (Default is 0).\n");
    printf("-w <hexvalue>          Configure port for writing and write <hexvalue> to it.\n");
    printf("                       If this option is omitted the port is read.\n");
}



int main(int argc, char *argv[]){
    int err;
    char errStr[256] = {0};
    int c;
    unsigned int board = 0;
    unsigned int port = 0;
    int dir = 0; // Input
    unsigned char value = 0;

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "hb:p:w:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 'b':
		board = atoi(optarg);
		break;
	    case 'p':
		port = atoi(optarg);
		break;
	    case 'w':
		dir = 1; // Output
		if(sscanf(optarg, "%hhx", &value) != 1){
		    usage();
		    exit(2);
		}
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    printf("Open digital I/O on board %u.\n", board);
    err = me4000DIOOpen(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    if(dir){ // Output selected
	printf("Configure port %u as output port.\n", port);
	err = me4000DIOConfig(board, port, ME4000_DIO_PORT_OUTPUT);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}

	printf("Write 0x%X to digital output port\n", value);
	err = me4000DIOSetByte(board, port, value);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
    }
    else{ // Input selected
	printf("Configure port %u as input port.\n", port);
	err = me4000DIOConfig(board, port, ME4000_DIO_PORT_INPUT);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}

	printf("Read value from digital input port.\n");
	err = me4000DIOGetByte(board, port, &value);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
	printf("Value from digital input port is 0x%X.\n", value);
    }

    printf("Close digital I/O on board %u.\n", board);
    err = me4000DIOClose(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    exit(0);
}
