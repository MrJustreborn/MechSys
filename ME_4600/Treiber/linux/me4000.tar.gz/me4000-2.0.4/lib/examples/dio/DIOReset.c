#include <unistd.h>
#include <stdio.h>
#include <ctype.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"



void usage(void){
    printf("dioReset - Program to test digital I/O\n\n");
    printf("Usage: dioReset [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-b <board number>      Use <board number> board (Default is 0).\n");
}



int main(int argc, char *argv[]){
    int err;
    char errStr[256] = {0};
    int c;
    unsigned int board = 0;

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "hs:b:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 'b':
		board = atoi(optarg);
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    printf("Open digital I/O on board %u.\n", board);
    err = me4000DIOOpen(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    printf("Reset the digital I/O.\n");
    err = me4000DIOResetAll(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    printf("Close digital I/O on board %u.\n", board);
    err = me4000DIOClose(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    exit(0);
}
