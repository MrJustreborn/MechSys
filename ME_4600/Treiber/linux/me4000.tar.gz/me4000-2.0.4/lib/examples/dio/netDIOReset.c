#include <unistd.h>
#include <stdio.h>
#include <ctype.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000net.h"
#include "../../libme4000.h"



void usage(void){
	printf("dioReset - Program to test digital I/O over a network connection\n\n");
	printf("Usage: dioReset [arguments]\n\n");
	printf("Arguments:\n\n");
	printf("-h                     Print this help and exit.\n");
	printf("-s <server address>    Use <server address> IP address to connect to\n");
	printf("                       (Default is 127.0.0.1).\n");
	printf("-b <board number>      Use <board number> board (Default is 0).\n");
}



int main(int argc, char *argv[]){
	int err;
	char errStr[256] = {0};
	int c;
	char *server = "127.0.0.1";
	unsigned int board = 0;

	/* Parse the command line arguments */
	while((c = getopt(argc, argv, "hs:b:")) != -1){
		switch(c){
			case 'h':
				usage();
				exit(0);
			case 's':
				server = optarg;
				break;
			case 'b':
				board = atoi(optarg);
				break;
			default:
				usage();
				exit(2);
		}
	}

	if(optind != argc){
		fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
		usage();
		exit(2);
	}

	printf("Connect to ME-4000 server with address %s.\n", server);
	err = me4000NetConnect(server);
	if(err){
		me4000NetErrorGetMessage(err, errStr, sizeof(errStr));
		printf("%s\n", errStr);
		exit(1);
	}

	printf("Open digital I/O on board %u.\n", board);
	err = me4000NetDIOOpen(server, board);
	if(err){
		me4000NetErrorGetMessage(err, errStr, sizeof(errStr));
		fprintf(stderr, "ERROR: %s.\n", errStr);
		exit(1);
	}

	printf("Reset the digital I/O.\n");
	err = me4000NetDIOResetAll(server, board);
	if(err){
		me4000NetErrorGetMessage(err, errStr, sizeof(errStr));
		fprintf(stderr, "ERROR: %s.\n", errStr);
		exit(1);
	}

	printf("Close digital I/O on board %u.\n", board);
	err = me4000NetDIOClose(server, board);
	if(err){
		me4000NetErrorGetMessage(err, errStr, sizeof(errStr));
		fprintf(stderr, "ERROR: %s.\n", errStr);
		exit(1);
	}

	printf("Shut down connection to ME-4000 server with address %s.\n", server);
	err = me4000NetDisconnect(server);
	if(err){
		me4000NetErrorGetMessage(err, errStr, sizeof(errStr));
		fprintf(stderr, "ERROR: %s.\n", errStr);
		exit(1);
	}

	exit(0);
}
