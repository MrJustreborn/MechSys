#include <unistd.h>
#include <stdio.h>
#include <ctype.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"



void usage(void){
    printf("dioBP - Program to test the bit pattern generator\n\n");
    printf("Usage: dioBP [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-b <board number>      Use <board number> board (Default is 0).\n");
    printf("-m <mode>              Sets the conversion mode to either 'WRAPAROUND',\n");
    printf("                       'CONTINUOUS' or 'RESET' (Default is 'WRAPAROUND').\n");
    printf("-t <trigger>           Sets the trigger to either 'SOFTWARE', 'RISING' or\n");
    printf("                       'FALLING' (Default is 'SOFTWARE')\n");
    printf("-i <interval>          Time interval between two successive values (Default 1E-3).\n");
    printf("-o <timeout>           Timeout when external trigger is used (Default 0).\n");
}



int main(int argc, char *argv[]){
    int err;
    char errStr[256] = {0};
    int c;
    unsigned int board = 0;
    int mode = ME4000_DIOBP_CONV_MODE_WRAPAROUND;
    int trigger = ME4000_DIOBP_TRIGGER_SOFTWARE;
    int edge = ME4000_DIOBP_TRIGGER_EXT_EDGE_RISING;
    unsigned long sample = 33000;
    unsigned long timeout = 0;
    int reset = 0;

    unsigned short *values;

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "hb:m:t:i:o:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 'b':
		board = atoi(optarg);
		break;
	    case 'm':
		if(!strcmp(optarg, "WRAPAROUND")){
		    mode = ME4000_DIOBP_CONV_MODE_WRAPAROUND;
		}
		else if(!strcmp(optarg, "CONTINUOUS")){
		    mode = ME4000_DIOBP_CONV_MODE_CONTINUOUS;
		}
		else if(!strcmp(optarg, "RESET")){
		    mode = ME4000_DIOBP_CONV_MODE_WRAPAROUND;
		    reset = 1;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-c'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 't':
		if(!strcmp(optarg, "SOFTWARE")){
		    trigger = ME4000_DIOBP_TRIGGER_SOFTWARE;
		}
		else if (!strcmp(optarg, "RISING")){
		    trigger = ME4000_DIOBP_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_DIOBP_TRIGGER_EXT_EDGE_RISING;
		}
		else if (!strcmp(optarg, "FALLING")){
		    trigger = ME4000_DIOBP_TRIGGER_EXT_DIGITAL;
		    edge = ME4000_DIOBP_TRIGGER_EXT_EDGE_FALLING;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-t'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 'i':
		{
		    unsigned long high;
		    double achieved;
		    double freq = atof(optarg);
		    err = me4000TimeToTicks(freq, &sample, &high, &achieved);
		    if(err){
			me4000ErrorGetLastMessage(errStr, sizeof(errStr));
			fprintf(stderr, "ERROR while me4000TimeToTicks():%s\n", errStr);
			exit(1);
		    }
		}
		break;
	    case 'o':
		timeout = atoi(optarg);
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    printf("Open bit pattern generator\n");
    err = me4000DIOBPOpen(board, mode);
    if(err){
	me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	fprintf(stderr, "ERROR while me4000DIOBPOpen():%s\n", errStr);
	exit(1);
    }

    if(reset == 0){
	printf("Stop any previously started conversion.\n");
	err = me4000DIOBPStop(board, ME4000_DIOBP_STOP_MODE_IMMEDIATE);
	if(err){
	    me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	    printf("ERROR while me4000DIOBPStop():%s\n", errStr);
	    exit(1);
	}

	printf("Configure port 0 for bit pattern conversion.\n");
	err = me4000DIOBPPortConfig(
		board, 
		ME4000_DIOBP_PORT_A, 
		ME4000_DIOBP_OUTPUT_MODE_BYTE_LOW);
	if(err){
	    me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	    printf("ERROR while me4000DIOBPPortConfig():%s\n", errStr);
	    exit(1);
	}

	printf("Configure port 1 for bit pattern conversion.\n");
	err = me4000DIOBPPortConfig(
		board, 
		ME4000_DIOBP_PORT_B, 
		ME4000_DIOBP_OUTPUT_MODE_BYTE_HIGH);
	if(err){
	    me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR while me4000DIOBPPortConfig():%s\n", errStr);
	    exit(1);
	}

	printf("Configure board.\n");
	err = me4000DIOBPConfig(
		board, 
		sample, 
		trigger, 
		edge);
	if(err){
	    me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	    printf("ERROR while me4000DIOBPConfig():%s\n", errStr);
	    exit(1);
	}

	/*-------------------------------------------------------------------------
	  Prepare values
	  -----------------------------------------------------------------------*/

	if(mode == ME4000_DIOBP_CONV_MODE_WRAPAROUND){ // Wraparound
	    int i;
	    values = malloc(16 * sizeof(unsigned short));
	    if(!values){
		perror("Cannot get buffer for output values");
		exit(1);
	    }
	    for(i = 0; i < 16; i++){
		values[i] = 0x1 << i;
	    }

	    printf("Write values for wraparound conversion.\n");
	    err = me4000DIOBPWraparound(
		    board,
		    values,
		    16,
		    ME4000_DIOBP_WRAPAROUND_INFINITE,
		    ME4000_DIOBP_WRAPAROUND_ASYNCHRONOUS,
		    NULL,
		    NULL,
		    timeout);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000DIOBPWraparound():%s\n", errStr);
		exit(1);
	    }

	    printf("Start conversion.\n");
	    err = me4000DIOBPStart(board);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000DIOBPStart():%s\n", errStr);
		exit(1);
	    }
	}
	else{ // Continuous
	    unsigned long written = 0;
	    unsigned long count = ME4000_AO_BUFFER_COUNT + ME4000_AO_FIFO_COUNT + 64;
	    int i;
	    int k;

	    values = malloc(count * sizeof(unsigned short));
	    if(!values){
		perror("Cannot get buffer for output values");
		exit(1);
	    }

	    for(k = 0; k < count / 16; k++){
		for(i = 0; i < 16; i++){
		    values[i + k * 16] = 0x1 << i;
		}
	    }

	    printf("Prepare for continuous conversion.\n");
	    err = me4000DIOBPContinuous(
		    board,
		    values, 
		    count, 
		    NULL,
		    NULL,
		    timeout,
		    &written);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000DIOBPContinuous():%s\n", errStr);
		exit(1);
	    }

	    printf("Start conversion.\n");
	    err = me4000DIOBPStart(board);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000DIOBPStart():%s\n", errStr);
		exit(1);
	    }

	    printf("Append remaining %lu values.\n", count - written);
	    err = me4000DIOBPAppendNewValues(
		    board,
		    &values[written],
		    count - written,
		    ME4000_DIOBP_APPEND_NEW_VALUES_BLOCKING,
		    &written);
	    if(err){
		me4000ErrorGetLastMessage(errStr, sizeof(errStr));
		printf("ERROR while me4000DIOBPAppendNewValues():%s\n", errStr);
		exit(1);
	    }
	}
    }
    else{
	printf("Reset bit pattern generator.\n");
	err = me4000DIOBPReset(board);
	if(err){
	    me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	    printf("ERROR while me4000DIOBPReset():%s\n", errStr);
	    exit(1);
	}
    }

    printf("Close bit pattern generator.\n");
    err = me4000DIOBPClose(board);
    if(err){
	me4000ErrorGetLastMessage(errStr, sizeof(errStr));
	printf("ERROR while me4000DIOBPClose():%s\n", errStr);
	exit(1);
    }

    return 0;
}
