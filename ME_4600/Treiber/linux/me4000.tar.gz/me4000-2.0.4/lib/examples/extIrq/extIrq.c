#include <unistd.h>
#include <stdio.h>
#include <ctype.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"



/* Global stuff */
volatile int i = 0;
static char *context = "External interrupt occured\n";
unsigned int board = 0;


void callback(void *context){
    char *text;
    unsigned int count;

    text = context;
    printf("%s", text);
    me4000ExtIrqGetCount(board, &count);
    printf("Interrupt count = %u\n", count);
    i++;
}


void usage(void){
    printf("extIrq - Program to test the external interrupt\n\n");
    printf("Usage: extIrq [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-b <board number>      Use <board number> board (Default is 0).\n");
    printf("-c <interrupt count>   Wait for <interrupt count> interrupts (Default 8).\n");
}



int main(int argc, char *argv[]){
    int err;
    char errStr[256] = {0};
    int c;
    int intCount = 8;

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "hb:c:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 'b':
		board = atoi(optarg);
		break;
	    case 'c':
		intCount = atoi(optarg);
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    /*-------------------------------------------------------------------------
       Open the external interrupt
      -----------------------------------------------------------------------*/

    printf("Open external interrupt on board %d\n", board);
    err = me4000ExtIrqOpen(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    /*-------------------------------------------------------------------------
      Enable external interrupt
      -----------------------------------------------------------------------*/

    printf("Enable external interrupt on board %d\n", board);
    err = me4000ExtIrqEnable(
	    board, 
	    callback, 
	    context);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    while(i < intCount);

    /*-------------------------------------------------------------------------
      Disable external interrupt
      -----------------------------------------------------------------------*/

    printf("Disable external interrupt on board %d\n", board);
    err = me4000ExtIrqDisable(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    /*-------------------------------------------------------------------------
      Close the external interrupt
      -----------------------------------------------------------------------*/

    printf("Close external interrupt on board %d.\n", board);
    err = me4000ExtIrqClose(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    return 0;
}
