#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <time.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"


void usage(void){
    printf("extIrq - Program to test the external interrupt\n\n");
    printf("Usage: extIrq [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-b <board number>      Use <board number> board (Default is 0).\n");
    printf("-m <multiSig>          Use <multiSig number> board (Default is 0).\n");
    printf("-g <group>             Use <group number> board. Either GROUP_A or GROUP_B (Default GROUP_A).\n");
    printf("-v <gain>              Use <gain> gain. Either GAIN_1, GAIN_10 or GAIN_100 (Default GAIN_1).\n");
    printf("-r                     Reset the MulitSig boards.\n");
}


int main(int argc, char *argv[]){
    int err;
    char errStr[256] = {0};
    int c;
    unsigned int board = 0;
    unsigned int multiSig = 0;
    unsigned int group = ME4000_MULTISIG_GROUP_A;
    unsigned int gain = ME4000_MULTISIG_GAIN_1;
    int reset = 0;

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "hrb:m:g:v:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 'b':
		board = atoi(optarg);
		break;
	    case 'm':
		multiSig = atoi(optarg);
		break;
	    case 'r':
		reset = 1;
		break;
	    case 'g':
		if(!strcmp(optarg, "GROUP_A")){
		    group = ME4000_MULTISIG_GROUP_A;
		}
		else if (!strcmp(optarg, "GROUP_B")){
		    group = ME4000_MULTISIG_GROUP_B;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-g'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 'v':
		if(!strcmp(optarg, "GAIN_1")){
		    gain = ME4000_MULTISIG_GAIN_1;
		}
		else if (!strcmp(optarg, "GAIN_10")){
		    gain = ME4000_MULTISIG_GAIN_10;
		}
		else if (!strcmp(optarg, "GAIN_100")){
		    gain = ME4000_MULTISIG_GAIN_100;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-g'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    printf("Open MultiSig facility on board %d\n", board);
    err = me4000MultiSigOpen(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    if(reset){
	printf("Reset MultiSig board\n");
	err = me4000MultiSigReset(board);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
    }
    else{
	printf("Set address LED on MultiSig board\n");
	err = me4000MultiSigAddressLED(
		board, 
		multiSig, 
		ME4000_MULTISIG_LED_ON);

	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}

	sleep(2);

	printf("Reset address LED on MultiSig board\n");
	err = me4000MultiSigAddressLED(
		board, 
		multiSig, 
		ME4000_MULTISIG_LED_OFF);

	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}

	printf("Set gain on MultiSig board\n");
	err = me4000MultiSigSetGain(
		board, 
		multiSig, 
		group, 
		gain);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
    }

    printf("Close MultiSig facility.\n");
    err = me4000MultiSigClose(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    return 0;
}
