#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <time.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"


void usage(void){
    printf("multiSigAI - Program to test the multiSigAI facility\n\n");
    printf("Usage: multiSigAI [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-b <board number>      Use <board number> board (Default 0).\n");
    printf("-c <multiSig count>    Count of multiSig boards (Default 1).\n");
    printf("-v <gain>              Use <gain> gain. Either GAIN_1, GAIN_10 or GAIN_100 (Default GAIN_1).\n");
    printf("-i <interval>          Interval between two successive samples (Default 1E-3).\n");  
    printf("-r                     Reset the MulitSig boards.\n");
}


int main(int argc, char *argv[]){
    int err;
    char errStr[256] = {0};
    int c;
    int i;
    unsigned int board = 0;
    unsigned msCount = 1;
    unsigned int gain = ME4000_MULTISIG_GAIN_1;
    int acqMode = ME4000_AI_ACQ_MODE_SOFTWARE;
    int trigger = ME4000_AI_TRIGGER_SOFTWARE;
    int edge = ME4000_AI_TRIGGER_EXT_EDGE_BOTH;
    unsigned long timeout = 0;
    int reset = 0;
    unsigned char *pucMuxChanList = NULL;
    short *psBuffer = NULL;
    double *pdVoltage = NULL;
    unsigned int channels = 32;
    unsigned long ticks = 33000;
    unsigned long hTicks;
    double interval = 1E-3;

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "hrb:c:v:i:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 'b':
		board = atoi(optarg);
		break;
	    case 'r':
		reset = 1;
		break;
	    case 'c':
		msCount = atoi(optarg);
		break;
	    case 'v':
		if(!strcmp(optarg, "GAIN_1")){
		    gain = ME4000_MULTISIG_GAIN_1;
		}
		else if (!strcmp(optarg, "GAIN_10")){
		    gain = ME4000_MULTISIG_GAIN_10;
		}
		else if (!strcmp(optarg, "GAIN_100")){
		    gain = ME4000_MULTISIG_GAIN_100;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-v'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 'i':
		interval = atof(optarg);
		err = me4000TimeToTicks(interval, &ticks, &hTicks, ME4000_POINTER_NOT_USED);
		if(err){
		    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
		    fprintf(stderr, "ERROR: %s.\n", errStr);
		    exit(1);
		}
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    channels = msCount * 32;

    printf("Open MultiSig facility on board %d.\n", board);
    err = me4000MultiSigOpen(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    printf("Reset MultiSig board.\n");
    err = me4000MultiSigReset(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    for(i = 0; i < msCount; i++){
	printf("Set gain on MultiSig board %d for channel group A.\n", i);
	err = me4000MultiSigSetGain(
		board, 
		i, 
		ME4000_MULTISIG_GROUP_A, 
		gain);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}

	printf("Set gain on MultiSig board %d for channel group B.\n", i);
	err = me4000MultiSigSetGain(
		board, 
		i, 
		ME4000_MULTISIG_GROUP_B, 
		gain);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
    }

    printf("Close MultiSig facility on board %d.\n", board);
    err = me4000MultiSigClose(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    printf("Open MultiSigAI facility on board %d.\n", board);
    err = me4000MultiSigAIOpen(board, acqMode);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    pucMuxChanList = malloc(sizeof(unsigned short) * channels);
    for(i = 0; i < channels; i++){
	pucMuxChanList[i] = i;
    }

    printf("Configure MultiSigAI hardware\n");
    err = me4000MultiSigAIConfig(
	    board,
	    0,
	    pucMuxChanList, 
	    channels, 
	    ME4000_VALUE_NOT_USED, 
	    ticks, 
	    0, 
	    0, 
	    ME4000_VALUE_NOT_USED, 
	    trigger,
	    edge);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    psBuffer = malloc(sizeof(short) * channels);
    if(!psBuffer){
	perror("Cannot get buffer for data");
	exit(1);
    }

    printf("Prepare for scan acquisition\n");
    err = me4000MultiSigAIScan(
	    board,
	    ME4000_VALUE_NOT_USED, // Never used in Linux
	    psBuffer, 
	    channels,
	    ME4000_AI_SCAN_BLOCKING, 
	    ME4000_POINTER_NOT_USED, 
	    ME4000_POINTER_NOT_USED, 
	    ME4000_VALUE_NOT_USED,
	    ME4000_POINTER_NOT_USED, 
	    ME4000_POINTER_NOT_USED, 
	    timeout);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    printf("Start conversion\n");
    err = me4000MultiSigAIStart(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    pdVoltage = malloc(sizeof(short) * channels);
    if(!pdVoltage){
	perror("Cannot get buffer for voltage");
	exit(1);
    }

    for(i = 0; i < channels; i++){
	err = me4000MultiSigAIDigitToSize(
		psBuffer[i], 
		gain, 
		ME4000_MULTISIG_MODULE_NONE, 
		ME4000_VALUE_NOT_USED, 
		&pdVoltage[i]);
	if(err){
	    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	    fprintf(stderr, "ERROR: %s.\n", errStr);
	    exit(1);
	}
	printf("Value %d: %.4f Volts | %05hi Digits\n", i, pdVoltage[i], psBuffer[i]);
    }

    printf("Close MultiSigAi facility\n");
    err = me4000MultiSigAIClose(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    return 0;
}
