#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <time.h>


/* This must be included in order
   to have access to the ME-4000
   specific definitions */
#include "../../libme4000.h"


void usage(void){
    printf("multiSigAO - Program to test the multiSigAO facility\n\n");
    printf("Usage: multiSigAO [arguments]\n\n");
    printf("Arguments:\n\n");
    printf("-h                     Print this help and exit.\n");
    printf("-b <board number>      Use <board number> board (Default 0).\n");
    printf("-c <multiSig count>    Count of multiSig boards (Default 1).\n");
    printf("-v <gain>              Use <gain> gain. Either GAIN_1, GAIN_10 or GAIN_100 (Default GAIN_1).\n");
    printf("-i <interval>          Interval between two successive samples (Default 1E-3).\n");  
    printf("-r                     Reset the MulitSig boards.\n");
}


int main(int argc, char *argv[]){
    int err;
    char errStr[256] = {0};
    int c;
    int i;
    unsigned int board = 0;
    unsigned msCount = 1;
    unsigned int gain = ME4000_MULTISIG_GAIN_1;
    int trigger = ME4000_AI_TRIGGER_SOFTWARE;
    int edge = ME4000_AI_TRIGGER_EXT_EDGE_BOTH;
    unsigned long timeout = 0;
    int reset = 0;
    unsigned char *pucDemuxChanList = NULL;
    short *pusBuffer = NULL;
    unsigned int channels = 32;
    unsigned long ticks = 33000;
    unsigned long hTicks;
    double interval = 1E-3;

    /* Parse the command line arguments */
    while((c = getopt(argc, argv, "hrb:c:v:i:")) != -1){
	switch(c){
	    case 'h':
		usage();
		exit(0);
	    case 'b':
		board = atoi(optarg);
		break;
	    case 'r':
		reset = 1;
		break;
	    case 'c':
		msCount = atoi(optarg);
		break;
	    case 'v':
		if(!strcmp(optarg, "GAIN_1")){
		    gain = ME4000_MULTISIG_GAIN_1;
		}
		else if (!strcmp(optarg, "GAIN_10")){
		    gain = ME4000_MULTISIG_GAIN_10;
		}
		else if (!strcmp(optarg, "GAIN_100")){
		    gain = ME4000_MULTISIG_GAIN_100;
		}
		else{
		    fprintf(stderr, "%s: Invalid option argument for option '-v'.\n", argv[0]);
		    usage();
		    exit(2);
		}
		break;
	    case 'i':
		interval = atof(optarg);
		err = me4000TimeToTicks(interval, &ticks, &hTicks, ME4000_POINTER_NOT_USED);
		if(err){
		    me4000ErrorGetMessage(err, errStr, sizeof(errStr));
		    fprintf(stderr, "ERROR: %s.\n", errStr);
		    exit(1);
		}
		break;
	    default:
		usage();
		exit(2);
	}
    }

    if(optind != argc){
	fprintf(stderr, "%s: No non option arguments are supported.\n", argv[0]);
	usage();
	exit(2);
    }

    channels = msCount * 32;

    printf("Open MultiSigAO facility on board 0\n");
    err = me4000MultiSigAOOpen(board, ME4000_AO_CONV_MODE_WRAPAROUND);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    printf("Stop any previously started conversion\n");
    err = me4000MultiSigAOStop(board, ME4000_AO_STOP_MODE_IMMEDIATE);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    pucDemuxChanList = malloc(sizeof(unsigned short) * channels);
    if(!pucDemuxChanList){
	fprintf(stderr, "ERROR: Cannot get chan list buffer.\n");
	exit(1);
    }

    for(i = 0; i < channels; i++){
	pucDemuxChanList[i] = i;
    }

    printf("Configure MultiSigAO\n");
    err = me4000MultiSigAOConfig(
	    board, 
	    pucDemuxChanList, 
	    channels,
	    ticks, 
	    trigger,
	    edge);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    pusBuffer = malloc(sizeof(unsigned short) * channels);
    for(i = 0; i < channels; i++){
	pusBuffer[i] = 0xFFFF;
    }

    printf("Prepare for wraparound\n");
    err = me4000MultiSigAOWraparound(
	    board,
	    pusBuffer, 
	    channels, 
	    ME4000_AO_WRAPAROUND_INFINITE,
	    ME4000_AO_WRAPAROUND_ASYNCHRONOUS,
	    ME4000_POINTER_NOT_USED,
	    ME4000_POINTER_NOT_USED,
	    timeout);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    printf("Start wraparound\n");
    err = me4000MultiSigAOStart(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    printf("Close MultiSigAO facility\n");
    err = me4000MultiSigAOClose(board);
    if(err){
	me4000ErrorGetMessage(err, errStr, sizeof(errStr));
	fprintf(stderr, "ERROR: %s.\n", errStr);
	exit(1);
    }

    return 0;
}
