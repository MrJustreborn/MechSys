/* API for Meilhaus ME-4000 board family.
 * ======================================
 *
 *  Copyright (C) 2004 Meilhaus Electronic GmbH (support@meilhaus.de)
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Author:	Guenter Gebhardt	<g.gebhardt@meilhaus.de>
 */


#include <syslog.h>
#include <libme4000.h>
#include <libme4000_error.h>
#include <pt_100.h>
#include <te_type_b.h>
#include <te_type_e.h>
#include <te_type_j.h>
#include <te_type_k.h>
#include <te_type_n.h>
#include <te_type_r.h>
#include <te_type_s.h>
#include <te_type_t.h>


/* Init and exit of the shared object */
void _init(void);
void _fini(void);


#define ME4000_DLL_VERSION 0x20002


/* Global error number */
static int my_errno = 0;

/* Stores the system error message after a ERROR_NO_SYSTEM */
static char sysErrMsg[256];

/* Flag for default error function */
static int errorDefaultProcFlag = 0;

/* Pointer to user defined error function */
static ME4000_P_ERROR_PROC errorUserProcPtr = NULL;

/* Holds the number of the detected boards */
static int board_count = 0;


/* Holds the driver version */
static unsigned long driver_version = 0;


typedef struct me4000_adjust {
	unsigned long date;
	double a_uni_10;
	double b_uni_10;
	double a_uni_2_5;
	double b_uni_2_5;
	double a_bi_10;
	double b_bi_10;
	double a_bi_2_5;
	double b_bi_2_5;
	double a_diff_10;
	double b_diff_10;
	double a_diff_2_5;
	double b_diff_2_5;
} me4000_adjust_t;


typedef struct me4000AIContext{
	int fd;
	pthread_t thread;
	unsigned long ulChannelListCount;
	short *psAIBuffer;
	unsigned long ulAIBufferCount;
	int iExecutionMode;
	int iAcqMode;
	ME4000_P_AI_CALLBACK_PROC pCallback;
	void *pCallbackContext;
	unsigned long ulRefreshFrequency;
	ME4000_P_AI_CALLBACK_PROC pTerminateFunc;
	void *pTerminateContext;
	unsigned long ulTimeOutSeconds;
	me4000_adjust_t adjust_table;
	me4000_adjust_t adjust_table_sh;
	int ai_count;
	int ai_sh_count;
	int ai_ex_trig_analog;
	unsigned short device_id; // In order to detect a ME-4610
} me4000AIContext_t;


typedef struct me4000AOContext{
	int fd;
	unsigned long ulTimeOutSeconds;
	pthread_t thread;
	ME4000_P_AO_CALLBACK_PROC pCallback;
	void *pCallbackContext;
} me4000AOContext_t;


typedef struct me4000DIOContext{
	int fd;
} me4000DIOContext_t;


typedef struct me4000CntContext{
	int fd;
} me4000CntContext_t;


typedef struct me4000ExtIrqContext{
	int fd;
	ME4000_P_EXT_IRQ_PROC pCallback;
	void *pCallbackContext;
} me4000ExtIrqContext_t;


typedef struct me4000DIOBPContext{
	me4000DIOContext_t dioContext;
	me4000AOContext_t aoContext;
} me4000DIOBPContext_t;


typedef struct me4000MultiSigContext{
	me4000DIOContext_t dioContext;
} me4000MultiSigContext_t;


typedef struct me4000MultiSigAIContext{
	me4000DIOContext_t dioContext;
	me4000AIContext_t aiContext;
	me4000AOContext_t aoContext;
} me4000MultiSigAIContext_t;


typedef struct me4000MultiSigAOContext{
	me4000DIOContext_t dioContext;
	me4000AOContext_t aoContext_0;
	me4000AOContext_t aoContext_3;
} me4000MultiSigAOContext_t;


typedef struct me4000BoardContext {
	me4000AIContext_t aiContext;
	me4000AOContext_t aoContext[4];
	me4000DIOContext_t dioContext;
	me4000CntContext_t cntContext;
	me4000ExtIrqContext_t extIntContext;
	me4000DIOBPContext_t diobpContext;
	me4000MultiSigContext_t multiSigContext;
	me4000MultiSigAIContext_t multiSigAIContext;
	me4000MultiSigAOContext_t multiSigAOContext;
	DEVICEINFOSTRUCT devInfo;
} me4000BoardContext_t;

static me4000BoardContext_t boardContextVec[4];


static char *errorTable[1024] = {
	ERROR_STR_SUCCESS,
	ERROR_STR_UNSPECIFIED,
	ERROR_STR_INVALID_FREQUENCY,
	ERROR_STR_INVALID_TIME,
	ERROR_STR_INVALID_BOARD,
	ERROR_STR_INVALID_ACQ_MODE,
	ERROR_STR_NOT_OPEN,
	ERROR_STR_INVALID_CHANNEL,
	ERROR_STR_INVALID_RANGE,
	ERROR_STR_INVALID_SDMODE,
	ERROR_STR_INVALID_TRIGGER_MODE,
	ERROR_STR_INVALID_CHANLIST,
	ERROR_STR_INITIAL_TICKS,
	ERROR_STR_CHAN_TICKS,
	ERROR_STR_SCAN_TICKS,
	ERROR_STR_INVALID_TRIGGER_EDGE,
	ERROR_STR_REFRESH_FREQUENCY,
	ERROR_STR_CALLBACK_USED,
	ERROR_STR_INVALID_EXEC_MODE,
	ERROR_STR_START_THREAD,
	ERROR_STR_CANCEL_THREAD,
	ERROR_STR_INVALID_PORT,
	ERROR_STR_INVALID_PORT_MODE,
	ERROR_STR_INVALID_BIT,
	ERROR_STR_INVALID_CONV_MODE,
	ERROR_STR_INVALID_STOP_MODE,
	ERROR_STR_INVALID_PORT_FUNCTION,
	ERROR_STR_INVALID_MULTI_SIG_BASE,
	ERROR_STR_INVALID_MULTI_SIG_IDENT,
	ERROR_STR_INVALID_MULTI_SIG_GAIN,
	ERROR_STR_INVALID_MULTI_SIG_GROUP,
	ERROR_STR_SIMULTANEOUS,
	ERROR_STR_SIMULTANEOUS_CHAN,
	ERROR_STR_INVALID_SHAPE,
	ERROR_STR_INVALID_AMPLITUDE,
	ERROR_STR_INVALID_OFFSET,
	ERROR_STR_AMPLITUDE_OFFSET,
	ERROR_STR_INVALID_COUNTER,
	ERROR_STR_INVALID_DUTY_CYCLE,
	ERROR_STR_INVALID_COUNTER_MODE,
	ERROR_STR_BUSY,
	ERROR_STR_INVALID_OUTPUT_MODE,
	ERROR_STR_INVALID_MULTI_SIG_MODULE_TYPE,
	ERROR_STR_INVALID_ERROR_NO,
	ERROR_STR_ERROR_BUFFER_TO_LITTLE,
	ERROR_STR_NO_SAMPLE_HOLD,
	ERROR_STR_NO_DIFF,
	ERROR_STR_NO_ANALOG,
	ERROR_STR_INVALID_ADJUSTMENT,
	ERROR_STR_INVALID_MUX_CHANNEL,
	ERROR_STR_INVALID_LOOPS,
	ERROR_STR_TEMP_RANGE
};



/* Local functions */
static void * me4000AIContAsync(void *arg);
static int contMeasurement(me4000AIContext_t *context);
static void * me4000AIScanAsync(void *arg);
static int scanMeasurement(me4000AIContext_t *context);

static double me4000MultiSigCalcTemp(double resistance, int iIMeasured);


/*============================================================================= 
  Internal general purpose functions
  ===========================================================================*/

static int opto_isolated(unsigned long ulBoardNumber);


/*============================================================================= 
  Internal error functions
  ===========================================================================*/

static int storeSystemError(int error);
static void errorDefaultProc(char *function, int iErrorCode);


/*============================================================================= 
  Internal external interrupt functions
  ===========================================================================*/

static int ExtIrqCheckBoard(unsigned int uiBoardNumber);
static int ExtIrqCheckBoardFD(unsigned int uiBoardNumber);
static void ExtIrqHandler(int sig);


/*============================================================================= 
  Internal AI functions
  ===========================================================================*/

static int AICheckBoard(unsigned int uiBoardNumber);
static int AICheckBoardFD(unsigned int uiBoardNumber);
static int AIOpen(me4000AIContext_t *aiContext, unsigned int uiBoardNumber, int iAcqMode);
static int AIClose(me4000AIContext_t *aiContext);
static int AIConfig(
		me4000AIContext_t *aiContext,
		unsigned char *pucChanList, 
		unsigned int uiChanListCount, 
		int iSDMode, 
		int iSimultaneous,
		unsigned long ulReserved,
		unsigned long ulChanTicks, 
		unsigned long ulScanTicksLow, 
		unsigned long ulScanTicksHigh, 
		int iExtTriggerMode, 
		int iExtTriggerEdge);
static int AIContinuous(
		me4000AIContext_t *aiContext,
		ME4000_P_AI_CALLBACK_PROC pCallbackProc, 
		void *pCallbackContext, 
		unsigned int uiRefreshFrequency,
		unsigned long ulTimeOutSeconds);
static int AIGetNewValues(
		me4000AIContext_t *aiContext,
		short *psBuffer, 
		unsigned long ulNumberOfValuesToRead,
		int iExecutionMode,
		unsigned long *pulNumberOfValuesRead,
		int *piLastError);
static int AIGetStatus(
		me4000AIContext_t *aiContext,
		int iWaitIdle,
		int *piStatus);
int AIScan(
		me4000AIContext_t *aiContext,
		unsigned int uiNumberOfChanLists,
		short *psBuffer, 
		unsigned long ulBufferSizeValues,
		int iExecutionMode, 
		ME4000_P_AI_CALLBACK_PROC pCallbackProc, 
		void *pCallbackContext, 
		unsigned int uiRefreshFrequency,
		ME4000_P_AI_TERMINATE_PROC pTerminateProc, 
		void *pTerminateContext, 
		unsigned long ulTimeOutSeconds);
static int AISingle(
		me4000AIContext_t *aiContext,
		unsigned int uiChannelNumber,
		int iRange, 
		int iSDMode, 
		int iTriggerMode,
		int iExtTriggerEdge, 
		unsigned long ulTimeOutSeconds, 
		short *psDigitalValue);
static int AIStart(me4000AIContext_t *aiContext);
static int AIStop(me4000AIContext_t *aiContext);


/*============================================================================= 
  Internal AO functions
  ===========================================================================*/

static int AOCheckBoardChannel(unsigned int uiBoardNumber, unsigned int uiChannelNumber);
static int AOCheckBoardChannelFD(unsigned int uiBoardNumber, unsigned int uiChannelNumber);
static int AOOpen(me4000AOContext_t *aoContext, unsigned int uiBoardNumber, unsigned int uiChannelNumber, int iMode);
static int AOClose(me4000AOContext_t *aoContext);
static int AOConfig(me4000AOContext_t *aoContext, unsigned long ulTicks, int iTriggerMode, int iExtTriggerEdge);
static int AOContinuous(
		me4000AOContext_t *aoContext,
		unsigned short *pusBuffer, 
		unsigned long ulBufferCount, 
		ME4000_P_AO_CALLBACK_PROC pCallback,
		void *pCallbackContext,
		unsigned long ulTimeOutSeconds,
		unsigned long *pulNumberOfValuesWritten);
static int AOAppendNewValues(
		me4000AOContext_t *aoContext,
		unsigned short *pusBuffer, 
		unsigned long ulBufferCount, 
		int iExecutionMode,
		unsigned long *pulNumberOfValuesAppended);
static int AOGetStatus(me4000AOContext_t *aoContext, int iWaitIdle, int *piStatus);
static int AOReset(me4000AOContext_t *aoContext);
static int AOSingle(
		me4000AOContext_t *aoContext,
		int iTriggerMode,
		int iExtTriggerEdge,
		unsigned long ulTimeOutSeconds,
		unsigned short usValue);
static int AOStart(me4000AOContext_t *aoContext);
static void *AOContinuousAsync(void *arg);
static int AOSetTimer(me4000AOContext_t *aoContext, unsigned long ulTicks);
static int AOStop(me4000AOContext_t *aoContext, int iStopMode);
static int AOSingleSimultaneous(
		me4000AOContext_t *aoContext,
		int iTriggerMode,
		int iExtTriggerEnable,
		int iExtTriggerEdge,
		unsigned short usValue);
static int AOSingleSimultaneousSoftware(me4000AOContext_t *aoContext, me4000_ao_channel_list_t chanlist);
static int AOSingleSimultaneousTimeout(me4000AOContext_t *aoContext, unsigned long timeout);
static int AOStartSynchronous(
		me4000AOContext_t *aoContext,
		int iTriggerMode, 
		int iExtTriggerEnable,
		int iExtTriggerEdge);
static int AOStartSynchronousSoftware(me4000AOContext_t *aoContext);
static int AOStartSynchronousTimeout(me4000AOContext_t *aoContext, unsigned long ulTimeOutSeconds);
static int AOWraparound(
		me4000AOContext_t *aoContext,
		unsigned short *pusBuffer, 
		unsigned long ulDataCount, 
		unsigned long ulTimeOutSeconds);


/*============================================================================= 
  Internal DIOBP functions
  ===========================================================================*/

static int DIOBPCheckBoard(unsigned int uiBoardNumber);
static int DIOBPCheckBoardFD(unsigned int uiBoardNumber);


/*============================================================================= 
  Internal DIO functions
  ===========================================================================*/

static int DIOCheckBoard(unsigned int uiBoardNumber);
static int DIOCheckBoardFD(unsigned int uiBoardNumber);
static int DIOOpen(me4000DIOContext_t *dioContext, unsigned int uiBoardNumber);
static int DIOClose(me4000DIOContext_t *dioContext);
static int DIOConfig(me4000DIOContext_t *dioContext, unsigned int uiPortNumber, int iMode, int iFunction);
static int DIOGetByte(me4000DIOContext_t *dioContext, unsigned int uiPortNumber, unsigned char *pucByteValue);
static int ResetAll(me4000DIOContext_t *dioContext);
static int DIOSetByte(me4000DIOContext_t *dioContext, unsigned int uiPortNumber, unsigned char ucByteValue);


/*============================================================================= 
  Internal counter functions
  ===========================================================================*/

static int cntCheckBoard(unsigned int uiBoardNumber);
static int cntCheckBoardFD(unsigned int uiBoardNumber);
static int cntOpen(me4000CntContext_t *cntContext, unsigned int uiBoardNumber);
static int cntClose(me4000CntContext_t *cntContext);
static int cntWrite(me4000CntContext_t *cntContext, unsigned int uiCounterNumber, int iMode, unsigned short usValue);
static int cntRead(me4000CntContext_t *cntContext, unsigned int uiCounterNumber, unsigned short *pusValue);


/*============================================================================= 
  Internal MultiSig functions
  ===========================================================================*/

static int MultiSigCheckBoard(unsigned int uiBoardNumber);
static int MultiSigCheckBoardFD(unsigned int uiBoardNumber);


/*============================================================================= 
  Internal MultiSig AI functions
  ===========================================================================*/

static int MultiSigAICheckBoard(unsigned int uiBoardNumber);
static int MultiSigAICheckBoardFD(unsigned int uiBoardNumber);


/*============================================================================= 
  Internal MultiSig AO functions
  ===========================================================================*/

static int MultiSigAOCheckBoard(unsigned int uiBoardNumber);
static int MultiSigAOCheckBoardFD(unsigned int uiBoardNumber);


/*============================================================================= 
  Initialization and cleanup of shared object
  ===========================================================================*/

void _init(void){
	me4000_user_info_t uinfo;
	int fd;
	char path[32];
	int i;
	int err;
	me4000_eeprom_t eeprom;

	/* Detect number of board available and
	   get the board information */
	for(board_count = 0; board_count < 4; board_count++){
		sprintf(path, "/dev/me4000_%d_ai_single", board_count);

		/* Analog input is always available */
		fd = open(path, O_RDWR);
		if(fd < 0) break;

		/* This should never fail */
		ioctl(fd, ME4000_GET_USER_INFO, &uinfo);

		/* Save the device info global */
		boardContextVec[board_count].devInfo.dwBoardNumber = uinfo.board_count;
		boardContextVec[board_count].devInfo.dwVendorID = uinfo.vendor_id;
		boardContextVec[board_count].devInfo.dwDeviceID = uinfo.device_id;
		boardContextVec[board_count].devInfo.dwSystemSlotNumber = uinfo.pci_dev_no;
		boardContextVec[board_count].devInfo.dwPortBase = uinfo.me4000_regbase;
		boardContextVec[board_count].devInfo.dwPortCount = uinfo.me4000_regbase_size;
		boardContextVec[board_count].devInfo.dwIntChannel = uinfo.irq;
		boardContextVec[board_count].devInfo.dwPortBasePLX = uinfo.plx_regbase;
		boardContextVec[board_count].devInfo.dwPortCountPLX = uinfo.plx_regbase_size;
		boardContextVec[board_count].devInfo.dwSerialNumber = uinfo.serial_no;
		boardContextVec[board_count].devInfo.dwBusNumber = uinfo.pci_bus_no;
		boardContextVec[board_count].devInfo.dwHWRevision = uinfo.hw_revision;
		boardContextVec[board_count].devInfo.dwIrqCnt = 0;
		boardContextVec[board_count].devInfo.dwVersion = uinfo.device_id;

		/* Hold the driver version global */
		driver_version = uinfo.driver_version;

		/* Calculate adjustment constants */
		err = ioctl(fd, ME4000_AI_EEPROM_READ, &eeprom);
		if(err){
			memset(&boardContextVec[board_count].aiContext.adjust_table, 0, 
					sizeof(boardContextVec[board_count].aiContext.adjust_table));
			memset(&boardContextVec[board_count].aiContext.adjust_table_sh, 0, 
					sizeof(boardContextVec[board_count].aiContext.adjust_table_sh));
		}
		else{
			boardContextVec[board_count].aiContext.adjust_table.date = eeprom.date;

			if(0){ // New calibration scheme not used yet
				unsigned short uni_10_offset;
				unsigned short uni_10_fullscale;
				unsigned short bi_10_offset;
				unsigned short bi_10_fullscale;
				unsigned short diff_10_offset;
				unsigned short diff_10_fullscale;

				unsigned short uni_2_5_offset;
				unsigned short uni_2_5_fullscale;
				unsigned short bi_2_5_offset;
				unsigned short bi_2_5_fullscale;
				unsigned short diff_2_5_offset;
				unsigned short diff_2_5_fullscale;

				uni_10_offset = ((eeprom.uni_10_offset & 0xFF00) >> 8) + ME4000_AI_GAIN_1_UNI_OFFSET_DIGITS;
				uni_10_fullscale = ((eeprom.uni_10_fullscale & 0xFF00) >> 8) + ME4000_AI_GAIN_1_UNI_FULLSCALE_DIGITS;

				bi_10_offset = ((eeprom.bi_10_offset & 0xFF00) >> 8) + ME4000_AI_GAIN_1_BI_OFFSET_DIGITS;
				bi_10_fullscale = ((eeprom.bi_10_fullscale & 0xFF00) >> 8) + ME4000_AI_GAIN_1_BI_FULLSCALE_DIGITS;

				diff_10_offset = ((eeprom.diff_10_offset & 0xFF00) >> 8) + ME4000_AI_GAIN_1_BI_OFFSET_DIGITS;
				diff_10_fullscale = ((eeprom.diff_10_fullscale & 0xFF00) >> 8) + ME4000_AI_GAIN_1_BI_FULLSCALE_DIGITS;

				uni_2_5_offset = ((eeprom.uni_2_5_offset & 0xFF00) >> 8) + ME4000_AI_GAIN_4_UNI_OFFSET_DIGITS;
				uni_2_5_fullscale = ((eeprom.uni_2_5_fullscale & 0xFF00) >> 8) + ME4000_AI_GAIN_4_UNI_FULLSCALE_DIGITS;

				bi_2_5_offset = ((eeprom.bi_2_5_offset & 0xFF00) >> 8) + ME4000_AI_GAIN_4_BI_OFFSET_DIGITS;
				bi_2_5_fullscale = ((eeprom.bi_2_5_fullscale & 0xFF00) >> 8) + ME4000_AI_GAIN_4_BI_FULLSCALE_DIGITS;

				diff_2_5_offset = ((eeprom.diff_2_5_offset & 0xFF00) >> 8) + ME4000_AI_GAIN_4_BI_OFFSET_DIGITS;
				diff_2_5_fullscale = ((eeprom.diff_2_5_fullscale & 0xFF00) >> 8) + ME4000_AI_GAIN_4_BI_FULLSCALE_DIGITS;

				boardContextVec[board_count].aiContext.adjust_table.a_uni_10 = 
					(ME4000_AI_GAIN_1_UNI_FULLSCALE - ME4000_AI_GAIN_1_UNI_OFFSET) /
					(uni_10_fullscale - uni_10_offset);
				boardContextVec[board_count].aiContext.adjust_table.b_uni_10 = 
					ME4000_AI_GAIN_1_UNI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table.a_uni_10 *
					uni_10_offset;

				boardContextVec[board_count].aiContext.adjust_table.a_bi_10 = 
					(ME4000_AI_GAIN_1_BI_FULLSCALE - ME4000_AI_GAIN_1_BI_OFFSET) /
					(bi_10_fullscale - bi_10_offset);
				boardContextVec[board_count].aiContext.adjust_table.b_bi_10 = 
					ME4000_AI_GAIN_1_BI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table.a_bi_10 *
					bi_10_offset;

				boardContextVec[board_count].aiContext.adjust_table.a_diff_10 = 
					(ME4000_AI_GAIN_1_BI_FULLSCALE - ME4000_AI_GAIN_1_BI_OFFSET) /
					(diff_10_fullscale - diff_10_offset);
				boardContextVec[board_count].aiContext.adjust_table.b_diff_10 = 
					ME4000_AI_GAIN_1_BI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table.a_diff_10 *
					diff_10_offset;

				boardContextVec[board_count].aiContext.adjust_table.a_uni_2_5 = 
					(ME4000_AI_GAIN_4_UNI_FULLSCALE - ME4000_AI_GAIN_4_UNI_OFFSET) /
					(uni_2_5_fullscale - uni_2_5_offset);
				boardContextVec[board_count].aiContext.adjust_table.b_uni_2_5 = 
					ME4000_AI_GAIN_4_UNI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table.a_uni_2_5 *
					uni_2_5_offset;

				boardContextVec[board_count].aiContext.adjust_table.a_bi_2_5 = 
					(ME4000_AI_GAIN_4_BI_FULLSCALE - ME4000_AI_GAIN_4_BI_OFFSET) /
					(bi_2_5_fullscale - bi_2_5_offset);
				boardContextVec[board_count].aiContext.adjust_table.b_bi_2_5 = 
					ME4000_AI_GAIN_4_BI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table.a_bi_2_5 *
					bi_2_5_offset;

				boardContextVec[board_count].aiContext.adjust_table.a_diff_2_5 = 
					(ME4000_AI_GAIN_4_BI_FULLSCALE - ME4000_AI_GAIN_4_BI_OFFSET) /
					(diff_2_5_fullscale - diff_2_5_offset);
				boardContextVec[board_count].aiContext.adjust_table.b_diff_2_5 = 
					ME4000_AI_GAIN_4_BI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table.a_diff_2_5 *
					diff_2_5_offset;

				uni_10_offset = (eeprom.uni_10_offset & 0xFF) + ME4000_AI_GAIN_1_UNI_OFFSET_DIGITS;
				uni_10_fullscale = (eeprom.uni_10_fullscale & 0xFF) + ME4000_AI_GAIN_1_UNI_FULLSCALE_DIGITS;

				bi_10_offset = (eeprom.bi_10_offset & 0xFF) + ME4000_AI_GAIN_1_BI_OFFSET_DIGITS;
				bi_10_fullscale = (eeprom.bi_10_fullscale & 0xFF) + ME4000_AI_GAIN_1_BI_FULLSCALE_DIGITS;

				diff_10_offset = (eeprom.diff_10_offset & 0xFF) + ME4000_AI_GAIN_1_BI_OFFSET_DIGITS;
				diff_10_fullscale = (eeprom.diff_10_fullscale & 0xFF) + ME4000_AI_GAIN_1_BI_FULLSCALE_DIGITS;

				uni_2_5_offset = (eeprom.uni_2_5_offset & 0xFF) + ME4000_AI_GAIN_4_UNI_OFFSET_DIGITS;
				uni_2_5_fullscale = (eeprom.uni_2_5_fullscale & 0xFF) + ME4000_AI_GAIN_4_UNI_FULLSCALE_DIGITS;

				bi_2_5_offset = (eeprom.bi_2_5_offset & 0xFF) + ME4000_AI_GAIN_4_BI_OFFSET_DIGITS;
				bi_2_5_fullscale = (eeprom.bi_2_5_fullscale & 0xFF) + ME4000_AI_GAIN_4_BI_FULLSCALE_DIGITS;

				diff_2_5_offset = (eeprom.diff_2_5_offset & 0xFF00) + ME4000_AI_GAIN_4_BI_OFFSET_DIGITS;
				diff_2_5_fullscale = (eeprom.diff_2_5_fullscale & 0xFF) + ME4000_AI_GAIN_4_BI_FULLSCALE_DIGITS;

				boardContextVec[board_count].aiContext.adjust_table_sh.a_uni_10 = 
					(ME4000_AI_GAIN_1_UNI_FULLSCALE - ME4000_AI_GAIN_1_UNI_OFFSET) /
					(uni_10_fullscale - uni_10_offset);
				boardContextVec[board_count].aiContext.adjust_table_sh.b_uni_10 = 
					ME4000_AI_GAIN_1_UNI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table_sh.a_uni_10 *
					uni_10_offset;

				boardContextVec[board_count].aiContext.adjust_table_sh.a_bi_10 = 
					(ME4000_AI_GAIN_1_BI_FULLSCALE - ME4000_AI_GAIN_1_BI_OFFSET) /
					(bi_10_fullscale - bi_10_offset);
				boardContextVec[board_count].aiContext.adjust_table_sh.b_bi_10 = 
					ME4000_AI_GAIN_1_BI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table_sh.a_bi_10 *
					bi_10_offset;

				boardContextVec[board_count].aiContext.adjust_table_sh.a_diff_10 = 
					(ME4000_AI_GAIN_1_BI_FULLSCALE - ME4000_AI_GAIN_1_BI_OFFSET) /
					(diff_10_fullscale - diff_10_offset);
				boardContextVec[board_count].aiContext.adjust_table_sh.b_diff_10 = 
					ME4000_AI_GAIN_1_BI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table_sh.a_diff_10 *
					diff_10_offset;

				boardContextVec[board_count].aiContext.adjust_table_sh.a_uni_2_5 = 
					(ME4000_AI_GAIN_4_UNI_FULLSCALE - ME4000_AI_GAIN_4_UNI_OFFSET) /
					(uni_2_5_fullscale - uni_2_5_offset);
				boardContextVec[board_count].aiContext.adjust_table_sh.b_uni_2_5 = 
					ME4000_AI_GAIN_4_UNI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table_sh.a_uni_2_5 *
					uni_2_5_offset;

				boardContextVec[board_count].aiContext.adjust_table_sh.a_bi_2_5 = 
					(ME4000_AI_GAIN_4_BI_FULLSCALE - ME4000_AI_GAIN_4_BI_OFFSET) /
					(bi_2_5_fullscale - bi_2_5_offset);
				boardContextVec[board_count].aiContext.adjust_table_sh.b_bi_2_5 = 
					ME4000_AI_GAIN_4_BI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table_sh.a_bi_2_5 *
					bi_2_5_offset;

				boardContextVec[board_count].aiContext.adjust_table_sh.a_diff_2_5 = 
					(ME4000_AI_GAIN_4_BI_FULLSCALE - ME4000_AI_GAIN_4_BI_OFFSET) /
					(diff_2_5_fullscale - diff_2_5_offset);
				boardContextVec[board_count].aiContext.adjust_table_sh.b_diff_2_5 = 
					ME4000_AI_GAIN_4_BI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table_sh.a_diff_2_5 *
					diff_2_5_offset;
			}
			else{ // Originally calibration scheme
				boardContextVec[board_count].aiContext.adjust_table.a_uni_10 = 
					(ME4000_AI_GAIN_1_UNI_FULLSCALE - ME4000_AI_GAIN_1_UNI_OFFSET) /
					(eeprom.uni_10_fullscale - eeprom.uni_10_offset);
				boardContextVec[board_count].aiContext.adjust_table.b_uni_10 = 
					ME4000_AI_GAIN_1_UNI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table.a_uni_10 *
					eeprom.uni_10_offset;

				boardContextVec[board_count].aiContext.adjust_table.a_bi_10 = 
					(ME4000_AI_GAIN_1_BI_FULLSCALE - ME4000_AI_GAIN_1_BI_OFFSET) /
					(eeprom.bi_10_fullscale - eeprom.bi_10_offset);
				boardContextVec[board_count].aiContext.adjust_table.b_bi_10 = 
					ME4000_AI_GAIN_1_BI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table.a_bi_10 *
					eeprom.bi_10_offset;

				boardContextVec[board_count].aiContext.adjust_table.a_diff_10 = 
					(ME4000_AI_GAIN_1_BI_FULLSCALE - ME4000_AI_GAIN_1_BI_OFFSET) /
					(eeprom.diff_10_fullscale - eeprom.diff_10_offset);
				boardContextVec[board_count].aiContext.adjust_table.b_diff_10 = 
					ME4000_AI_GAIN_1_BI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table.a_diff_10 *
					eeprom.diff_10_offset;

				boardContextVec[board_count].aiContext.adjust_table.a_uni_2_5 = 
					(ME4000_AI_GAIN_4_UNI_FULLSCALE - ME4000_AI_GAIN_4_UNI_OFFSET) /
					(eeprom.uni_2_5_fullscale - eeprom.uni_2_5_offset);
				boardContextVec[board_count].aiContext.adjust_table.b_uni_2_5 = 
					ME4000_AI_GAIN_4_UNI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table.a_uni_2_5 *
					eeprom.uni_2_5_offset;

				boardContextVec[board_count].aiContext.adjust_table.a_bi_2_5 = 
					(ME4000_AI_GAIN_4_BI_FULLSCALE - ME4000_AI_GAIN_4_BI_OFFSET) /
					(eeprom.bi_2_5_fullscale - eeprom.bi_2_5_offset);
				boardContextVec[board_count].aiContext.adjust_table.b_bi_2_5 = 
					ME4000_AI_GAIN_4_BI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table.a_bi_2_5 *
					eeprom.bi_2_5_offset;

				boardContextVec[board_count].aiContext.adjust_table.a_diff_2_5 = 
					(ME4000_AI_GAIN_4_BI_FULLSCALE - ME4000_AI_GAIN_4_BI_OFFSET) /
					(eeprom.diff_2_5_fullscale - eeprom.diff_2_5_offset);
				boardContextVec[board_count].aiContext.adjust_table.b_diff_2_5 = 
					ME4000_AI_GAIN_4_BI_OFFSET - 
					boardContextVec[board_count].aiContext.adjust_table.a_diff_2_5 *
					eeprom.diff_2_5_offset;
			}
		}

		close(fd);

		/* Init the analog input context */
		boardContextVec[board_count].aiContext.fd = -1;
		boardContextVec[board_count].aiContext.thread = 0;
		boardContextVec[board_count].aiContext.ulChannelListCount = 0;
		boardContextVec[board_count].aiContext.psAIBuffer = NULL;
		boardContextVec[board_count].aiContext.ulAIBufferCount = 0;
		boardContextVec[board_count].aiContext.iExecutionMode = 0;
		boardContextVec[board_count].aiContext.iAcqMode = 0;
		boardContextVec[board_count].aiContext.pCallback = NULL;
		boardContextVec[board_count].aiContext.pCallbackContext = NULL;
		boardContextVec[board_count].aiContext.ulRefreshFrequency = 0;
		boardContextVec[board_count].aiContext.pTerminateFunc = NULL;
		boardContextVec[board_count].aiContext.pTerminateContext = NULL;
		boardContextVec[board_count].aiContext.ulTimeOutSeconds = 0;
		boardContextVec[board_count].aiContext.ai_count = uinfo.ai_count;
		boardContextVec[board_count].aiContext.ai_sh_count = uinfo.ai_sh_count;
		boardContextVec[board_count].aiContext.ai_ex_trig_analog = uinfo.ai_ex_trig_analog;
		boardContextVec[board_count].aiContext.device_id = uinfo.device_id;

		/* Init the analog output context */
		for(i = 0; i < 4; i++){
			boardContextVec[board_count].aoContext[i].fd = -1;
			boardContextVec[board_count].aoContext[i].thread = 0;
			boardContextVec[board_count].aoContext[i].pCallback = NULL;
			boardContextVec[board_count].aoContext[i].pCallbackContext = NULL;
		}

		/* Init bit pattern context */
		boardContextVec[board_count].dioContext.fd = -1;

		/* Init dio context */
		boardContextVec[board_count].diobpContext.aoContext.fd = -1;
		boardContextVec[board_count].diobpContext.dioContext.fd = -1;

		/* Init cnt context */
		boardContextVec[board_count].cntContext.fd = -1;

		/* Init external interrupt context */
		boardContextVec[board_count].extIntContext.fd = -1;
		boardContextVec[board_count].extIntContext.pCallback = NULL;
		boardContextVec[board_count].extIntContext.pCallbackContext = NULL;

		/* Init MultiSig context */
		boardContextVec[board_count].multiSigContext.dioContext.fd = -1;

		/* Init MultiSigAI context */
		boardContextVec[board_count].multiSigAIContext.dioContext.fd = -1;

		boardContextVec[board_count].multiSigAIContext.aiContext.fd = -1;
		boardContextVec[board_count].multiSigAIContext.aiContext.thread = 0;
		boardContextVec[board_count].multiSigAIContext.aiContext.ulChannelListCount = 0;
		boardContextVec[board_count].multiSigAIContext.aiContext.psAIBuffer = NULL;
		boardContextVec[board_count].multiSigAIContext.aiContext.ulAIBufferCount = 0;
		boardContextVec[board_count].multiSigAIContext.aiContext.iExecutionMode = 0;
		boardContextVec[board_count].multiSigAIContext.aiContext.iAcqMode = 0;
		boardContextVec[board_count].multiSigAIContext.aiContext.pCallback = NULL;
		boardContextVec[board_count].multiSigAIContext.aiContext.pCallbackContext = NULL;
		boardContextVec[board_count].multiSigAIContext.aiContext.ulRefreshFrequency = 0;
		boardContextVec[board_count].multiSigAIContext.aiContext.pTerminateFunc = NULL;
		boardContextVec[board_count].multiSigAIContext.aiContext.pTerminateContext = NULL;
		boardContextVec[board_count].multiSigAIContext.aiContext.ulTimeOutSeconds = 0;
		boardContextVec[board_count].multiSigAIContext.aiContext.ai_count = uinfo.ai_count;
		boardContextVec[board_count].multiSigAIContext.aiContext.ai_sh_count = uinfo.ai_sh_count;
		boardContextVec[board_count].multiSigAIContext.aiContext.ai_ex_trig_analog = uinfo.ai_ex_trig_analog;

		boardContextVec[board_count].multiSigAIContext.aoContext.fd = -1;
		boardContextVec[board_count].multiSigAIContext.aoContext.thread = 0;
		boardContextVec[board_count].multiSigAIContext.aoContext.pCallback = NULL;
		boardContextVec[board_count].multiSigAIContext.aoContext.pCallbackContext = NULL;

		/* Init MultiSigAO context */
		boardContextVec[board_count].multiSigAOContext.dioContext.fd = -1;

		boardContextVec[board_count].multiSigAOContext.aoContext_0.fd = -1;
		boardContextVec[board_count].multiSigAOContext.aoContext_0.thread = 0;
		boardContextVec[board_count].multiSigAOContext.aoContext_0.pCallback = NULL;
		boardContextVec[board_count].multiSigAOContext.aoContext_0.pCallbackContext = NULL;

		boardContextVec[board_count].multiSigAOContext.aoContext_3.fd = -1;
		boardContextVec[board_count].multiSigAOContext.aoContext_3.thread = 0;
		boardContextVec[board_count].multiSigAOContext.aoContext_3.pCallback = NULL;
		boardContextVec[board_count].multiSigAOContext.aoContext_3.pCallbackContext = NULL;
	}

	return;
}



void _fini(void){
	int fd;
	int i;

	/* Try to close any open path */
	fd = boardContextVec[board_count].aiContext.fd;
	if(fd != -1) close(fd);

	for(i = 0; i < 4; i++){
		fd = boardContextVec[board_count].aoContext[i].fd;
		if(fd != -1) close(fd);
	}

	fd = boardContextVec[board_count].dioContext.fd;
	if(fd != -1) close(fd);

	return;
}



/*===========================================================================
  Error handling functions
  =========================================================================*/

int me4000ErrorGetMessage(
		int iErrorCode, 
		char *pcBuffer, 
		unsigned int uiBufferSize){
	if(iErrorCode > ERROR_NO_SYSTEM || iErrorCode < ERROR_NO_SUCCESS){
		my_errno = ERROR_NO_INVALID_ERROR_NO;
		strncpy(pcBuffer, errorTable[ERROR_NO_INVALID_ERROR_NO], uiBufferSize);
		return ME4000_NO_ERROR;
	}

	if(iErrorCode == ERROR_NO_SYSTEM){
		strncpy(pcBuffer, sysErrMsg, uiBufferSize);
	}
	else{
		strncpy(pcBuffer, errorTable[iErrorCode], uiBufferSize);
	}

	return ME4000_NO_ERROR;
}



int me4000ErrorGetLastMessage(char *pcBuffer, unsigned int uiBufferSize){
	return me4000ErrorGetMessage(my_errno, pcBuffer, uiBufferSize);
}



int me4000ErrorSetDefaultProc(int iDefaultProcStatus){
	errorDefaultProcFlag = iDefaultProcStatus;
	return ME4000_NO_ERROR;
}



int me4000ErrorSetUserProc(ME4000_P_ERROR_PROC pErrorProc){
	errorUserProcPtr = pErrorProc;
	return ME4000_NO_ERROR;
}



int storeSystemError(int error){
	strcpy(sysErrMsg, strerror(error));
	my_errno = ERROR_NO_SYSTEM;
	return ERROR_NO_SYSTEM;
}



void errorDefaultProc(char *function, int iErrorCode){
	char msg[64] = {0};
	me4000ErrorGetMessage(iErrorCode, msg, sizeof(msg));
	fprintf(stderr, "In function %s: %s (%d)\n", function, msg, iErrorCode);
}



/*=============================================================================
  General purpose functions
  ===========================================================================*/

int me4000FrequencyToTicks(
		double dRequiredFreq, 
		unsigned long *pulTicksLowPart, 
		unsigned long *pulTicksHighPart, 
		double *pdAchievedFreq){
	unsigned long long i64_count;
	double d_count;

	/* Check the first parameter
	   Test if the required frequency 
	   lies within the supported range */
	if((dRequiredFreq <= 0.0) || (ME4000_BASE_FREQUENCY < dRequiredFreq)){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_FREQUENCY;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000FrequencyToTicks()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000FrequencyToTicks()", my_errno);
		return ERROR_NO_INVALID_FREQUENCY;
	}

	/* Preset pulCountLowPart to zero */
	*pulTicksLowPart = 0;

	/* Preset pulCountHighPart to zero */
	*pulTicksHighPart = 0;

	/* Preset pdAchievedFreq to zero */
	if(pdAchievedFreq) *pdAchievedFreq = 0.0;

	/* Calculate required count as double */
	d_count = ME4000_BASE_FREQUENCY / dRequiredFreq;
	i64_count = (unsigned long long) d_count;

	/* Separate the high and low parts of the count */
	*pulTicksLowPart = (unsigned long) (i64_count & 0x00000000FFFFFFFF);
	*pulTicksHighPart = (unsigned long) ((i64_count >> 32) & 0x00000000FFFFFFFF);

	/* Calculate the frequency actually acheived using this count */
	if(pdAchievedFreq) *pdAchievedFreq = ME4000_BASE_FREQUENCY / (double) i64_count;

	return ME4000_NO_ERROR;
}



int me4000TimeToTicks(
		double dRequiredTime, 
		unsigned long *pulTicksLowPart, 
		unsigned long *pulTicksHighPart, 
		double *pdAchievedTime){
	double d_count;
	unsigned long long i64_count;

	/* Check the first parameter
	   Test if the required time lies within the supported range */
	if(dRequiredTime <= 1 / (double) ME4000_BASE_FREQUENCY){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_TIME;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000TimeToTicks()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000TimeToTicks()", my_errno);
		return ERROR_NO_INVALID_TIME;
	}

	/* Preset pulCountLowPart to zero */
	*pulTicksLowPart = 0;

	/* Preset pulCountHighPart to zero */
	*pulTicksHighPart = 0;

	/* Preset pdAchievedTime to zero */
	if(pdAchievedTime) *pdAchievedTime = 0.0;

	/* Calculate required count as double */
	d_count = ME4000_BASE_FREQUENCY * dRequiredTime;
	i64_count = (unsigned long long) d_count;

	/* Separate the high and low parts of the count */
	*pulTicksLowPart = (unsigned long) (i64_count & 0x00000000FFFFFFFF);
	*pulTicksHighPart = (unsigned long) ((i64_count >> 32) & 0x00000000FFFFFFFF);

	/* Calculate the time actually acheived using this count */
	if(pdAchievedTime) *pdAchievedTime =  (double) i64_count / ME4000_BASE_FREQUENCY;

	return ME4000_NO_ERROR;
}



int me4000GetBoardVersion(unsigned int uiBoardNumber, unsigned short *pusVersion){
	*pusVersion = 0;

	/* Check if board number is valid */
	if(uiBoardNumber >= board_count){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BOARD;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000GetBoardVersion()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000GetBoardVersion()", my_errno);
		return ERROR_NO_INVALID_BOARD;
	}

	*pusVersion = boardContextVec[uiBoardNumber].devInfo.dwDeviceID;

	return ME4000_NO_ERROR;
}



int me4000GetDLLVersion(unsigned long *pulVersion){
	*pulVersion = ME4000_DLL_VERSION;
	return ME4000_NO_ERROR;
}



int me4000GetDriverVersion(unsigned long *pulVersion){
	*pulVersion = driver_version;
	return ME4000_NO_ERROR;
}



int me4000GetSerialNumber(unsigned int uiBoardNumber, unsigned long *pulSerialNumber){
	*pulSerialNumber = 0;

	/* Check if board number is valid */
	if(uiBoardNumber >= board_count){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BOARD;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000GetSerialNumber()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000GetSerialNumber()", my_errno);
		return ERROR_NO_INVALID_BOARD;
	}

	*pulSerialNumber = boardContextVec[uiBoardNumber].devInfo.dwSerialNumber;

	return ME4000_NO_ERROR;
}



int me4000GetDevInfo(unsigned int uiBoardNumber, DEVICEINFOSTRUCT *pDevInfo){

	/* Check if board number is valid */
	if(uiBoardNumber >= board_count){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BOARD;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000GetDevInfo()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000GetDevInfo()", my_errno);
		return ERROR_NO_INVALID_BOARD;
	}

	*pDevInfo = boardContextVec[uiBoardNumber].devInfo;

	return ME4000_NO_ERROR;
}



int me4000GetBoardCount(void){
	return board_count;
}



/*=============================================================================
  Analog output
  ===========================================================================*/


int AOCheckBoardChannel(unsigned int uiBoardNumber, unsigned int uiChannelNumber){
	if(uiBoardNumber >= board_count){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BOARD;
		return ERROR_NO_INVALID_BOARD;
	}

	if(uiChannelNumber >= 4){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_CHANNEL;
		return ERROR_NO_INVALID_CHANNEL;
	}

	return ME4000_NO_ERROR;
}



int AOCheckBoardChannelFD(unsigned int uiBoardNumber, unsigned int uiChannelNumber){
	int fd;
	int err;

	err = AOCheckBoardChannel(uiBoardNumber, uiChannelNumber);
	if(err) return err;

	fd = boardContextVec[uiBoardNumber].aoContext[uiChannelNumber].fd;
	if(fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}

	return ME4000_NO_ERROR;
}



int me4000AOOpen(
		unsigned int uiBoardNumber,
		unsigned int uiChannelNumber,
		int iMode){
	int err;

	err = AOCheckBoardChannel(uiBoardNumber, uiChannelNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOOpen()", err);
		return err;
	}

	if(boardContextVec[uiBoardNumber].aoContext[uiChannelNumber].fd != -1){
		return ME4000_NO_ERROR; // Already open
	}

	err = AOOpen(&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber], uiBoardNumber, uiChannelNumber, iMode);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOOpen()", err);
		return err;
	}

	if(uiChannelNumber == 3){
		/* Maybe the analog output was opened in MultiSigAI, MultiSigAO or DIOPB mode */
		err = ioctl(boardContextVec[uiBoardNumber].aoContext[uiChannelNumber].fd, ME4000_AO_DISABLE_DO);
		if(err){
			AOClose(&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber]);
			err = storeSystemError(errno);
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000AOOpen()", err);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000AOOpen()", err);
			return err;
		}
	}

	return ME4000_NO_ERROR;
}



int AOOpen(
		me4000AOContext_t *aoContext,
		unsigned int uiBoardNumber,
		unsigned int uiChannelNumber,
		int iMode){
	char str[64];
	int err;

	switch(iMode){
		case ME4000_AO_CONV_MODE_SINGLE:
			snprintf(str, sizeof(str), "/dev/me4000_%u_ao_%u_%s", uiBoardNumber, uiChannelNumber, "sing");
			break;
		case ME4000_AO_CONV_MODE_WRAPAROUND:
			snprintf(str, sizeof(str), "/dev/me4000_%u_ao_%u_%s", uiBoardNumber, uiChannelNumber, "wrap");
			break;
		case ME4000_AO_CONV_MODE_CONTINUOUS:
			snprintf(str, sizeof(str), "/dev/me4000_%u_ao_%u_%s", uiBoardNumber, uiChannelNumber, "cont");
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_CONV_MODE;
			return ERROR_NO_INVALID_CONV_MODE;
	}

	err = open(str, O_RDWR);
	if(err < 0) return storeSystemError(errno);

	aoContext->fd = err;
	return ME4000_NO_ERROR;
}



int me4000AOClose(unsigned int uiBoardNumber, unsigned int uiChannelNumber){
	int err;

	err = AOCheckBoardChannelFD(uiBoardNumber, uiChannelNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOClose()", err);
		return err;
	}

	err = AOClose(&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber]);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOClose()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AOClose(me4000AOContext_t *aoContext){
	int err;

	err = close(aoContext->fd);
	if(err < 0) return storeSystemError(errno);

	aoContext->fd = -1;
	return ME4000_NO_ERROR;
}



int me4000AOAppendNewValues(
		unsigned int uiBoardNumber, 
		unsigned int uiChannelNumber, 
		unsigned short *pusBuffer, 
		unsigned long ulNumberOfValuesToAppend, 
		int iExecutionMode,
		unsigned long *pulNumberOfValuesAppended){
	int err;

	err = AOCheckBoardChannelFD(uiBoardNumber, uiChannelNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOAppendNewValues()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOAppendNewValues()", err);
		return err;
	}

	err = AOAppendNewValues(
			&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber],
			pusBuffer,
			ulNumberOfValuesToAppend,
			iExecutionMode,
			pulNumberOfValuesAppended);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOAppendNewValues()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOAppendNewValues()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AOAppendNewValues(
		me4000AOContext_t *aoContext,
		unsigned short *pusBuffer, 
		unsigned long ulBufferCount, 
		int iExecutionMode,
		unsigned long *pulNumberOfValuesAppended){
	int err;
	int flags;

	*pulNumberOfValuesAppended = 0;

	if(!ulBufferCount){
		err = ioctl(aoContext->fd, ME4000_AO_GET_FREE_BUFFER, pulNumberOfValuesAppended);
		if(err) return storeSystemError(errno);
	}
	else {
		/* Get the flags */
		flags = fcntl(aoContext->fd, F_GETFL, 0);
		if(flags < 0) return storeSystemError(errno);

		/* Set the append flag in order to append new values to the stream */
		flags |= O_APPEND;

		/* Setup the nonblock flag according to the execution mode */
		if(iExecutionMode == ME4000_AO_APPEND_NEW_VALUES_BLOCKING)
			flags &= ~O_NONBLOCK;
		else if(iExecutionMode == ME4000_AO_APPEND_NEW_VALUES_NON_BLOCKING)
			flags |= O_NONBLOCK;
		else{
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_EXEC_MODE;
			return ERROR_NO_INVALID_EXEC_MODE;
		}

		err = fcntl(aoContext->fd, F_SETFL, flags);
		if(err < 0) return storeSystemError(errno);

		/* Append to the data stream */
		err = write(aoContext->fd, pusBuffer, 2 * ulBufferCount);
		if(err < 0){
			if(errno == EAGAIN){
				*pulNumberOfValuesAppended = 0;
				return ME4000_NO_ERROR;
			}
			else
				return storeSystemError(errno);
		}

		*pulNumberOfValuesAppended = err;
	}

	return ME4000_NO_ERROR;
}



int me4000AOConfig(
		unsigned int uiBoardNumber, 
		unsigned int uiChannelNumber,
		unsigned long ulTicks, 
		int iTriggerMode,
		int iExtTriggerEdge){
	int err;

	err = AOCheckBoardChannelFD(uiBoardNumber, uiChannelNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOConfig()", err);
		return err;
	}

	err = AOConfig(
			&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber],
			ulTicks,
			iTriggerMode,
			iExtTriggerEdge);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOConfig()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AOConfig(
		me4000AOContext_t *aoContext,
		unsigned long ulTicks, 
		int iTriggerMode,
		int iExtTriggerEdge){
	int err;

	err = ioctl(aoContext->fd, ME4000_AO_TIMER_SET_DIVISOR, &ulTicks);
	if(err) return storeSystemError(errno);

	switch(iExtTriggerEdge){
		case ME4000_AO_TRIGGER_EXT_EDGE_RISING:
		case ME4000_AO_TRIGGER_EXT_EDGE_FALLING:
		case ME4000_AO_TRIGGER_EXT_EDGE_BOTH:
			err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_SETUP, &iExtTriggerEdge);
			if(err) return storeSystemError(errno);
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_TRIGGER_EDGE;
			return ERROR_NO_INVALID_TRIGGER_EDGE;
	}

	switch(iTriggerMode){
		case ME4000_AO_TRIGGER_SOFTWARE:
			err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_DISABLE);
			if(err) return storeSystemError(errno);

			err = ioctl(aoContext->fd, ME4000_AO_SYNCHRONOUS_DISABLE);
			if(err) return storeSystemError(errno);
			break;
		case ME4000_AO_TRIGGER_EXT_DIGITAL:
			err = ioctl(aoContext->fd, ME4000_AO_SYNCHRONOUS_DISABLE);
			if(err) return storeSystemError(errno);

			err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_ENABLE);
			if(err) return storeSystemError(errno);
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_TRIGGER_MODE;
			return ERROR_NO_INVALID_TRIGGER_MODE;
	}

	return ME4000_NO_ERROR;
}



int me4000AOContinuous(
		unsigned int uiBoardNumber, 
		unsigned int uiChannelNumber,
		unsigned short *pusBuffer, 
		unsigned long ulDataCount, 
		ME4000_P_AO_CALLBACK_PROC pCallbackProc,
		void *pCallbackContext,
		unsigned long ulTimeOutSeconds,
		unsigned long *pulNumberOfValuesWritten){
	int err;

	err = AOCheckBoardChannelFD(uiBoardNumber, uiChannelNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOContinuous()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOContinuous()", err);
		return err;
	}

	err = AOContinuous(
			&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber],
			pusBuffer, 
			ulDataCount, 
			pCallbackProc,
			pCallbackContext,
			ulTimeOutSeconds,
			pulNumberOfValuesWritten);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOContinuous()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOContinuous()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AOContinuous(
		me4000AOContext_t *aoContext,
		unsigned short *pusBuffer, 
		unsigned long ulBufferCount, 
		ME4000_P_AO_CALLBACK_PROC pCallback,
		void *pCallbackContext,
		unsigned long ulTimeOutSeconds,
		unsigned long *pulNumberOfValuesWritten){
	int err;
	int flags;

	*pulNumberOfValuesWritten = 0;

	aoContext->ulTimeOutSeconds = ulTimeOutSeconds;
	aoContext->pCallback = pCallback;
	aoContext->pCallbackContext = pCallbackContext;

	*pulNumberOfValuesWritten = 0;

	/* Get the flags */
	flags = fcntl(aoContext->fd, F_GETFL, 0);
	if(flags < 0) return storeSystemError(errno);

	/* Clear the append flag */
	flags &= ~O_APPEND;

	err = fcntl(aoContext->fd, F_SETFL, flags);
	if(err < 0) return storeSystemError(errno);

	/* Preload the analog output */
	err = write(aoContext->fd, pusBuffer, 2 * ulBufferCount);
	if(err < 0) return storeSystemError(errno);

	*pulNumberOfValuesWritten = err / 2;
	return ME4000_NO_ERROR;
}



int me4000AOGetStatus(
		unsigned int uiBoardNumber, 
		unsigned int uiChannelNumber,
		int iWaitIdle,
		int *piStatus){
	int err;

	err = AOCheckBoardChannelFD(uiBoardNumber, uiChannelNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOGetStatus()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOGetStatus()", err);
		return err;
	}

	err = AOGetStatus(&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber], iWaitIdle, piStatus);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOGetStatus()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOGetStatus()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AOGetStatus(
		me4000AOContext_t *aoContext,
		int iWaitIdle,
		int *piStatus){
	int err;
	int flags;

	if(iWaitIdle){
		/* Synchronize with the hardware. It guarantees
		   that the last value is converted and the
		   State Machine is idle now */
		err = fsync(aoContext->fd);
		if(err < 0) return storeSystemError(errno);

		/* Conversion is finished. So enable preloading
		   for the next run */
		flags = fcntl(aoContext->fd, F_GETFL, 0);
		if(flags < 0) return storeSystemError(errno);

		flags &= ~O_APPEND;
		flags = fcntl(aoContext->fd, F_SETFL, flags);
		if(flags < 0) return storeSystemError(errno);
		*piStatus = 0;
	}
	else{
		err = ioctl(aoContext->fd, ME4000_AO_FSM_STATE, piStatus);
		if(err) return storeSystemError(errno);
	}

	return ME4000_NO_ERROR;
}



int me4000AOReset(unsigned int uiBoardNumber, unsigned int uiChannelNumber){
	int err;

	err = AOCheckBoardChannelFD(uiBoardNumber, uiChannelNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOReset()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOReset()", err);
		return err;
	}

	err = AOReset(&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber]);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOReset()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOReset()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AOReset(me4000AOContext_t *aoContext){
	int err;

	/* Reset the analog output */
	err = ioctl(aoContext->fd, ME4000_AO_RESET);
	if(err) return storeSystemError(errno);

	return ME4000_NO_ERROR;
}



int AOSetTimer(me4000AOContext_t *aoContext, unsigned long ulTicks){
	int err;

	err = ioctl(aoContext->fd, ME4000_AO_TIMER_SET_DIVISOR, &ulTicks);
	if(err) return storeSystemError(errno);
	return ME4000_NO_ERROR;
}



int me4000AOSingle(
		unsigned int uiBoardNumber, 
		unsigned int uiChannelNumber, 
		int iTriggerMode,
		int iExtTriggerEdge,
		unsigned long ulTimeOutSeconds,
		unsigned short usValue){
	int err;

	err = AOCheckBoardChannelFD(uiBoardNumber, uiChannelNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOSingle()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOSingle()", err);
		return err;
	}

	err = AOSingle(
			&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber],
			iTriggerMode,
			iExtTriggerEdge,
			ulTimeOutSeconds,
			usValue);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOSingle()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOSingle()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AOSingle(
		me4000AOContext_t *aoContext,
		int iTriggerMode,
		int iExtTriggerEdge,
		unsigned long ulTimeOutSeconds,
		unsigned short usValue){
	unsigned long jiffies;
	int err;

	err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_DISABLE);
	if(err) return storeSystemError(errno);

	err = ioctl(aoContext->fd, ME4000_AO_SIMULTANEOUS_DISABLE);
	if(err) return storeSystemError(errno);


	switch(iTriggerMode){
		case ME4000_AO_TRIGGER_SOFTWARE:
			iExtTriggerEdge = ME4000_AO_TRIGGER_EXT_EDGE_RISING;
			err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_SETUP, &iExtTriggerEdge);
			if(err) return storeSystemError(errno);

			err = write(aoContext->fd, &usValue, sizeof(usValue));
			if(err != sizeof(usValue)) return storeSystemError(errno);
			break;
		case ME4000_AO_TRIGGER_EXT_DIGITAL:
			switch(iExtTriggerEdge){
				case ME4000_AO_TRIGGER_EXT_EDGE_RISING:
				case ME4000_AO_TRIGGER_EXT_EDGE_FALLING:
				case ME4000_AO_TRIGGER_EXT_EDGE_BOTH:
					err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_SETUP, &iExtTriggerEdge);
					if(err) return storeSystemError(errno);
					break;
				default:
					errno = EINVAL;
					my_errno = ERROR_NO_INVALID_TRIGGER_EDGE;
					return ERROR_NO_INVALID_TRIGGER_EDGE;
			}

			err = ioctl(aoContext->fd, ME4000_AO_PRELOAD);
			if(err) return storeSystemError(errno);

			err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_ENABLE);
			if(err) return storeSystemError(errno);

			err = write(aoContext->fd, &usValue, sizeof(usValue));
			if(err != sizeof(usValue)) return storeSystemError(errno);

			jiffies = HZ * ulTimeOutSeconds;
			err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_TIMEOUT, &jiffies);
			if(err) return storeSystemError(errno);
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_TRIGGER_MODE;
			return ERROR_NO_INVALID_TRIGGER_MODE;
	}

	return ME4000_NO_ERROR;
}



int me4000AOSingleSimultaneous(
		unsigned int uiBoardNumber,
		unsigned int *puiChannelNumber,
		unsigned long ulCount,
		int iTriggerMode,
		int *piExtTriggerEnable,
		int *piExtTriggerEdge,
		unsigned long ulTimeOutSeconds,
		unsigned short *pusValue){
	int err;
	int i;
	me4000_ao_channel_list_t chanlist;

	for(i = 0; i < ulCount; i++){
		err = AOCheckBoardChannelFD(uiBoardNumber, puiChannelNumber[i]);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000AOSingleSimultaneous()", err);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000AOSingleSimultaneous()", err);
			return err;
		}

		err = AOSingleSimultaneous(
				&boardContextVec[uiBoardNumber].aoContext[puiChannelNumber[i]],
				iTriggerMode,
				piExtTriggerEnable[i],
				piExtTriggerEdge[i],
				pusValue[i]);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000AOSingleSimultaneous()", err);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000AOSingleSimultaneous()", err);
			return err;
		}
	}

	if(iTriggerMode == ME4000_AO_TRIGGER_SOFTWARE){
		err = AOCheckBoardChannelFD(uiBoardNumber, puiChannelNumber[0]);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000AOSingleSimultaneous()", err);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000AOSingleSimultaneous()", err);
			return err;
		}
		chanlist.count = ulCount;
		chanlist.list = (unsigned long *) puiChannelNumber;
		err = AOSingleSimultaneousSoftware(&boardContextVec[uiBoardNumber].aoContext[puiChannelNumber[0]], chanlist);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000AOSingleSimultaneous()", err);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000AOSingleSimultaneous()", err);
			return err;
		}
	}
	else if(iTriggerMode == ME4000_AO_TRIGGER_EXT_DIGITAL){
		for(i = 0; i < ulCount; i++){
			err = AOCheckBoardChannelFD(uiBoardNumber, puiChannelNumber[i]);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000AOSingleSimultaneous()", err);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000AOSingleSimultaneous()", err);
				return err;
			}
			if(piExtTriggerEnable[i]){
				err = AOSingleSimultaneousTimeout(&boardContextVec[uiBoardNumber].aoContext[puiChannelNumber[i]], ulTimeOutSeconds);
				if(err){
					if(errorDefaultProcFlag)
						errorDefaultProc("me4000AOSingleSimultaneous()", err);
					else if(errorUserProcPtr)
						errorUserProcPtr("me4000AOSingleSimultaneous()", err);
					return err;
				}
				break;
			}
		}
	}
	else{
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_TRIGGER_MODE;
		return ERROR_NO_INVALID_TRIGGER_MODE;
	}

	return ME4000_NO_ERROR;
}



int AOSingleSimultaneous(
		me4000AOContext_t *aoContext,
		int iTriggerMode,
		int iExtTriggerEnable,
		int iExtTriggerEdge,
		unsigned short usValue){
	int err;

	switch(iTriggerMode){
		case ME4000_AO_TRIGGER_SOFTWARE:
			err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_DISABLE);
			if(err) return storeSystemError(errno);

			err = ioctl(aoContext->fd, ME4000_AO_SIMULTANEOUS_SW);
			if(err) return storeSystemError(errno);

			err = write(aoContext->fd, &usValue, sizeof(usValue));
			if(err != 2) return storeSystemError(errno);

			break;
		case ME4000_AO_TRIGGER_EXT_DIGITAL:
			err = ioctl(aoContext->fd, ME4000_AO_SIMULTANEOUS_EX_TRIG);
			if(err) return storeSystemError(errno);

			if(iExtTriggerEnable){
				err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_SETUP, &iExtTriggerEdge);
				if(err) return storeSystemError(errno);

				err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_ENABLE);
				if(err) return storeSystemError(errno);
			}
			else{
				err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_DISABLE);
				if(err) return storeSystemError(errno);
			}

			err = write(aoContext->fd, &usValue, sizeof(usValue));
			if(err != 2) return storeSystemError(errno);

			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_TRIGGER_MODE;
			return ERROR_NO_INVALID_TRIGGER_MODE;
	}

	return ME4000_NO_ERROR;
}



int AOSingleSimultaneousSoftware(
		me4000AOContext_t *aoContext,
		me4000_ao_channel_list_t chanlist){
	int err;

	err = ioctl(aoContext->fd, ME4000_AO_SIMULTANEOUS_UPDATE, &chanlist);
	if(err) return storeSystemError(errno);
	return ME4000_NO_ERROR;
}



int AOSingleSimultaneousTimeout(
		me4000AOContext_t *aoContext,
		unsigned long ulTimeOutSeconds){
	int err;
	unsigned long jiffies;

	jiffies = HZ * ulTimeOutSeconds;
	err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_TIMEOUT, &jiffies);
	if(err) return storeSystemError(errno);
	return ME4000_NO_ERROR;
}



int me4000AOStart(unsigned int uiBoardNumber, unsigned int uiChannelNumber){
	int err;

	err = AOCheckBoardChannelFD(uiBoardNumber, uiChannelNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOStart()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOStart()", err);
		return err;
	}

	err = AOStart(&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber]);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOStart()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOStart()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AOStart(me4000AOContext_t *aoContext){
	int err;
	unsigned long jiffies;

	jiffies = HZ * aoContext->ulTimeOutSeconds;

	err = ioctl(aoContext->fd, ME4000_AO_START, &jiffies);
	if(err) return storeSystemError(errno);

	if(aoContext->pCallback){
		err = pthread_create(&aoContext->thread, NULL, AOContinuousAsync, (void *) aoContext);
		if(err){
			my_errno = ERROR_NO_START_THREAD;
			return ERROR_NO_START_THREAD;
		}
		pthread_detach(aoContext->thread);
	}

	return ME4000_NO_ERROR;
}



void *AOContinuousAsync(void *arg){
	me4000AOContext_t *context = arg;
	fd_set wset;
	int err;
	unsigned long c;

	FD_ZERO(&wset);
	FD_SET(context->fd, &wset);

	/* Execute for ever until user stops conversion in the main thread
	   or calls exit() in the callback */
	while(1){
		err = select(context->fd + 1, NULL, &wset, NULL, NULL);
		if(err){
			storeSystemError(errno);
			return &my_errno;
		}

		/* Call the user function */
		if(FD_ISSET(context->fd, &wset)){
			err = ioctl(context->fd, ME4000_AO_GET_FREE_BUFFER, &c);
			if(err){
				storeSystemError(errno);
				return &my_errno;
			}

			context->pCallback(c, context->pCallbackContext);
		}
	}

	return NULL;
}



int me4000AOStartSynchronous(
		unsigned int uiBoardNumber, 
		unsigned int *puiChannelNumber, 
		unsigned long ulCount, 
		int iTriggerMode, 
		int *piExtTriggerEnable,
		int *piExtTriggerEdge,
		unsigned long ulTimeOutSeconds){
	int err;
	int i;

	for(i = 0; i < ulCount; i++){
		err = AOCheckBoardChannelFD(uiBoardNumber, puiChannelNumber[i]);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000AOStartSynchronous()", err);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000AOStartSynchronous()", err);
			return err;
		}

		err = AOStartSynchronous(
				&boardContextVec[uiBoardNumber].aoContext[puiChannelNumber[i]],
				iTriggerMode, 
				piExtTriggerEnable[i],
				piExtTriggerEdge[i]);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000AOStartSynchronous()", err);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000AOStartSynchronous()", err);
			return err;
		}
	}

	if(iTriggerMode == ME4000_AO_TRIGGER_SOFTWARE){
		/* Start conversion by the first channel */
		err = AOCheckBoardChannelFD(uiBoardNumber, puiChannelNumber[0]);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000AOStartSynchronous()", err);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000AOStartSynchronous()", err);
			return err;
		}

		err = AOStartSynchronousSoftware(&boardContextVec[uiBoardNumber].aoContext[puiChannelNumber[0]]);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000AOStartSynchronous()", err);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000AOStartSynchronous()", err);
			return err;
		}
	}
	else if(iTriggerMode == ME4000_AO_TRIGGER_EXT_DIGITAL){
		/* Start conversion by any channel which has the external trigger enabled */
		for(i = 0; i < ulCount; i++){
			err = AOCheckBoardChannelFD(uiBoardNumber, puiChannelNumber[i]);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000AOStartSynchronous()", err);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000AOStartSynchronous()", err);
				return err;
			}

			if(piExtTriggerEnable[i]){
				err = AOStartSynchronousTimeout(&boardContextVec[uiBoardNumber].aoContext[puiChannelNumber[i]], ulTimeOutSeconds);
				if(err){
					if(errorDefaultProcFlag)
						errorDefaultProc("me4000AOStartSynchronous()", err);
					else if(errorUserProcPtr)
						errorUserProcPtr("me4000AOStartSynchronous()", err);
					return err;
				}
				break;
			}
		}
	}

	return ME4000_NO_ERROR;
}



int AOStartSynchronous(
		me4000AOContext_t *aoContext,
		int iTriggerMode, 
		int iExtTriggerEnable,
		int iExtTriggerEdge){

	int err;

	switch(iTriggerMode){
		case ME4000_AO_TRIGGER_SOFTWARE:
			err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_DISABLE);
			if(err) return storeSystemError(errno);

			err = ioctl(aoContext->fd, ME4000_AO_SYNCHRONOUS_SW);
			if(err) return storeSystemError(errno);

			break;
		case ME4000_AO_TRIGGER_EXT_DIGITAL:
			err = ioctl(aoContext->fd, ME4000_AO_SYNCHRONOUS_EX_TRIG);
			if(err) return storeSystemError(errno);

			if(iExtTriggerEnable){
				err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_SETUP, &iExtTriggerEdge);
				if(err) return storeSystemError(errno);

				err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_ENABLE);
				if(err) return storeSystemError(errno);
			}
			else{
				err = ioctl(aoContext->fd, ME4000_AO_EX_TRIG_DISABLE);
				if(err) return storeSystemError(errno);
			}
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_TRIGGER_MODE;
			return ERROR_NO_INVALID_TRIGGER_MODE;
	}

	return ME4000_NO_ERROR;
}



int AOStartSynchronousSoftware(me4000AOContext_t *aoContext){
	unsigned long jiffies = 0;
	int err;

	err = ioctl(aoContext->fd, ME4000_AO_START, &jiffies);
	if(err) return storeSystemError(errno);
	return ME4000_NO_ERROR;
}



int AOStartSynchronousTimeout(me4000AOContext_t *aoContext, unsigned long ulTimeOutSeconds){
	unsigned long jiffies = HZ * ulTimeOutSeconds;
	int err;

	err = ioctl(aoContext->fd, ME4000_AO_START, &jiffies);
	if(err) return storeSystemError(errno);
	return ME4000_NO_ERROR;
}



int me4000AOStop(
		unsigned int uiBoardNumber, 
		unsigned int uiChannelNumber, 
		int iStopMode){
	int err;

	err = AOCheckBoardChannelFD(uiBoardNumber, uiChannelNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOStop()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOStop()", err);
		return err;
	}

	err = AOStop(&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber], iStopMode);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOStop()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOStop()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AOStop(me4000AOContext_t *aoContext, int iStopMode){
	int err;
	int flags;

	/* Check for callback */
	if(aoContext->pCallback){
		err = pthread_cancel(aoContext->thread);
		if(err){
			my_errno = ERROR_NO_CANCEL_THREAD;
			return ERROR_NO_CANCEL_THREAD;
		}
	}

	/* Stop the conversion */
	if(iStopMode == ME4000_AO_STOP_MODE_LAST_VALUE){
		err = ioctl(aoContext->fd, ME4000_AO_STOP);
		if(err) return storeSystemError(errno);
	}
	else if (iStopMode == ME4000_AO_STOP_MODE_IMMEDIATE){
		err = ioctl(aoContext->fd, ME4000_AO_IMMEDIATE_STOP);
		if(err) return storeSystemError(errno);
	}
	else{
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_STOP_MODE;
		return ERROR_NO_INVALID_STOP_MODE;
	}

	/* Enable prelaoding for the next run */
	flags = fcntl(aoContext->fd, F_GETFL, 0);
	if(flags < 0) return storeSystemError(errno);
	flags &= ~O_APPEND;
	flags = fcntl(aoContext->fd, F_SETFL, flags);
	if(flags < 0) return storeSystemError(errno);

	return ME4000_NO_ERROR;
}


int me4000AOVoltToDigit(double dVolt, unsigned short *pusDigit){

	if(dVolt < -10.0) dVolt = -10.0;
	else if (dVolt > 10.0 - 20.0 / 65536) dVolt = 10.0 - 20.0 / 65536;

	*pusDigit = dVolt * 65536 / 20 + 65536 / 2;
	return ME4000_NO_ERROR;
}



int me4000AOWaveGen(
		unsigned int uiBoardNumber,
		unsigned int uiChannelNumber, 
		int iShape,
		double dAmplitude,
		double dOffset,
		double dFrequency){
	int i;
	int iMin;
	int iMax;
	int fifoUsed;
	double dDivisor;
	unsigned long ulTicks;
	int err;

	unsigned short value;
	unsigned short pusBuffer[ME4000_AO_FIFO_COUNT];

	// check params
	if(iShape < ME4000_AO_SHAPE_RECTANGLE || iShape > ME4000_AO_SHAPE_NEG_RAMP){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_SHAPE;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOWaveGen()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOWaveGen()", my_errno);
		return ERROR_NO_INVALID_SHAPE;
	}

	if(dAmplitude <= 0.0 || dAmplitude > 10.0) {
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_AMPLITUDE;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOWaveGen()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOWaveGen()", my_errno);
		return ERROR_NO_INVALID_AMPLITUDE;
	}

	if(dOffset < -10.0 || dOffset > 10.0){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_OFFSET;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOWaveGen()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOWaveGen()", my_errno);
		return ERROR_NO_INVALID_OFFSET;
	}

	iMin = (int)((-dAmplitude + dOffset + 10) / 20 * 0xffff);
	iMax = (int)((dAmplitude + dOffset + 10) / 20 * 0xffff);

	if(iMin < ME4000_AO_MIN_DIGIT || iMin > ME4000_AO_MAX_DIGIT) {
		errno = EINVAL;
		my_errno = ERROR_NO_AMPLITUDE_OFFSET;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOWaveGen()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOWaveGen()", my_errno);
		return ERROR_NO_AMPLITUDE_OFFSET;
	}

	if(iMax < ME4000_AO_MIN_DIGIT || iMax > ME4000_AO_MAX_DIGIT){
		errno = EINVAL;
		my_errno = ERROR_NO_AMPLITUDE_OFFSET;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOWaveGen()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOWaveGen()", my_errno);
		return ERROR_NO_AMPLITUDE_OFFSET;
	}

	if(dFrequency > ME4000_AO_MAX_FREQUENCY / 2.0){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_FREQUENCY;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOWaveGen()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOWaveGen()", my_errno);
		return ERROR_NO_INVALID_FREQUENCY;
	}

	if(iMin > iMax){
		int iTmp = iMin;
		iMin     = iMax;
		iMax     = iTmp;
	}

	// If Ff is the Frequency with which the DAC operates, Fs is the desired
	// signal frequency and Np is the number of DAC values we use to define
	// one cycle of the signal, then:
	//
	//  Ff = Fs * Np
	//
	// But the DAC frequency Ff is 33 MHz divided by D, where D is the divisor
	// with which we load the ME4000_TIMERREG_DACxx register and which
	// must lie between 66 and 0xFFFFFFFF. So we have:
	//
	// 33000000 / D = Fs * Np
	//
	// or:
	//
	// D = 33000000 / (Fs * Np)
	//
	// We would like to use the largest possible value for Np in order to
	// get the smoothest possible signal. The largest possible value is
	// ME4000_AO_FIFO_SIZE

	fifoUsed = (iShape == ME4000_AO_SHAPE_RECTANGLE) ? 2 : ME4000_AO_FIFO_COUNT;
	dDivisor = ME4000_TIMER_FREQ / (dFrequency * (double)fifoUsed);

	if(dDivisor < ME4000_MIN_TIMER_TICK){
		// We can't use the entire DAC FIFO to define our signal as we would
		// be unable to attain the required frequency. What is the largest
		// number of points which we can use to define our signal and still
		// attain the required frequency?
		//
		// Rearranging the formula above we have:
		//
		// Np = 33000000 / (D * Fs);
		//
		// Since the smallest value of D is 66, we obtain for the largest
		// value of Np:

		fifoUsed = (int)(ME4000_TIMER_FREQ / (ME4000_MIN_TIMER_TICK * dFrequency));

		// All of the signal forms except AO_xxx_RAMP are symmetrical, and to
		// cleanly define the minima and maxima we need an even number of points
		// to a cycle

		// check if not less than 5 points
		if(fifoUsed < 5){
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_FREQUENCY;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000AOWaveGen()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000AOWaveGen()", my_errno);
			return ERROR_NO_INVALID_FREQUENCY;
		}

		// Now all we need to do is calculate the corresponding divisor
		dDivisor = ME4000_TIMER_FREQ / (dFrequency * (double)fifoUsed);
	}

	// We round the frequency up (by rounding the divisor down) as we assume
	// that if the exact frequency required cannot be obtained, then a slightly
	// higher frequency is preferable to a lower frequency
	ulTicks = (int)dDivisor;

	// Now load the buffer with the appropriate values
	for(i = 0; i < fifoUsed; i++){
		switch(iShape){
			case ME4000_AO_SHAPE_RECTANGLE:
				value = (i < fifoUsed / 2) ? iMin : iMax;
				break;

			case ME4000_AO_SHAPE_TRIANGLE:
				if( i <= fifoUsed / 2)
					value = iMin + (int)(0.5 + (double)i * 2.0 * (double)(iMax - iMin) / (double)fifoUsed);
				else
					value = iMax - (int)(0.5 + (double)(i - fifoUsed / 2) * 2.0 * (double)(iMax - iMin) / (double)fifoUsed);
				break;

			case ME4000_AO_SHAPE_SINUS:
				{ 
					double val = (sin( (double)i / (double)fifoUsed * 2.0 * 3.14159 ) + 1.0) * (double)(iMax - iMin) / 2.0;
					value = iMin + (int)val;
					break;
				}

			case ME4000_AO_SHAPE_COSINUS:
				{
					double val = (cos( (double)i / (double)fifoUsed * 2.0 * 3.14159 ) + 1.0) * (double)(iMax - iMin) / 2.0;
					value = iMin + (int)val;
					break;
				}

			case ME4000_AO_SHAPE_POS_RAMP:
				value = iMin + (int)( 0.5 + (double)i * (double)(iMax - iMin) / (double)(fifoUsed-1) );
				break;

			case ME4000_AO_SHAPE_NEG_RAMP:
				value = iMax - (int)( 0.5 + (double)i * (double)(iMax - iMin) / (double)(fifoUsed-1) );
				break;
		}

		pusBuffer[i] = value;
	}

	err = AOCheckBoardChannelFD(uiBoardNumber, uiChannelNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOWaveGen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOWaveGen()", err);
		return err;
	}

	err = AOStop(&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber], ME4000_AO_STOP_MODE_IMMEDIATE);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOWaveGen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOWaveGen()", err);
		return err;
	}

	err = AOSetTimer(&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber], ulTicks);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOWaveGen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOWaveGen()", err);
		return err;
	}

	err = AOWraparound(&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber], pusBuffer, fifoUsed, 0);
	if(err) return err;

	err = AOStart(&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber]);
	if(err) return err;

	return ME4000_NO_ERROR;
}



/*
 * Only supports asynchronous output with infinite loops because
 * we would have to use a continuous conversion. But we opened
 * the device in wraparound mode.
 */
int me4000AOWraparound(
		unsigned int uiBoardNumber, 
		unsigned int uiChannelNumber, 
		unsigned short *pusBuffer, 
		unsigned long ulDataCount, 
		unsigned long ulLoops,
		int iExecutionMode,
		ME4000_P_AO_TERMINATE_PROC pTerminateProc,
		void *pTerminateContext,
		unsigned long ulTimeOutSeconds){
	int err;

	err = AOCheckBoardChannelFD(uiBoardNumber, uiChannelNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOWraparound()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOWraparound()", err);
		return err;
	}

	if(iExecutionMode != ME4000_AO_WRAPAROUND_ASYNCHRONOUS){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_EXEC_MODE;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOWraparound()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOWraparound()", my_errno);
		return ERROR_NO_INVALID_EXEC_MODE;
	}

	if(ulLoops != ME4000_AO_WRAPAROUND_INFINITE){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_LOOPS;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOWraparound()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOWraparound()", my_errno);
		return ERROR_NO_INVALID_LOOPS;
	}

	err = AOWraparound(
			&boardContextVec[uiBoardNumber].aoContext[uiChannelNumber],
			pusBuffer, 
			ulDataCount, 
			ulTimeOutSeconds);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AOWraparound()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AOWraparound()", err);
		return err;
	}
	return ME4000_NO_ERROR;
}



int AOWraparound(
		me4000AOContext_t *aoContext,
		unsigned short *pusBuffer, 
		unsigned long ulDataCount, 
		unsigned long ulTimeOutSeconds){
	int err;

	aoContext->ulTimeOutSeconds = ulTimeOutSeconds;

	err = write(aoContext->fd, pusBuffer, 2 * ulDataCount);
	if(err != 2 * ulDataCount) return storeSystemError(errno);
	return ME4000_NO_ERROR;
}



/*=============================================================================
  Analog input
  ===========================================================================*/

int AICheckBoard(unsigned int uiBoardNumber){
	if(uiBoardNumber >= board_count){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BOARD;
		return ERROR_NO_INVALID_BOARD;
	}
	return ME4000_NO_ERROR;
}



int AICheckBoardFD(unsigned int uiBoardNumber){
	int err;

	err = AICheckBoard(uiBoardNumber);
	if(err) return err;

	if(boardContextVec[uiBoardNumber].aiContext.fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}
	return ME4000_NO_ERROR;
}



int me4000AIOpen(unsigned int uiBoardNumber, int iAcqMode){
	int err;

	err = AICheckBoard(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIOpen()", err);
		return err;
	}

	if(boardContextVec[uiBoardNumber].aiContext.fd != -1){
		return ME4000_NO_ERROR; // Already open
	}

	err = AIOpen(&boardContextVec[uiBoardNumber].aiContext, uiBoardNumber, iAcqMode);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIOpen()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AIOpen(me4000AIContext_t *aiContext, unsigned int uiBoardNumber, int iAcqMode){
	int err;
	char str[64];

	if(iAcqMode == ME4000_AI_ACQ_MODE_SINGLE){
		snprintf(str, sizeof(str), "/dev/me4000_%u_ai_%s", uiBoardNumber, "single");
	}
	else if(iAcqMode == ME4000_AI_ACQ_MODE_SOFTWARE){
		snprintf(str, sizeof(str), "/dev/me4000_%u_ai_%s", uiBoardNumber, "cont_sw");
	}
	else if(iAcqMode == ME4000_AI_ACQ_MODE_EXT){
		snprintf(str, sizeof(str), "/dev/me4000_%u_ai_%s", uiBoardNumber, "cont_et");
	}
	else if(iAcqMode == ME4000_AI_ACQ_MODE_EXT_SINGLE_VALUE){
		snprintf(str, sizeof(str), "/dev/me4000_%u_ai_%s", uiBoardNumber, "cont_et_value");
	}
	else if(iAcqMode == ME4000_AI_ACQ_MODE_EXT_SINGLE_CHANLIST){
		snprintf(str, sizeof(str), "/dev/me4000_%u_ai_%s", uiBoardNumber, "cont_et_chanlist");
	}
	else {
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_ACQ_MODE;
		return ERROR_NO_INVALID_ACQ_MODE;
	}

	err = open(str, O_RDWR);
	if(err < 0) return storeSystemError(errno);
	aiContext->fd = err;
	aiContext->iAcqMode = iAcqMode;

	return ME4000_NO_ERROR;
}



int me4000AIClose(unsigned int uiBoardNumber){
	int err;

	err = AICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIClose()", err);
		return err;
	}

	err = AIClose(&boardContextVec[uiBoardNumber].aiContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIClose()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AIClose(me4000AIContext_t *aiContext){
	int err;

	err = close(aiContext->fd);
	if(err) return storeSystemError(errno);
	aiContext->fd = -1;
	return ME4000_NO_ERROR;
}



int me4000AIMakeChannelListEntry(
		unsigned int uiChannelNumber, 
		int iRange, 
		unsigned char *pucChanListEntry){

	/* Check the first parameter
	   A further check on the channel number must be carried out when
	   the channel list is used to program a particular board in 
	   me4000AIWriteChannelList below. (ME4650 has only 16 AI channels). */
	if(uiChannelNumber > ME4000_AI_MAX_CHANNELS - 1){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_CHANNEL;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIMakeChannelListEntry()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIMakeChannelListEntry()", my_errno);
		return ERROR_NO_INVALID_CHANNEL;
	}

	// Check the second parameter
	switch(iRange){
		case ME4000_AI_RANGE_BIPOLAR_10:
			iRange = ME4000_AI_LIST_RANGE_BIPOLAR_10;
			break;
		case ME4000_AI_RANGE_BIPOLAR_2_5:
			iRange = ME4000_AI_LIST_RANGE_BIPOLAR_2_5;
			break;
		case ME4000_AI_RANGE_UNIPOLAR_10:
			iRange = ME4000_AI_LIST_RANGE_UNIPOLAR_10;
			break;
		case ME4000_AI_RANGE_UNIPOLAR_2_5:
			iRange = ME4000_AI_LIST_RANGE_UNIPOLAR_2_5;
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_RANGE;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000AIMakeChannelListEntry()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000AIMakeChannelListEntry()", my_errno);
			return ERROR_NO_INVALID_RANGE;
	}

	/* Build the channel entry */
	*pucChanListEntry = uiChannelNumber | iRange;
	return ME4000_NO_ERROR;
}



int me4000AIReset(unsigned int uiBoardNumber){
	int err;

	err = AICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIReset()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIReset()", err);
		return err;
	}

	err = AIStop(&boardContextVec[uiBoardNumber].aiContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIReset()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIReset()", err);
		return err;
	}
	return ME4000_NO_ERROR;
}



int me4000AIConfig(
		unsigned int uiBoardNumber, 
		unsigned char *pucChanList, 
		unsigned int uiChanListCount, 
		int iSDMode, 
		int iSimultaneous,
		unsigned long ulReserved,
		unsigned long ulChanTicks, 
		unsigned long ulScanTicksLow, 
		unsigned long ulScanTicksHigh, 
		int iAcqMode,
		int iExtTriggerMode, 
		int iExtTriggerEdge){
	int err;

	err = AICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIConfig()", err);
		return err;
	}

	err = AIConfig(
			&boardContextVec[uiBoardNumber].aiContext,
			pucChanList, 
			uiChanListCount, 
			iSDMode, 
			iSimultaneous,
			ulReserved,
			ulChanTicks, 
			ulScanTicksLow, 
			ulScanTicksHigh, 
			iExtTriggerMode, 
			iExtTriggerEdge);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIConfig()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AIConfig(
		me4000AIContext_t *aiContext,
		unsigned char *pucChanList, 
		unsigned int uiChanListCount, 
		int iSDMode, 
		int iSimultaneous,
		unsigned long ulReserved,
		unsigned long ulChanTicks, 
		unsigned long ulScanTicksLow, 
		unsigned long ulScanTicksHigh, 
		int iExtTriggerMode, 
		int iExtTriggerEdge){
	int err;
	int i;
	me4000_ai_config_t config;
	me4000_ai_trigger_t trigger;
	unsigned long long scan;
	unsigned long pulChanList[uiChanListCount];

	for(i = 0; i < uiChanListCount; i++){
		pulChanList[i] = pucChanList[i];
	}

	if(aiContext->iAcqMode == ME4000_AI_ACQ_MODE_SINGLE){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_ACQ_MODE;
		return ERROR_NO_INVALID_ACQ_MODE;
	}

	/* Check size of channel list */
	if(uiChanListCount == 0 || uiChanListCount > ME4000_AI_CHANNEL_LIST_COUNT){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_CHANLIST;
		return ERROR_NO_INVALID_CHANLIST;
	}

	/* Input mode must be equal for all entries */
	for(i = 0; i < uiChanListCount; i++){
		if(iSDMode == ME4000_AI_INPUT_SINGLE_ENDED){
			pulChanList[i] |= ME4000_AI_LIST_INPUT_SINGLE_ENDED;
		}
		else if(iSDMode == ME4000_AI_INPUT_DIFFERENTIAL){
			if(aiContext->ai_count < 16){
				errno = EINVAL;
				my_errno = ERROR_NO_NO_DIFF;
				return ERROR_NO_NO_DIFF;
			}
			pulChanList[i] |= ME4000_AI_LIST_INPUT_DIFFERENTIAL;
		}
		else{
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_SDMODE;
			return ERROR_NO_INVALID_SDMODE;
		}
	}

	/* Check if a ME-4610 has range bipolar 10V set */
	if(aiContext->device_id == 0x4610){
		for(i = 0; i < uiChanListCount; i++){
			if((pulChanList[i] & 0xC0) != ME4000_AI_LIST_RANGE_BIPOLAR_10){
				errno = EINVAL;
				my_errno = ERROR_NO_INVALID_RANGE;
				return ERROR_NO_INVALID_RANGE;
			}
		}
	}

	/* Set last entry bit */
	pulChanList[uiChanListCount - 1] |= ME4000_AI_LIST_LAST_ENTRY;

	config.channel_list.list = pulChanList;
	config.channel_list.count = uiChanListCount;

	/* For later usage in me4000AIContinuous */
	aiContext->ulChannelListCount = uiChanListCount;

	/* Check for simultaneous */
	switch(iSimultaneous){
		case ME4000_AI_SIMULTANEOUS_ENABLE:
			if(!aiContext->ai_sh_count){
				errno = EINVAL;
				my_errno = ERROR_NO_NO_SAMPLE_HOLD;
				return ERROR_NO_NO_SAMPLE_HOLD;
			}

			if(ulChanTicks != ME4000_AI_MIN_TICKS){
				errno = EINVAL;
				my_errno = ERROR_NO_SIMULTANEOUS_CHAN;
				return ERROR_NO_SIMULTANEOUS_CHAN;
			}
			break;
		case ME4000_AI_SIMULTANEOUS_DISABLE:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_SIMULTANEOUS;
			return ERROR_NO_SIMULTANEOUS;
	}
	config.sh = iSimultaneous;

	/* Set initial timer value always to lowest */
	config.timer.pre_chan = ME4000_AI_MIN_TICKS;

	/* Check channel timer value */
	if(ulChanTicks < ME4000_AI_MIN_TICKS){
		errno = EINVAL;
		my_errno = ERROR_NO_CHAN_TICKS;
		return ERROR_NO_CHAN_TICKS;
	}
	config.timer.chan = ulChanTicks;

	/* Check scan timer values */
	scan = (unsigned long long) ulScanTicksLow + ((unsigned long long) ulScanTicksHigh << 32);
	if(scan != 0){
		if((scan < ulChanTicks * uiChanListCount + ME4000_AI_MIN_TICKS) || (scan > ME4000_AI_MAX_SCAN_TICKS)){
			errno = EINVAL;
			my_errno = ERROR_NO_SCAN_TICKS;
			return ERROR_NO_SCAN_TICKS;
		}
	}
	config.timer.scan_low = ulScanTicksLow;
	config.timer.scan_high = ulScanTicksHigh;

	/* Do the job */
	err = ioctl(aiContext->fd, ME4000_AI_CONFIG, &config);
	if(err) return storeSystemError(errno);

	/* Check for external trigger */
	if(aiContext->iAcqMode != ME4000_AI_ACQ_MODE_SOFTWARE){
		switch(iExtTriggerMode){
			case ME4000_AI_TRIGGER_EXT_ANALOG:
			case ME4000_AI_TRIGGER_EXT_DIGITAL:
				break;
			default:
				errno = EINVAL;
				my_errno = ERROR_NO_INVALID_TRIGGER_MODE;
				return ERROR_NO_INVALID_TRIGGER_MODE;
		}
		trigger.mode = iExtTriggerMode;

		switch(iExtTriggerEdge){
			case ME4000_AI_TRIGGER_EXT_EDGE_RISING:
			case ME4000_AI_TRIGGER_EXT_EDGE_FALLING:
			case ME4000_AI_TRIGGER_EXT_EDGE_BOTH:
				break;
			default:
				errno = EINVAL;
				my_errno = ERROR_NO_INVALID_TRIGGER_EDGE;
				return ERROR_NO_INVALID_TRIGGER_EDGE;
		}
		trigger.edge = iExtTriggerEdge;

		/* Do the job */
		err = ioctl(aiContext->fd, ME4000_AI_EX_TRIG_SETUP, &trigger);
		if(err) return storeSystemError(errno);

		err = ioctl(aiContext->fd, ME4000_AI_EX_TRIG_ENABLE);
		if(err) return storeSystemError(errno);
	}

	return ME4000_NO_ERROR;
}



int me4000AIContinuous(
		unsigned int uiBoardNumber,
		ME4000_P_AI_CALLBACK_PROC pCallbackProc, 
		void *pCallbackContext, 
		unsigned int uiRefreshFrequency,
		unsigned long ulTimeOutSeconds){
	int err;

	err = AICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIContinuous()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIContinuous()", err);
		return err;
	}

	err = AIContinuous(
			&boardContextVec[uiBoardNumber].aiContext,
			pCallbackProc, 
			pCallbackContext, 
			uiRefreshFrequency,
			ulTimeOutSeconds);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIContinuous()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIContinuous()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AIContinuous(
		me4000AIContext_t *aiContext,
		ME4000_P_AI_CALLBACK_PROC pCallbackProc, 
		void *pCallbackContext, 
		unsigned int uiRefreshFrequency,
		unsigned long ulTimeOutSeconds){

	/* Mark that continuous is adjusted */
	aiContext->iExecutionMode = ME4000_AI_SCAN_CONTINUOUS;

	/* No user buffers needed so reset the entries */
	aiContext->psAIBuffer = NULL;
	aiContext->ulAIBufferCount = 0;

	aiContext->pCallback = pCallbackProc;
	aiContext->pCallbackContext = pCallbackContext;

	/* Check callback parameter */
	if(pCallbackProc){
		if(uiRefreshFrequency == 0){
			errno = EINVAL;
			my_errno = ERROR_NO_REFRESH_FREQUENCY;
			return ERROR_NO_REFRESH_FREQUENCY;
		}
	}
	aiContext->ulRefreshFrequency = uiRefreshFrequency;

	/* No terminate function needed so reset entries */
	aiContext->pTerminateFunc = NULL;
	aiContext->pTerminateContext = NULL;
	aiContext->ulTimeOutSeconds = ulTimeOutSeconds;

	return ME4000_NO_ERROR;
}



int me4000AIDigitToVolt(
		short sDigit, 
		int iRange, 
		double *pdVolt){

	/* Initialise the converted value to 0.0 */
	*pdVolt = 0.0;

	switch(iRange){
		case ME4000_AI_RANGE_BIPOLAR_10:
			*pdVolt = 20.0 / 65536.0 * sDigit;
			break;

		case ME4000_AI_RANGE_BIPOLAR_2_5:
			*pdVolt = 5.0 / 65536.0 * sDigit;
			break;

		case ME4000_AI_RANGE_UNIPOLAR_10:
			*pdVolt = 10.0 / 65536.0 * sDigit + 5.0;
			break;

		case ME4000_AI_RANGE_UNIPOLAR_2_5:
			*pdVolt = 2.5 / 65536.0 * sDigit + 1.25;
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_RANGE;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000AIDigitToVolt()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000AIDigitToVolt()", my_errno);
			return ERROR_NO_INVALID_RANGE;
	}

	return ME4000_NO_ERROR;
}



int me4000AIDigitToVoltAdjusted(
		unsigned int uiBoardNumber,
		short sDigit, 
		int iRange, 
		int iSDMode, 
		double *pdVolt){
	int err;
	me4000_adjust_t *adjust;

	/* Initialise the converted value to 0.0 */
	*pdVolt = 1.0;

	err = AICheckBoard(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIDigitToVoltAdjusted()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIDigitToVoltAdjusted()", err);
		return err;
	}

	adjust = &boardContextVec[uiBoardNumber].aiContext.adjust_table;

	switch(iRange){
		case ME4000_AI_RANGE_BIPOLAR_10:
			if(iSDMode == ME4000_AI_INPUT_SINGLE_ENDED){
				*pdVolt = adjust->a_bi_10 * sDigit + adjust->b_bi_10;
			}
			else if(iSDMode == ME4000_AI_INPUT_DIFFERENTIAL){
				*pdVolt = adjust->a_diff_10 * sDigit + adjust->b_diff_10;
			}
			else{
				errno = EINVAL;
				my_errno = ERROR_NO_INVALID_SDMODE;
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000AIDigitToVoltAdjusted()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000AIDigitToVoltAdjusted()", my_errno);
				return ERROR_NO_INVALID_SDMODE;
			}

			break;

		case ME4000_AI_RANGE_BIPOLAR_2_5:
			if(iSDMode == ME4000_AI_INPUT_SINGLE_ENDED){
				*pdVolt = adjust->a_bi_2_5 * sDigit + adjust->b_bi_2_5;
			}
			else if(iSDMode == ME4000_AI_INPUT_DIFFERENTIAL){
				*pdVolt = adjust->a_diff_2_5 * sDigit + adjust->b_diff_2_5;
			}
			else{
				errno = EINVAL;
				my_errno = ERROR_NO_INVALID_SDMODE;
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000AIDigitToVoltAdjusted()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000AIDigitToVoltAdjusted()", my_errno);
				return ERROR_NO_INVALID_SDMODE;
			}

			break;
		case ME4000_AI_RANGE_UNIPOLAR_10:
			*pdVolt = adjust->a_uni_10 * sDigit + adjust->b_uni_10;

			break;
		case ME4000_AI_RANGE_UNIPOLAR_2_5:
			*pdVolt = adjust->a_uni_2_5 * sDigit + adjust->b_uni_2_5;

			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_RANGE;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000AIDigitToVoltAdjusted()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000AIDigitToVoltAdjusted()", my_errno);
			return ERROR_NO_INVALID_RANGE;
	}

	return ME4000_NO_ERROR;
}



int me4000AIExtractValues(
		unsigned int uiChannelNumber, 
		short *psAIBuffer, 
		unsigned long ulAIDataCount, 
		unsigned char *pucChanList, 
		unsigned int uiChanListCount, 
		short *psChanBuffer, 
		unsigned long ulChanBufferSizeValues, 
		unsigned long *pulChanDataCount){
	int b_chan_found = 0;
	unsigned char *p_c_chan = pucChanList;
	unsigned long index_chan = 0;
	unsigned long index_AI_value = 0;

	/* Preset number of data to 0 */
	*pulChanDataCount = 0;

	/* Check the channel number, is it contained in the channel list? */
	for(index_chan = 0; index_chan < uiChanListCount; index_chan++){
		if((unsigned long) (*p_c_chan & 0x1F) == uiChannelNumber){
			b_chan_found = 1;
			break;
		}
		++p_c_chan;
	}

	if(!b_chan_found){
		/* The channel whose values we are required to extract is not even 
		   contained in the channel list */
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_CHANNEL;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIExtractValues()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIExtractValues()", my_errno);
		return ERROR_NO_INVALID_CHANNEL;
	}

	index_chan = 0;

	for(index_AI_value = 0; index_AI_value < ulAIDataCount; index_AI_value++){
		if((unsigned long)(pucChanList[index_chan] & 0x1F) == uiChannelNumber){
			/* This value belongs to the channel we are extracting - Write it to
			   the buffer */
			psChanBuffer[*pulChanDataCount] = psAIBuffer[index_AI_value];

			if(++(*pulChanDataCount) >= ulChanBufferSizeValues){
				/* The data buffer is full! */
				break;
			}
		}

		if(++index_chan >= uiChanListCount){
			index_chan = 0;
		}
	}

	return ME4000_NO_ERROR;
}



int me4000AIGetNewValues(
		unsigned int uiBoardNumber, 
		short *psBuffer, 
		unsigned long ulNumberOfValuesToRead,
		int iExecutionMode,
		unsigned long *pulNumberOfValuesRead,
		int *piLastError){
	int err;

	err = AICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIGetNewValues()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIGetNewValues()", err);
		return err;
	}

	err = AIGetNewValues(
			&boardContextVec[uiBoardNumber].aiContext,
			psBuffer, 
			ulNumberOfValuesToRead,
			iExecutionMode,
			pulNumberOfValuesRead,
			piLastError);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIGetNewValues()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIGetNewValues()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AIGetNewValues(
		me4000AIContext_t *aiContext,
		short *psBuffer, 
		unsigned long ulNumberOfValuesToRead,
		int iExecutionMode,
		unsigned long *pulNumberOfValuesRead,
		int *piLastError){
	int err;
	int flags;

	if(!ulNumberOfValuesToRead){
		err = ioctl(aiContext->fd, ME4000_AI_GET_COUNT_BUFFER, pulNumberOfValuesRead);
		if(err) return storeSystemError(errno);
	}
	else {
		if(aiContext->pCallback){
			errno = ENOSYS;
			my_errno = ERROR_NO_CALLBACK_USED;
			return ERROR_NO_CALLBACK_USED;
		}

		/* Get the flags */
		flags = fcntl(aiContext->fd, F_GETFL, 0);
		if(flags < 0) return storeSystemError(errno);

		if(iExecutionMode == ME4000_AI_GET_NEW_VALUES_BLOCKING){
			flags &= ~O_NONBLOCK;
			err = fcntl(aiContext->fd, F_SETFL, flags);
			if(err < 0) return storeSystemError(errno);
			err = read(aiContext->fd, psBuffer, 2 * ulNumberOfValuesToRead);
			if(err != 2 * ulNumberOfValuesToRead){
				*pulNumberOfValuesRead = 0;
				err = storeSystemError(errno);
				return err;
			}
		}
		else if(iExecutionMode == ME4000_AI_GET_NEW_VALUES_NON_BLOCKING){
			flags |= O_NONBLOCK;
			err = fcntl(aiContext->fd, F_SETFL, flags);
			if(err < 0) return storeSystemError(errno);
			err = read(aiContext->fd, psBuffer, 2 * ulNumberOfValuesToRead);
			if(err == EAGAIN){
				err = 0;
			}
			else if(err < 0){
				*pulNumberOfValuesRead = 0;
				err = storeSystemError(errno);
				return err;
			}
		}
		else {
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_EXEC_MODE;
			return ERROR_NO_INVALID_EXEC_MODE;
		}

		*pulNumberOfValuesRead = err / 2;
	}

	return ME4000_NO_ERROR;
}



int me4000AIGetStatus(
		unsigned int uiBoardNumber,
		int iWaitIdle,
		int *piStatus){
	int err;

	err = AICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIGetStatus()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIGetStatus()", err);
		return err;
	}

	err = AIGetStatus(
			&boardContextVec[uiBoardNumber].aiContext,
			iWaitIdle,
			piStatus);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIGetStatus()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIGetStatus()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AIGetStatus(
		me4000AIContext_t *aiContext,
		int iWaitIdle,
		int *piStatus){
	int err;

	*piStatus = ME4000_AI_STATUS_BUSY;

	if(iWaitIdle == ME4000_AI_WAIT_NONE){
		err = ioctl(aiContext->fd, ME4000_AI_FSM_STATE, piStatus);
		if(err) return storeSystemError(errno);
	}
	else{
		while(*piStatus){
			err = ioctl(aiContext->fd, ME4000_AI_FSM_STATE, piStatus);
			if(err) return storeSystemError(errno);
			usleep(10000);
		}
	}

	return ME4000_NO_ERROR;
}



int me4000AIScan(
		unsigned int uiBoardNumber,
		unsigned int uiNumberOfChanLists,
		short *psBuffer, 
		unsigned long ulBufferSizeValues,
		int iExecutionMode, 
		ME4000_P_AI_CALLBACK_PROC pCallbackProc, 
		void *pCallbackContext, 
		unsigned int uiRefreshFrequency,
		ME4000_P_AI_TERMINATE_PROC pTerminateProc, 
		void *pTerminateContext, 
		unsigned long ulTimeOutSeconds){
	int err;

	err = AICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIScan()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIScan()", err);
		return err;
	}

	err = AIScan(
			&boardContextVec[uiBoardNumber].aiContext,
			uiNumberOfChanLists,
			psBuffer, 
			ulBufferSizeValues,
			iExecutionMode, 
			pCallbackProc, 
			pCallbackContext, 
			uiRefreshFrequency,
			pTerminateProc, 
			pTerminateContext, 
			ulTimeOutSeconds);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIScan()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIScan()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AIScan(
		me4000AIContext_t *aiContext,
		unsigned int uiNumberOfChanLists,
		short *psBuffer, 
		unsigned long ulBufferSizeValues,
		int iExecutionMode, 
		ME4000_P_AI_CALLBACK_PROC pCallbackProc, 
		void *pCallbackContext, 
		unsigned int uiRefreshFrequency,
		ME4000_P_AI_TERMINATE_PROC pTerminateProc, 
		void *pTerminateContext, 
		unsigned long ulTimeOutSeconds){

	/* Check execution mode */
	switch(iExecutionMode){
		case ME4000_AI_SCAN_BLOCKING:
		case ME4000_AI_SCAN_ASYNCHRONOUS:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_EXEC_MODE;
			return ERROR_NO_INVALID_EXEC_MODE;
	}

	/* Check callback parameter */
	if(pCallbackProc){
		if(uiRefreshFrequency == 0){
			errno = EINVAL;
			my_errno = ERROR_NO_REFRESH_FREQUENCY;
			return ERROR_NO_REFRESH_FREQUENCY;
		}
	}

	aiContext->iExecutionMode = iExecutionMode;

	aiContext->psAIBuffer = psBuffer;
	aiContext->ulAIBufferCount = ulBufferSizeValues;

	aiContext->pCallback = pCallbackProc;
	aiContext->pCallbackContext = pCallbackContext;

	aiContext->ulRefreshFrequency = uiRefreshFrequency;

	aiContext->pTerminateFunc = pTerminateProc;
	aiContext->pTerminateContext = pTerminateContext;

	aiContext->ulTimeOutSeconds = ulTimeOutSeconds;

	return ME4000_NO_ERROR;
}



static void * me4000AIContAsync(void *arg){
	contMeasurement((me4000AIContext_t *) arg);
	return NULL;
}



int contMeasurement(me4000AIContext_t *context){
	int err;
	int ret;
	int cycle;
	me4000_ai_sc_t scSetup;
	int flags;
	short *values;
	unsigned long ulJiffies;

	/* Values per call to pCallback */
	cycle = context->ulChannelListCount * context->ulRefreshFrequency;

	/* Allocate buffer to hold the new values */
	values = malloc(sizeof(short) * cycle);
	if(!values){
		err = storeSystemError(errno);
		context->pCallback(NULL, 0, context->pCallbackContext, err);
		return err;
	}

	/* Setup sample counter */
	scSetup.value = cycle;
	scSetup.reload = 1;

	err = ioctl(context->fd, ME4000_AI_SC_SETUP, &scSetup);
	if(err){
		err = storeSystemError(errno);
		context->pCallback(NULL, 0, context->pCallbackContext, err);
		return err;
	}

	flags = fcntl(context->fd, F_GETFL, 0);
	if(flags < 0){
		err = storeSystemError(errno);
		context->pCallback(NULL, 0, context->pCallbackContext, err);
		return err;
	}

	flags &= ~O_NONBLOCK;

	flags = fcntl(context->fd, F_SETFL, flags);
	if(flags < 0){
		err = storeSystemError(errno);
		context->pCallback(NULL, 0, context->pCallbackContext, err);
		return err;
	}

	/* Start conversion */
	ulJiffies = HZ * context->ulTimeOutSeconds;
	err = ioctl(context->fd, ME4000_AI_START, &ulJiffies);
	if(err){
		err = storeSystemError(errno);
		context->pCallback(NULL, 0, context->pCallbackContext, err);
		return err;
	}

	/* Read the values for ever */
	while(1){
		ret = read(context->fd, values, cycle * 2);
		if(ret != cycle * 2){
			err = storeSystemError(errno);
			context->pCallback(NULL, 0, context->pCallbackContext, err);
			return err;
		}
		context->pCallback(values, ret / 2, context->pCallbackContext, ME4000_NO_ERROR);
	}

	return ME4000_NO_ERROR; // You will never get there
}



static void * me4000AIScanAsync(void *arg){
	scanMeasurement((me4000AIContext_t *) arg);
	return NULL;
}



int scanMeasurement(me4000AIContext_t *context){
	int err;
	int i;
	int ret;
	int cycle;
	me4000_ai_sc_t scSetup;
	fd_set readfds;
	int flags;
	unsigned long ulJiffies;

	if(context->pCallback){
		/* Values per count */
		cycle = context->ulRefreshFrequency * context->ulChannelListCount;

		/* Setup sample counter */
		scSetup.value = cycle;
		scSetup.reload = 1;

		err = ioctl(context->fd, ME4000_AI_SC_SETUP, &scSetup);
		if(err){
			err = storeSystemError(errno);
			context->pCallback(NULL, 0, context->pCallbackContext, err);
			return err;
		}

		/* Start conversion */
		ulJiffies = HZ * context->ulTimeOutSeconds;
		err = ioctl(context->fd, ME4000_AI_START, &ulJiffies);
		if(err){
			err = storeSystemError(errno);
			context->pCallback(NULL, 0, context->pCallbackContext, err);
			return err;
		}

		flags = fcntl(context->fd, F_GETFL, 0);
		if(flags < 0){
			err = storeSystemError(errno);
			context->pCallback(NULL, 0, context->pCallbackContext, err);
			return err;
		}

		flags |= O_NONBLOCK;

		flags = fcntl(context->fd, F_SETFL, flags);
		if(flags < 0){
			err = storeSystemError(errno);
			context->pCallback(NULL, 0, context->pCallbackContext, err);
			return err;
		}

		/* Read the values */
		for(i = 0; i < context->ulAIBufferCount; i += ret / 2){
			/* prepare the readfds */
			FD_ZERO(&readfds);
			FD_SET(context->fd, &readfds);

			err = select(context->fd + 1, &readfds, NULL, NULL, NULL);
			if(err < 0){
				err = storeSystemError(errno);
				context->pCallback(NULL, 0, context->pCallbackContext, err);
				return err;
			}

			if(FD_ISSET(context->fd, &readfds)){
				ret = read(context->fd, &context->psAIBuffer[i], cycle * 2);
				if(ret != cycle * 2){
					err = storeSystemError(errno);
					context->pCallback(NULL, 0, context->pCallbackContext, err);
					return err;
				}
				context->pCallback(&context->psAIBuffer[i], ret / 2, context->pCallbackContext, 0);
			}
		}

		flags &= ~O_NONBLOCK;

		flags = fcntl(context->fd, F_SETFL, flags);
		if(flags < 0){
			err = storeSystemError(errno);
			context->pCallback(NULL, 0, context->pCallbackContext, err);
			return err;
		}
	}
	else{
		/* Setup sample counter */
		scSetup.value = context->ulAIBufferCount;
		scSetup.reload = 0;
		err = ioctl(context->fd, ME4000_AI_SC_SETUP, &scSetup);
		if(err) return storeSystemError(errno);

		/* Start conversion */
		ulJiffies = HZ * context->ulTimeOutSeconds;
		err = ioctl(context->fd, ME4000_AI_START, &ulJiffies);
		if(err) return storeSystemError(errno);

		/* Read values */
		ret = read(context->fd, context->psAIBuffer, context->ulAIBufferCount * 2);
		if(ret != context->ulAIBufferCount * 2) return storeSystemError(errno);
	}

	err = ioctl(context->fd, ME4000_AI_IMMEDIATE_STOP);
	if(err){
		err = storeSystemError(errno);
		if(context->pTerminateFunc){
			context->pTerminateFunc(
					context->psAIBuffer,
					context->ulAIBufferCount,
					context->pTerminateContext,
					err);
		}
		return err;
	}

	if(context->pTerminateFunc){
		context->pTerminateFunc(
				context->psAIBuffer,
				context->ulAIBufferCount,
				context->pTerminateContext,
				ME4000_NO_ERROR);
	}

	return ME4000_NO_ERROR;
}



int me4000AISingle(
		unsigned int uiBoardNumber, 
		unsigned int uiChannelNumber,
		int iRange, 
		int iSDMode, 
		int iTriggerMode,
		int iExtTriggerEdge, 
		unsigned long ulTimeOutSeconds, 
		short *psDigitalValue){
	int err;

	err = AICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AISingle()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AISingle()", err);
		return err;
	}

	err = AISingle(
			&boardContextVec[uiBoardNumber].aiContext,
			uiChannelNumber,
			iRange, 
			iSDMode, 
			iTriggerMode,
			iExtTriggerEdge, 
			ulTimeOutSeconds, 
			psDigitalValue);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AISingle()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AISingle()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AISingle(
		me4000AIContext_t *aiContext,
		unsigned int uiChannelNumber,
		int iRange, 
		int iSDMode, 
		int iTriggerMode,
		int iExtTriggerEdge, 
		unsigned long ulTimeOutSeconds, 
		short *psDigitalValue){
	me4000_ai_single_t sing;
	me4000_ai_trigger_t trig;
	int err;

	/* Check if channel number and mode is valid */
	if(iSDMode == ME4000_AI_INPUT_DIFFERENTIAL){
		if(aiContext->ai_count < 16){
			errno = EINVAL;
			my_errno = ERROR_NO_NO_DIFF;
			return ERROR_NO_NO_DIFF;
		}

		if (uiChannelNumber > 15){
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_CHANNEL;
			return ERROR_NO_INVALID_CHANNEL;
		}
		iSDMode = ME4000_AI_LIST_INPUT_DIFFERENTIAL;
	}	
	else if(iSDMode == ME4000_AI_INPUT_SINGLE_ENDED){
		if (uiChannelNumber > aiContext->ai_count){
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_CHANNEL;
			return ERROR_NO_INVALID_CHANNEL;
		}
		iSDMode = ME4000_AI_LIST_INPUT_SINGLE_ENDED;
	}
	else {
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_SDMODE;
		return ERROR_NO_INVALID_SDMODE;
	}

	/* Check range */
	switch (iRange){
		case ME4000_AI_RANGE_UNIPOLAR_10:
			iRange = ME4000_AI_LIST_RANGE_UNIPOLAR_10;
			break;
		case ME4000_AI_RANGE_UNIPOLAR_2_5:
			iRange = ME4000_AI_LIST_RANGE_UNIPOLAR_2_5;
			break;
		case ME4000_AI_RANGE_BIPOLAR_10:
			iRange = ME4000_AI_LIST_RANGE_BIPOLAR_10;
			break;
		case ME4000_AI_RANGE_BIPOLAR_2_5:
			iRange = ME4000_AI_LIST_RANGE_BIPOLAR_2_5;
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_RANGE;
			return ERROR_NO_INVALID_RANGE;
	}

	if(aiContext->device_id == 0x4610){
		if(iRange != ME4000_AI_LIST_RANGE_BIPOLAR_10){
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_RANGE;
			return ERROR_NO_INVALID_RANGE;
		}
	}

	sing.channel = uiChannelNumber;
	sing.range = iRange;
	sing.mode = iSDMode;
	sing.timeout = HZ * ulTimeOutSeconds;

	switch(iTriggerMode){
		case ME4000_AI_TRIGGER_EXT_ANALOG:
			if(!aiContext->ai_ex_trig_analog){
				errno = EINVAL;
				my_errno = ERROR_NO_NO_ANALOG;
				return ERROR_NO_NO_ANALOG;
			}
		case ME4000_AI_TRIGGER_EXT_DIGITAL:
			trig.mode = iTriggerMode;

			switch(iExtTriggerEdge){
				case ME4000_AI_TRIGGER_EXT_EDGE_RISING:
				case ME4000_AI_TRIGGER_EXT_EDGE_FALLING:
				case ME4000_AI_TRIGGER_EXT_EDGE_BOTH:
					break;
				default:
					errno = EINVAL;
					my_errno = ERROR_NO_INVALID_TRIGGER_EDGE;
					return ERROR_NO_INVALID_TRIGGER_EDGE;
			}
			trig.edge = iExtTriggerEdge;

			err = ioctl(aiContext->fd, ME4000_AI_EX_TRIG_SETUP, &trig);
			if(err) return storeSystemError(errno);

			err = ioctl(aiContext->fd, ME4000_AI_EX_TRIG_ENABLE);
			if(err) return storeSystemError(errno);
			break;
		case ME4000_AI_TRIGGER_SOFTWARE:
			err = ioctl(aiContext->fd, ME4000_AI_EX_TRIG_DISABLE);
			if(err) return storeSystemError(errno);
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_TRIGGER_MODE;
			return ERROR_NO_INVALID_TRIGGER_MODE;
	}

	err = ioctl(aiContext->fd, ME4000_AI_SINGLE, &sing);
	if(err) return storeSystemError(errno);

	*psDigitalValue = sing.value;

	err = ioctl(aiContext->fd, ME4000_AI_EX_TRIG_DISABLE);
	if(err) return storeSystemError(errno);

	return ME4000_NO_ERROR;
}



int me4000AIStart(unsigned int uiBoardNumber){
	int err;

	err = AICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIStart()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIStart()", err);
		return err;
	}

	err = AIStart(&boardContextVec[uiBoardNumber].aiContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIStart()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIStart()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AIStart(me4000AIContext_t *aiContext){
	int err;
	me4000_ai_sc_t scSetup;
	unsigned long ulJiffies;
	unsigned long cycle;

	if(aiContext->iExecutionMode == ME4000_AI_SCAN_BLOCKING){
		err = scanMeasurement(aiContext);
		if(err){
			return err;
		}
	}
	else if(aiContext->iExecutionMode == ME4000_AI_SCAN_ASYNCHRONOUS){
		err = pthread_create(&aiContext->thread, NULL, me4000AIScanAsync, (void *) aiContext);
		if(err){
			my_errno = ERROR_NO_START_THREAD;
			return ERROR_NO_START_THREAD;
		}
		pthread_detach(aiContext->thread);
	}
	else if(aiContext->iExecutionMode == ME4000_AI_SCAN_CONTINUOUS){
		if(aiContext->pCallback){
			err = pthread_create(&aiContext->thread, NULL, me4000AIContAsync, (void *) aiContext);
			if(err){
				my_errno = ERROR_NO_START_THREAD;
				return ERROR_NO_START_THREAD;
			}
			pthread_detach(aiContext->thread);
		}
		else{
			if(aiContext->ulRefreshFrequency){
				/* Values per call to me4000AIGetNewValues */
				cycle = aiContext->ulChannelListCount * aiContext->ulRefreshFrequency;

				/* Setup sample counter */
				scSetup.value = cycle;
				scSetup.reload = 1;
			}
			else{
				/* Disable sample counter */
				scSetup.value = 0;
				scSetup.reload = 0;
			}

			err = ioctl(aiContext->fd, ME4000_AI_SC_SETUP, &scSetup);
			if(err){
				err = storeSystemError(errno);
				return err;
			}

			ulJiffies = HZ * aiContext->ulTimeOutSeconds;
			err = ioctl(aiContext->fd, ME4000_AI_START, &ulJiffies);
			if(err){
				err = storeSystemError(errno);
				return err;
			}
		}
	}
	else{
		my_errno = ERROR_NO_INVALID_EXEC_MODE;
		return ERROR_NO_INVALID_EXEC_MODE;
	}

	return ME4000_NO_ERROR;
}



int me4000AIStop(unsigned int uiBoardNumber, int iReserved){
	int err;

	err = AICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIStop()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIStop()", err);
		return err;
	}

	err = AIStop(&boardContextVec[uiBoardNumber].aiContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000AIStop()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000AIStop()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int AIStop(me4000AIContext_t *aiContext){
	int err;

	if(aiContext->iExecutionMode != ME4000_AI_SCAN_CONTINUOUS){
		errno = ENOSYS;
		my_errno = ERROR_NO_INVALID_EXEC_MODE;
		return ERROR_NO_INVALID_EXEC_MODE;
	}

	if(aiContext->pCallback){
		err = pthread_cancel(aiContext->thread);
		if(err){
			my_errno = ERROR_NO_CANCEL_THREAD;
			return ERROR_NO_CANCEL_THREAD;
		}
	}

	err = ioctl(aiContext->fd, ME4000_AI_IMMEDIATE_STOP);
	if(err) return storeSystemError(errno);

	return ME4000_NO_ERROR;
}



/*=============================================================================
  Digital I/O functions
  ===========================================================================*/

int DIOCheckBoard(unsigned int uiBoardNumber){
	if(uiBoardNumber >= board_count){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BOARD;
		return ERROR_NO_INVALID_BOARD;
	}
	return ME4000_NO_ERROR;
}



int DIOCheckBoardFD(unsigned int uiBoardNumber){
	int err;

	err = DIOCheckBoard(uiBoardNumber);
	if(err) return err;

	if(boardContextVec[uiBoardNumber].dioContext.fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}

	return ME4000_NO_ERROR;
}



int me4000DIOOpen(unsigned int uiBoardNumber){
	int err;

	err = DIOCheckBoard(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOOpen()", err);
		return err;
	}

	if(boardContextVec[uiBoardNumber].dioContext.fd != -1){
		return ME4000_NO_ERROR; // Already open
	}

	err = DIOOpen(&boardContextVec[uiBoardNumber].dioContext, uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOOpen()", err);
		return err;
	}
	return ME4000_NO_ERROR;
}



int DIOOpen(me4000DIOContext_t *dioContext, unsigned int uiBoardNumber){
	char str[64];
	int err;

	snprintf(str, sizeof(str), "/dev/me4000_%u_dio", uiBoardNumber);

	err = open(str, O_RDWR);
	if(err < 0) return storeSystemError(errno);
	dioContext->fd = err;
	return ME4000_NO_ERROR;
}



int me4000DIOClose(unsigned int uiBoardNumber){
	int err;

	err = DIOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOClose()", err);
		return err;
	}

	err = DIOClose(&boardContextVec[uiBoardNumber].dioContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOClose()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int DIOClose(me4000DIOContext_t *dioContext){
	int err;

	err = close(dioContext->fd);
	if(err) return storeSystemError(errno);
	dioContext->fd = -1;
	return ME4000_NO_ERROR;
}



int me4000DIOConfig(
		unsigned int uiBoardNumber,
		unsigned int uiPortNumber,
		int iPortDirection){
	int err;

	err = DIOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOConfig()", err);
		return err;
	}

	switch(iPortDirection){
		case ME4000_DIO_PORT_INPUT:
		case ME4000_DIO_PORT_OUTPUT:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_PORT_MODE;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000DIOConfig()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000DIOConfig()", my_errno);
			return ERROR_NO_INVALID_PORT_MODE;
	}

	err = DIOConfig(
			&boardContextVec[uiBoardNumber].dioContext,
			uiPortNumber,
			iPortDirection,
			ME4000_DIO_FUNCTION_PATTERN);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOConfig()", err);
		return err;
	}
	return ME4000_NO_ERROR;
}



int DIOConfig(
		me4000DIOContext_t *dioContext, 
		unsigned int uiPortNumber, 
		int iMode, 
		int iFunction){
	me4000_dio_config_t config;
	int err;

	switch(uiPortNumber){
		case ME4000_DIO_PORT_A:
		case ME4000_DIO_PORT_B:
		case ME4000_DIO_PORT_C:
		case ME4000_DIO_PORT_D:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_PORT;
			return ERROR_NO_INVALID_PORT;
	}

	switch(iMode){
		case ME4000_DIO_PORT_INPUT:
		case ME4000_DIO_PORT_OUTPUT:
		case ME4000_DIO_FIFO_LOW:
		case ME4000_DIO_FIFO_HIGH:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_PORT_MODE;
			return ERROR_NO_INVALID_PORT_MODE;
	}

	switch(iFunction){
		case ME4000_DIO_FUNCTION_PATTERN:
		case ME4000_DIO_FUNCTION_DEMUX:
		case ME4000_DIO_FUNCTION_MUX:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_PORT_FUNCTION;
			return ERROR_NO_INVALID_PORT_FUNCTION;
	}

	config.port = uiPortNumber;
	config.mode = iMode;
	config.function = iFunction;

	err = ioctl(dioContext->fd, ME4000_DIO_CONFIG, &config);
	if(err) return storeSystemError(errno);

	return ME4000_NO_ERROR;
}



int me4000DIOGetBit(
		unsigned int uiBoardNumber,
		unsigned int uiPortNumber,
		unsigned int uiBitNumber,
		int *piBitValue){
	unsigned char byte;
	int err;

	err = DIOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOGetBit()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOGetBit()", err);
		return err;
	}

	if(uiBitNumber > 7){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BIT;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOGetBit()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOGetBit()", my_errno);
		return ERROR_NO_INVALID_BIT;
	}

	err = DIOGetByte(&boardContextVec[uiBoardNumber].dioContext, uiPortNumber, &byte);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOGetBit()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOGetBit()", err);
		return err;
	}

	*piBitValue = (byte & (0x1 << uiBitNumber)) ? 1 : 0;

	return ME4000_NO_ERROR;
}



int me4000DIOGetByte(
		unsigned int uiBoardNumber,
		unsigned int uiPortNumber,
		unsigned char *pucByteValue){
	int err;

	err = DIOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOGetByte()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOGetByte()", err);
		return err;
	}

	err = DIOGetByte(&boardContextVec[uiBoardNumber].dioContext, uiPortNumber, pucByteValue);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOGetByte()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOGetByte()", err);
		return err;
	}
	return ME4000_NO_ERROR;
}



int DIOGetByte(
		me4000DIOContext_t *dioConfig,
		unsigned int uiPortNumber,
		unsigned char *pucByteValue){
	me4000_dio_byte_t cmd;
	int err;

	switch(uiPortNumber){
		case ME4000_DIO_PORT_A:
		case ME4000_DIO_PORT_B:
		case ME4000_DIO_PORT_C:
		case ME4000_DIO_PORT_D:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_PORT;
			return ERROR_NO_INVALID_PORT;
	}

	cmd.port = uiPortNumber;

	err = ioctl(dioConfig->fd, ME4000_DIO_GET_BYTE, &cmd);
	if(err) return storeSystemError(errno);

	*pucByteValue = cmd.byte;
	return ME4000_NO_ERROR;
}



int me4000DIOResetAll(unsigned int uiBoardNumber){
	int err;

	err = DIOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOResetAll()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOResetAll()", err);
		return err;
	}

	err = ResetAll(&boardContextVec[uiBoardNumber].dioContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOResetAll()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOResetAll()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int ResetAll(me4000DIOContext_t *dioContext){
	int err;

	err = ioctl(dioContext->fd, ME4000_DIO_RESET);
	if(err) return storeSystemError(errno);

	return ME4000_NO_ERROR;
}



int me4000DIOSetBit(
		unsigned int uiBoardNumber,
		unsigned int uiPortNumber,
		unsigned int uiBitNumber,
		int iBitValue){
	unsigned char byte;
	int err;

	err = DIOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOSetBit()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOSetBit()", err);
		return err;
	}

	if(uiBitNumber > 7){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BIT;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOSetBit()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOSetBit()", my_errno);
		return ERROR_NO_INVALID_BIT;
	}

	err = DIOGetByte(&boardContextVec[uiBoardNumber].dioContext, uiPortNumber, &byte);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOSetBit()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOSetBit()", err);
		return err;
	}

	if(iBitValue)
		byte |= (0x1 << uiBitNumber);
	else
		byte &= ~(0x1 << uiBitNumber);

	err = DIOSetByte(&boardContextVec[uiBoardNumber].dioContext, uiPortNumber, byte);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOSetBit()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOSetBit()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000DIOSetByte(
		unsigned int uiBoardNumber,
		unsigned int uiPortNumber,
		unsigned char ucByteValue){
	int err;

	err = DIOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOSetByte()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOSetByte()", err);
		return err;
	}

	err = DIOSetByte(&boardContextVec[uiBoardNumber].dioContext, uiPortNumber, ucByteValue);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOSetByte()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOSetByte()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int DIOSetByte(
		me4000DIOContext_t *dioContext,
		unsigned int uiPortNumber,
		unsigned char ucByteValue){
	me4000_dio_byte_t cmd;
	int err;

	switch(uiPortNumber){
		case ME4000_DIO_PORT_A:
		case ME4000_DIO_PORT_B:
		case ME4000_DIO_PORT_C:
		case ME4000_DIO_PORT_D:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_PORT;
			return ERROR_NO_INVALID_PORT;
	}

	cmd.port = uiPortNumber;
	cmd.byte = ucByteValue;

	err = ioctl(dioContext->fd, ME4000_DIO_SET_BYTE, &cmd);
	if(err) return storeSystemError(errno);

	return ME4000_NO_ERROR;
}



/*===========================================================================
  Counter routines
  =========================================================================*/

int cntCheckBoard(unsigned int uiBoardNumber){
	if(uiBoardNumber >= board_count){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BOARD;
		return ERROR_NO_INVALID_BOARD;
	}
	return ME4000_NO_ERROR;
}



int cntCheckBoardFD(unsigned int uiBoardNumber){
	int err;

	err = cntCheckBoard(uiBoardNumber);
	if(err) return err;

	if(boardContextVec[uiBoardNumber].cntContext.fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}
	return ME4000_NO_ERROR;
}



int me4000CntOpen(unsigned int uiBoardNumber){
	int err;

	err = cntCheckBoard(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntOpen()", err);
		return err;
	}

	if(boardContextVec[uiBoardNumber].cntContext.fd != -1){
		return ME4000_NO_ERROR; // Already open
	}

	err = cntOpen(&boardContextVec[uiBoardNumber].cntContext, uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntOpen()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int cntOpen(me4000CntContext_t *cntContext, unsigned int uiBoardNumber){
	char str[64] = {0};
	int err;

	snprintf(str, sizeof(str), "/dev/me4000_%u_cnt", uiBoardNumber);

	err = open(str, O_RDWR);
	if(err < 0) return storeSystemError(errno);
	cntContext->fd = err;
	return ME4000_NO_ERROR;
}



int me4000CntClose(unsigned int uiBoardNumber){
	int err;

	err = cntCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntClose()", err);
		return err;
	}

	err = cntClose(&boardContextVec[uiBoardNumber].cntContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntClose()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int cntClose(me4000CntContext_t *cntContext){
	int err;

	err = close(cntContext->fd);
	if(err) return storeSystemError(errno);

	cntContext->fd = -1;
	return ME4000_NO_ERROR;
}



int me4000CntWrite(
		unsigned int uiBoardNumber,
		unsigned int uiCounterNumber,
		int iMode,
		unsigned short usValue){
	int err;

	err = cntCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntWrite()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntWrite()", my_errno);
		return err;
	}

	err = cntWrite(&boardContextVec[uiBoardNumber].cntContext, uiCounterNumber, iMode, usValue);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntWrite()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntWrite()", my_errno);
		return err;
	}
	return ME4000_NO_ERROR;
}


int cntWrite(
		me4000CntContext_t *cntContext,
		unsigned int uiCounterNumber,
		int iMode,
		unsigned short usValue){
	int err;
	me4000_cnt_config_t config;
	me4000_cnt_t start;

	switch(uiCounterNumber){
		case ME4000_CNT_COUNTER_0:
		case ME4000_CNT_COUNTER_1:
		case ME4000_CNT_COUNTER_2:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_COUNTER;
			return ERROR_NO_INVALID_COUNTER;
	}

	switch(iMode){
		case ME4000_CNT_MODE_0:
		case ME4000_CNT_MODE_1:
		case ME4000_CNT_MODE_2:
		case ME4000_CNT_MODE_3:
		case ME4000_CNT_MODE_4:
		case ME4000_CNT_MODE_5:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_COUNTER_MODE;
			return ERROR_NO_INVALID_COUNTER_MODE;
	}

	config.counter = uiCounterNumber;
	config.mode = iMode;

	err = ioctl(cntContext->fd, ME4000_CNT_CONFIG, &config);
	if(err) return storeSystemError(errno);

	start.counter = uiCounterNumber;
	start.value = usValue;

	err = ioctl(cntContext->fd, ME4000_CNT_WRITE, &start);
	if(err) return storeSystemError(errno);

	return ME4000_NO_ERROR;
}



int me4000CntRead(
		unsigned int uiBoardNumber,
		unsigned int uiCounterNumber,
		unsigned short *pusValue){
	int err;

	err = cntCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntRead()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntRead()", my_errno);
		return err;
	}

	err = cntRead(&boardContextVec[uiBoardNumber].cntContext, uiCounterNumber, pusValue);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntRead()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntRead()", my_errno);
		return err;
	}
	return ME4000_NO_ERROR;
}


int cntRead(
		me4000CntContext_t *cntContext,
		unsigned int uiCounterNumber,
		unsigned short *pusValue){
	int err;
	me4000_cnt_t actual;

	switch(uiCounterNumber){
		case ME4000_CNT_COUNTER_0:
		case ME4000_CNT_COUNTER_1:
		case ME4000_CNT_COUNTER_2:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_COUNTER;
			return ERROR_NO_INVALID_COUNTER;
	}

	actual.counter = uiCounterNumber;

	err = ioctl(cntContext->fd, ME4000_CNT_READ, &actual);
	if(err) return storeSystemError(errno);

	*pusValue = actual.value;
	return ME4000_NO_ERROR;
}



int me4000CntPWMStart(
		unsigned int uiBoardNumber,
		int iPrescaler,
		int iDutyCycle){
	int err;

	err = cntCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntPWMStart()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntPWMStart()", my_errno);
		return err;
	}

	if((iDutyCycle > 99) || (iDutyCycle < 1)){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_DUTY_CYCLE;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntPWMStart()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntPWMStart()", my_errno);
		return ERROR_NO_INVALID_DUTY_CYCLE;
	}

	err = cntWrite(&boardContextVec[uiBoardNumber].cntContext, ME4000_CNT_COUNTER_0, ME4000_CNT_MODE_2, iPrescaler);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntPWMStart()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntPWMStart()", my_errno);
		return err;
	}

	err = cntWrite(&boardContextVec[uiBoardNumber].cntContext, ME4000_CNT_COUNTER_1, ME4000_CNT_MODE_2, 100);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntPWMStart()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntPWMStart()", my_errno);
		return err;
	}

	err = cntWrite(&boardContextVec[uiBoardNumber].cntContext, ME4000_CNT_COUNTER_2, ME4000_CNT_MODE_1, iDutyCycle);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntPWMStart()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntPWMStart()", my_errno);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000CntPWMStop(unsigned int uiBoardNumber){
	int err;

	err = cntCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntPWMStop()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntPWMStop()", my_errno);
		return err;
	}

	err = cntWrite(&boardContextVec[uiBoardNumber].cntContext, ME4000_CNT_COUNTER_2, ME4000_CNT_MODE_1, 0);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000CntPWMStop()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000CntPWMStop()", my_errno);
		return err;
	}

	return ME4000_NO_ERROR;
}



/*===========================================================================
  External interrupt routines
  =========================================================================*/

int ExtIrqCheckBoard(unsigned int uiBoardNumber){

	/* Check if board number is valid */
	if(uiBoardNumber >= board_count){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BOARD;
		return ERROR_NO_INVALID_BOARD;
	}

	return ME4000_NO_ERROR;
}



int ExtIrqCheckBoardFD(unsigned int uiBoardNumber){
	int err;

	err = ExtIrqCheckBoard(uiBoardNumber);
	if(err) return err;

	/* Check if board is open */
	if(boardContextVec[uiBoardNumber].extIntContext.fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}

	return ME4000_NO_ERROR;
}



int me4000ExtIrqOpen(unsigned int uiBoardNumber){
	char str[30];
	int err;

	err = ExtIrqCheckBoard(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqOpen()", err);
		return err;
	}

	/* Check if already open */
	if(boardContextVec[uiBoardNumber].extIntContext.fd != -1){
		return ME4000_NO_ERROR; // Already open
	}


	sprintf(str, "/dev/me4000_%u_ext_int", uiBoardNumber);

	err = open(str, O_RDWR);
	if(err < 0){
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqOpen()", err);
		return err;
	}

	boardContextVec[uiBoardNumber].extIntContext.fd = err;
	return ME4000_NO_ERROR;
}



int me4000ExtIrqClose(unsigned int uiBoardNumber){
	int err;

	err = ExtIrqCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqClose()", err);
		return err;
	}

	err = close(boardContextVec[uiBoardNumber].extIntContext.fd);
	if(err){
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqClose()", err);
		return err;
	}

	boardContextVec[uiBoardNumber].extIntContext.fd = -1;

	return ME4000_NO_ERROR;
}



void ExtIrqHandler(int sig){
	int i;

	if(sig != SIGIO) return;

	/* Call any callback routine installed */
	for(i = 0; i < board_count; i++){
		if(boardContextVec[i].extIntContext.pCallback != NULL){
			boardContextVec[i].extIntContext.pCallback(boardContextVec[i].extIntContext.pCallbackContext);
		}
	}

	return;
}



int me4000ExtIrqEnable(
		unsigned int uiBoardNumber,
		ME4000_P_EXT_IRQ_PROC pCallback,
		void *pCallbackContext){
	int fd;
	int oflags = 0;
	int err = 0;

	err = ExtIrqCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqEnable()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqEnable()", err);
		return err;
	}

	fd = boardContextVec[uiBoardNumber].extIntContext.fd;
	boardContextVec[uiBoardNumber].extIntContext.pCallback= pCallback;
	boardContextVec[uiBoardNumber].extIntContext.pCallbackContext = pCallbackContext;

	err = ioctl(fd, ME4000_EXT_INT_ENABLE);
	if(err){
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqEnable()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqEnable()", err);
		return err;
	}

	/* Install signal handler */
	if(signal(SIGIO, ExtIrqHandler) == SIG_ERR){
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqEnable()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqEnable()", err);
		return err;
	}

	/* Register process as owner of the path */
	err = fcntl(fd, F_SETOWN, getpid());
	if(err == -1){
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqEnable()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqEnable()", err);
		return err;
	}

	/* Ask for the flags set in the path */
	oflags = fcntl(fd, F_GETFL);
	if(oflags == -1){
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqEnable()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqEnable()", err);
		return err;
	}

	/* Set the current process to the asuncronous queue of the driver */
	err = fcntl(fd, F_SETFL, oflags | FASYNC); 
	if(err == -1){
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqEnable()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqEnable()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000ExtIrqDisable(unsigned int uiBoardNumber){
	int fd;
	int oflags = 0;
	int err = 0;

	err = ExtIrqCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqDisable()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqDisable()", err);
		return err;
	}

	fd = boardContextVec[uiBoardNumber].extIntContext.fd;
	boardContextVec[uiBoardNumber].extIntContext.pCallback = NULL;
	boardContextVec[uiBoardNumber].extIntContext.pCallbackContext = NULL;

	err = ioctl(fd, ME4000_EXT_INT_DISABLE);
	if(err){
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqDisable()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqDisable()", err);
		return err;
	}

	/* Install signal handler */
	if(signal(SIGIO, SIG_DFL) == SIG_ERR){
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqDisable()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqDisable()", err);
		return err;
	}

	/* Register process as owner of the path */
	err = fcntl(fd, F_SETOWN, getpid());
	if(err == -1){
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqDisable()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqDisable()", err);
		return err;
	}

	/* Ask for the flags set in the path */
	oflags = fcntl(fd, F_GETFL);
	if(oflags == -1){
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqDisable()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqDisable()", err);
		return err;
	}

	/* Unset the current process to the asuncronous queue of the driver */
	fcntl(fd, F_SETFL, oflags & ~FASYNC); 
	if(err == -1){
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqDisable()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqDisable()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000ExtIrqGetCount(unsigned int uiBoardNumber, unsigned int *puiIrqCount){
	int fd;
	int err = 0;

	err = ExtIrqCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqGetCount()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqGetCount()", err);
		return err;
	}

	fd = boardContextVec[uiBoardNumber].extIntContext.fd;

	err = ioctl(fd, ME4000_EXT_INT_COUNT, puiIrqCount);
	if(err){
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000ExtIrqGetCount()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000ExtIrqGetCount()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



/*===========================================================================
  MultiSig routines
  =========================================================================*/

static int opto_isolated(unsigned long ulBoardNumber){
	unsigned short version;

	me4000GetBoardVersion(ulBoardNumber, &version);

	switch(version){
		case 0x4661:
		case 0x4663:
		case 0x4671:
		case 0x4673:
		case 0x4681:
		case 0x4683:
			return 1;
		default:
			return ME4000_NO_ERROR;
	}

	return ME4000_NO_ERROR;
}



int MultiSigCheckBoard(unsigned int uiBoardNumber){
	if(uiBoardNumber >= board_count){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BOARD;
		return ERROR_NO_INVALID_BOARD;
	}
	return ME4000_NO_ERROR;
}



int MultiSigCheckBoardFD(unsigned int uiBoardNumber){
	int err;

	err = MultiSigCheckBoard(uiBoardNumber);
	if(err) return err;

	if(boardContextVec[uiBoardNumber].multiSigContext.dioContext.fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigOpen(unsigned int uiBoardNumber){
	int err;

	err = MultiSigCheckBoard(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigOpen()", err);
		return err;
	}

	if(boardContextVec[uiBoardNumber].multiSigContext.dioContext.fd != -1){
		return ME4000_NO_ERROR; // Already open
	}

	err = DIOOpen(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigOpen()", err);
		return err;
	}

	err =  DIOConfig(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_A, ME4000_DIO_PORT_OUTPUT, 0);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigOpen()", err);
		DIOClose(&boardContextVec[uiBoardNumber].dioContext);
		return err;
	}

	if(opto_isolated(uiBoardNumber)){
		err =  DIOConfig(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_C, ME4000_DIO_PORT_OUTPUT, 0);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigOpen()", err);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigOpen()", err);
			DIOClose(&boardContextVec[uiBoardNumber].dioContext);
			return err;
		}
	}
	else{
		err =  DIOConfig(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_B, ME4000_DIO_PORT_OUTPUT, 0);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigOpen()", err);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigOpen()", err);
			DIOClose(&boardContextVec[uiBoardNumber].dioContext);
			return err;
		}
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigClose(unsigned int uiBoardNumber){
	int err;

	err = MultiSigCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigClose()", err);
		return err;
	}

	err = DIOClose(&boardContextVec[uiBoardNumber].multiSigContext.dioContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigClose()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigReset(unsigned int uiBoardNumber){
	int err;

	err = MultiSigCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigReset()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigReset()", my_errno);
		return err;
	}

	err = DIOSetByte(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_A, 0x00);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigReset()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigReset()", my_errno);
		return err;
	}
	usleep(10000);

	if(opto_isolated(uiBoardNumber)){
		err = DIOSetByte(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_C, 0x00);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigReset()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigReset()", my_errno);
			return err;
		}
	}
	else{
		err = DIOSetByte(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_B, 0x00);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigReset()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigReset()", my_errno);
			return err;
		}
	}

	usleep(10000);
	return ME4000_NO_ERROR;
}



int me4000MultiSigAddressLED(
		unsigned int uiBoardNumber,
		unsigned int uiBase,
		int iLEDStatus){
	int err;

	err = MultiSigCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAddressLED()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAddressLED()", my_errno);
		return err;
	}

	if(uiBase > 7){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_MULTI_SIG_BASE;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAddressLED()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAddressLED()", my_errno);
		return ERROR_NO_INVALID_MULTI_SIG_BASE;
	}

	uiBase = uiBase << 1;

	switch(iLEDStatus){
		case ME4000_MULTISIG_LED_OFF:
		case ME4000_MULTISIG_LED_ON:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_MULTI_SIG_IDENT;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigAddressLED()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigAddressLED()", my_errno);
			return ERROR_NO_INVALID_MULTI_SIG_IDENT;
	}

	err = DIOSetByte(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_A, uiBase | iLEDStatus);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAddressLED()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAddressLED()", my_errno);
		return err;
	}
	usleep(10000);

	if(opto_isolated(uiBoardNumber)){
		err = DIOSetByte(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_C, 0x0F);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigAddressLED()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigAddressLED()", my_errno);
			return err;
		}
		usleep(10000);

		err = DIOSetByte(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_C, 0x0E);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigAddressLED()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigAddressLED()", my_errno);
			return err;
		}
	}
	else{
		err = DIOSetByte(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_B, 0x0F);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigAddressLED()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigAddressLED()", my_errno);
			return err;
		}
		usleep(10000);

		err = DIOSetByte(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_B, 0x0E);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigAddressLED()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigAddressLED()", my_errno);
			return err;
		}
	}

	usleep(10000);
	return ME4000_NO_ERROR;
}



int me4000MultiSigSetGain(
		unsigned int uiBoardNumber, 
		unsigned int uiBase, 
		int iChannelGroup, 
		int iGain){
	int err;

	err = MultiSigCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigSetGain()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigSetGain()", my_errno);
		return err;
	}

	if(uiBase > 7){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_MULTI_SIG_BASE;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigSetGain()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigSetGain()", my_errno);
		return ERROR_NO_INVALID_MULTI_SIG_BASE;
	}
	uiBase = uiBase << 1;

	switch(iGain){
		case ME4000_MULTISIG_GAIN_1:
		case ME4000_MULTISIG_GAIN_10:
		case ME4000_MULTISIG_GAIN_100:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_MULTI_SIG_GAIN;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigSetGain()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigSetGain()", my_errno);
			return ERROR_NO_INVALID_MULTI_SIG_GAIN;
	}
	iGain = iGain << 1;

	switch(iChannelGroup){
		case ME4000_MULTISIG_GROUP_A:
		case ME4000_MULTISIG_GROUP_B:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_MULTI_SIG_GROUP;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigSetGain()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigSetGain()", my_errno);
			return ERROR_NO_INVALID_MULTI_SIG_GROUP;
	}

	err = DIOSetByte(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_A, uiBase | iChannelGroup);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigSetGain()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigSetGain()", my_errno);
		return err;
	}

	usleep(10000);

	if(opto_isolated(uiBoardNumber)){
		err = DIOSetByte(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_C, 0x9 | iGain);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigSetGain()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigSetGain()", my_errno);
			return err;
		}

		usleep(10000);

		err = DIOSetByte(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_C, 0x8 | iGain);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigSetGain()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigSetGain()", my_errno);
			return err;
		}
	}
	else{
		err = DIOSetByte(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_B, 0x9 | iGain);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigSetGain()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigSetGain()", my_errno);
			return err;
		}

		usleep(10000);

		err = DIOSetByte(&boardContextVec[uiBoardNumber].multiSigContext.dioContext, ME4000_DIO_PORT_B, 0x8 | iGain);
		if(err){
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigSetGain()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigSetGain()", my_errno);
			return err;
		}
	}

	usleep(10000);

	return ME4000_NO_ERROR;
}



/*===========================================================================
  Bit Pattern functions
  =========================================================================*/

int DIOBPCheckBoard(unsigned int uiBoardNumber){
	if(uiBoardNumber >= board_count){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BOARD;
		return ERROR_NO_INVALID_BOARD;
	}

	return ME4000_NO_ERROR;
}



int DIOBPCheckBoardFD(unsigned int uiBoardNumber){
	int fd;
	int err;

	err = DIOBPCheckBoard(uiBoardNumber);
	if(err) return err;

	fd = boardContextVec[uiBoardNumber].diobpContext.aoContext.fd;
	if(fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}

	fd = boardContextVec[uiBoardNumber].diobpContext.dioContext.fd;
	if(fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}

	return ME4000_NO_ERROR;
}



int me4000DIOBPOpen(unsigned int uiBoardNumber, int iConversionMode){
	int err;

	err = DIOBPCheckBoard(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPOpen()", err);
		return err;
	}

	if(boardContextVec[uiBoardNumber].diobpContext.aoContext.fd != -1){
		return ME4000_NO_ERROR; // Already open
	}

	switch(iConversionMode){
		case ME4000_DIOBP_CONV_MODE_CONTINUOUS:
		case ME4000_DIOBP_CONV_MODE_WRAPAROUND:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_CONV_MODE;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000DIOBPOpen()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000DIOBPOpen()", my_errno);
			return ERROR_NO_INVALID_CONV_MODE;
	}

	err = AOOpen(&boardContextVec[uiBoardNumber].diobpContext.aoContext, uiBoardNumber, 3, iConversionMode);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPOpen()", err);
		return err;
	}

	err =  DIOOpen(&boardContextVec[uiBoardNumber].diobpContext.dioContext, uiBoardNumber);
	if(err){
		AOClose(&boardContextVec[uiBoardNumber].diobpContext.aoContext);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPOpen()", err);
		return err;
	}

	/* Switch from analog output to digital output */
	err = ioctl(boardContextVec[uiBoardNumber].diobpContext.aoContext.fd, ME4000_AO_ENABLE_DO);
	if(err){
		AOClose(&boardContextVec[uiBoardNumber].diobpContext.aoContext);
		DIOClose(&boardContextVec[uiBoardNumber].diobpContext.dioContext);
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPOpen()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000DIOBPClose(unsigned int uiBoardNumber){
	int err;

	err = DIOBPCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPClose()", err);
		return err;
	}

	err = DIOClose(&boardContextVec[uiBoardNumber].diobpContext.dioContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPClose()", err);
		return err;
	}

	err = AOClose(&boardContextVec[uiBoardNumber].diobpContext.aoContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPClose()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000DIOBPAppendNewValues(
		unsigned int uiBoardNumber,
		unsigned short *pusBuffer, 
		unsigned long ulNumberOfValuesToAppend, 
		int iExecutionMode,
		unsigned long *pulNumberOfValuesAppended){
	int err;

	err = DIOBPCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPAppendNewValues()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPAppendNewValues()", err);
		return err;
	}

	err = AOAppendNewValues(
			&boardContextVec[uiBoardNumber].diobpContext.aoContext,
			pusBuffer,
			ulNumberOfValuesToAppend,
			iExecutionMode,
			pulNumberOfValuesAppended);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPAppendNewValues()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPAppendNewValues()", err);
		return err;
	}
	return ME4000_NO_ERROR;
}



int me4000DIOBPConfig(
		unsigned int uiBoardNumber, 
		unsigned long ulTicks, 
		int iTriggerMode,
		int iExtTriggerEdge){
	int err;

	err = DIOBPCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPConfig()", err);
		return err;
	}

	err = AOConfig(
			&boardContextVec[uiBoardNumber].diobpContext.aoContext,
			ulTicks,
			iTriggerMode, 
			iExtTriggerEdge);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPConfig()", err);
		return err;
	}
	return ME4000_NO_ERROR;
}



int me4000DIOBPContinuous(
		unsigned int uiBoardNumber,
		unsigned short *pusBuffer, 
		unsigned long ulBufferCount, 
		ME4000_P_DIOBP_CALLBACK_PROC pCallback,
		void *pCallbackContext,
		unsigned long ulTimeOutSeconds,
		unsigned long *pulNumberOfValuesWritten){
	int err;

	err = DIOBPCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPContinuous()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPContinuous()", err);
		return err;
	}

	err = AOContinuous(
			&boardContextVec[uiBoardNumber].diobpContext.aoContext,
			pusBuffer, 
			ulBufferCount, 
			pCallback,
			pCallbackContext,
			ulTimeOutSeconds, 
			pulNumberOfValuesWritten);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPContinuous()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPContinuous()", err);
		return err;
	}
	return ME4000_NO_ERROR;
}



int me4000DIOBPGetStatus(
		unsigned int uiBoardNumber,
		int iWaitIdle,
		int *piStatus){
	int err;

	err = DIOBPCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPGetStatus()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPGetStatus()", err);
		return err;
	}

	err = AOGetStatus(
			&boardContextVec[uiBoardNumber].diobpContext.aoContext, 
			iWaitIdle, 
			piStatus);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPGetStatus()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPGetStatus()", err);
		return err;
	}
	return ME4000_NO_ERROR;
}



int me4000DIOBPPortConfig(
		unsigned int uiBoardNumber, 
		unsigned int uiPortNumber, 
		int iOutputMode){
	int err;

	err = DIOBPCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPPortConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPPortConfig()", err);
		return err;
	}

	switch(iOutputMode){
		case ME4000_DIOBP_OUTPUT_MODE_BYTE_LOW:
		case ME4000_DIOBP_OUTPUT_MODE_BYTE_HIGH:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_OUTPUT_MODE;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000DIOBPPortConfig()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000DIOBPPortConfig()", my_errno);
			return ERROR_NO_INVALID_OUTPUT_MODE;
	}

	err = DIOConfig(
			&boardContextVec[uiBoardNumber].diobpContext.dioContext,
			uiPortNumber,
			iOutputMode,
			ME4000_DIO_FUNCTION_PATTERN);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPPortConfig()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPPortConfig()", my_errno);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000DIOBPReset(unsigned int uiBoardNumber){
	int err;
	unsigned short value = 0;
	unsigned long written;

	err = DIOBPCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPReset()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPReset()", err);
		return err;
	}

	err = AOStop(&boardContextVec[uiBoardNumber].diobpContext.aoContext, ME4000_DIOBP_STOP_MODE_IMMEDIATE);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPReset()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPReset()", err);
		return err;
	}

	err = AOContinuous(
			&boardContextVec[uiBoardNumber].diobpContext.aoContext,
			&value, 
			1, 
			NULL,
			NULL,
			0, 
			&written);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPReset()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPReset()", err);
		return err;
	}

	err = AOStart(&boardContextVec[uiBoardNumber].diobpContext.aoContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPReset()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPReset()", err);
		return err;
	}

	err = AOReset(&boardContextVec[uiBoardNumber].diobpContext.aoContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPReset()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPReset()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000DIOBPStart(unsigned int uiBoardNumber){
	int err;

	err = DIOBPCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPStart()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPStart()", err);
		return err;
	}

	err = AOStart(&boardContextVec[uiBoardNumber].diobpContext.aoContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPStart()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPStart()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000DIOBPStop(unsigned int uiBoardNumber, int iStopMode){
	int err;

	err = DIOBPCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPStop()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPStop()", err);
		return err;
	}

	err = AOStop(&boardContextVec[uiBoardNumber].diobpContext.aoContext, iStopMode);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPStop()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPStop()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000DIOBPWraparound(
		unsigned int uiBoardNumber, 
		unsigned short *pusBuffer, 
		unsigned long ulDataCount, 
		unsigned long ulLoops,
		int iExecutionMode,
		ME4000_P_DIOBP_TERMINATE_PROC pTerminateProc,
		void *pTerminateContext,
		unsigned long ulTimeOutSeconds){
	int err;

	err = DIOBPCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPWraparound()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPWraparound()", err);
		return err;
	}

	if(iExecutionMode != ME4000_DIOBP_WRAPAROUND_ASYNCHRONOUS){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_EXEC_MODE;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPWraparound()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPWraparound()", my_errno);
		return ERROR_NO_INVALID_EXEC_MODE;
	}

	if(ulLoops != ME4000_DIOBP_WRAPAROUND_INFINITE){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_LOOPS;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPWraparound()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPWraparound()", my_errno);
		return ERROR_NO_INVALID_LOOPS;
	}

	err = AOWraparound(
			&boardContextVec[uiBoardNumber].diobpContext.aoContext,
			pusBuffer, 
			ulDataCount, 
			ulTimeOutSeconds);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000DIOBPWraparound()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000DIOBPWraparound()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



/*===========================================================================
  Mux Functions
  =========================================================================*/

int MultiSigAICheckBoard(unsigned int uiBoardNumber){
	if(uiBoardNumber >= board_count){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BOARD;
		return ERROR_NO_INVALID_BOARD;
	}
	return ME4000_NO_ERROR;
}



int MultiSigAICheckBoardFD(unsigned int uiBoardNumber){
	int err;

	err = MultiSigAICheckBoard(uiBoardNumber);
	if(err) return err;

	if(boardContextVec[uiBoardNumber].multiSigAIContext.dioContext.fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}

	if(boardContextVec[uiBoardNumber].multiSigAIContext.aiContext.fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}

	if(boardContextVec[uiBoardNumber].multiSigAIContext.aoContext.fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAIOpen(unsigned int uiBoardNumber, int iAcqMode){
	int err;

	err = MultiSigAICheckBoard(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIOpen()", err);
		return err;
	}

	if(boardContextVec[uiBoardNumber].multiSigAIContext.dioContext.fd != -1){
		return ME4000_NO_ERROR; // Already open
	}

	switch(iAcqMode){
		case ME4000_AI_ACQ_MODE_SINGLE:
			iAcqMode = ME4000_AI_ACQ_MODE_SOFTWARE;
			break;
		case ME4000_AI_ACQ_MODE_SOFTWARE:
		case ME4000_AI_ACQ_MODE_EXT:
		case ME4000_AI_ACQ_MODE_EXT_SINGLE_VALUE:
		case ME4000_AI_ACQ_MODE_EXT_SINGLE_CHANLIST:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_ACQ_MODE;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigAIOpen()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigAIOpen()", my_errno);
			return ERROR_NO_INVALID_ACQ_MODE;
	}

	err = DIOOpen(&boardContextVec[uiBoardNumber].multiSigAIContext.dioContext, uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIOpen()", err);
		return err;
	}

	err = AIOpen(
			&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext,
			uiBoardNumber,
			iAcqMode);
	if(err){
		DIOClose(&boardContextVec[uiBoardNumber].multiSigAIContext.dioContext);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIOpen()", err);
		return err;
	}

	err = AOOpen(
			&boardContextVec[uiBoardNumber].multiSigAIContext.aoContext,
			uiBoardNumber,
			3,
			ME4000_AO_CONV_MODE_WRAPAROUND);
	if(err){
		DIOClose(&boardContextVec[uiBoardNumber].multiSigAIContext.dioContext);
		AIClose(&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIOpen()", err);
		return err;
	}

	err = DIOConfig(
			&boardContextVec[uiBoardNumber].multiSigAIContext.dioContext,
			ME4000_DIO_PORT_A,
			ME4000_DIO_FIFO_LOW,
			ME4000_DIO_FUNCTION_MUX);
	if(err){
		DIOClose(&boardContextVec[uiBoardNumber].multiSigAIContext.dioContext);
		AIClose(&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext);
		AOClose(&boardContextVec[uiBoardNumber].multiSigAIContext.aoContext);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIOpen()", err);
		return err;
	}

	/*
	   if(opto_isolated(uiBoardNumber)){
	   err = DIOConfig(
	   &boardContextVec[uiBoardNumber].multiSigAIContext.dioContext,
	   ME4000_DIO_PORT_C,
	   ME4000_DIO_FIFO_HIGH,
	   ME4000_DIO_FUNCTION_MUX);
	   if(err){
	   DIOClose(&boardContextVec[uiBoardNumber].multiSigAIContext.dioContext);
	   AIClose(&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext);
	   AOClose(&boardContextVec[uiBoardNumber].multiSigAIContext.aoContext);
	   if(errorDefaultProcFlag)
	   errorDefaultProc("me4000MultiSigAIOpen()", err);
	   else if(errorUserProcPtr)
	   errorUserProcPtr("me4000MultiSigAIOpen()", err);
	   return err;
	   }
	   }
	   else{
	   err = DIOConfig(
	   &boardContextVec[uiBoardNumber].multiSigAIContext.dioContext,
	   ME4000_DIO_PORT_B,
	   ME4000_DIO_FIFO_HIGH,
	   ME4000_DIO_FUNCTION_MUX);
	   if(err){
	   DIOClose(&boardContextVec[uiBoardNumber].multiSigAIContext.dioContext);
	   AIClose(&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext);
	   AOClose(&boardContextVec[uiBoardNumber].multiSigAIContext.aoContext);
	   if(errorDefaultProcFlag)
	   errorDefaultProc("me4000MultiSigAIOpen()", err);
	   else if(errorUserProcPtr)
	   errorUserProcPtr("me4000MultiSigAIOpen()", err);
	   return err;
	   }
	   }
	 */

	err = ioctl(boardContextVec[uiBoardNumber].multiSigAIContext.aoContext.fd, ME4000_AO_ENABLE_DO);
	if(err){
		DIOClose(&boardContextVec[uiBoardNumber].multiSigAIContext.dioContext);
		AIClose(&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext);
		AOClose(&boardContextVec[uiBoardNumber].multiSigAIContext.aoContext);
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIOpen()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAIClose(unsigned int uiBoardNumber){
	int err;

	err = MultiSigAICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIClose()", err);
		return err;
	}

	err = DIOClose(&boardContextVec[uiBoardNumber].multiSigAIContext.dioContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIClose()", err);
		return err;
	}
	err = AIClose(&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIClose()", err);
		return err;
	}
	err = AOClose(&boardContextVec[uiBoardNumber].multiSigAIContext.aoContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIClose()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAIConfig(
		unsigned int uiBoardNumber,
		unsigned int uiAIChannelNumber,
		unsigned char *pucMuxChanList, 
		unsigned int uiMuxChanListCount, 
		unsigned long ulReserved, 
		unsigned long ulChanTicks, 
		unsigned long ulScanTicksLow, 
		unsigned long ulScanTicksHigh, 
		int iAcqMode,
		int iExtTriggerMode, 
		int iExtTriggerEdge){
	unsigned char entry;
	int err;
	int i;
	unsigned short pusMuxChanList[uiMuxChanListCount];

	for(i = 0; i < uiMuxChanListCount; i++){
		pusMuxChanList[i] = pucMuxChanList[i];
	}

	err = MultiSigAICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIConfig()", err);
		return err;
	}

	entry = 
		ME4000_AI_LIST_INPUT_SINGLE_ENDED |
		ME4000_AI_LIST_RANGE_BIPOLAR_10 | 
		uiAIChannelNumber;

	err = AIConfig(
			&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext,
			&entry, 
			1, 
			ME4000_AI_INPUT_SINGLE_ENDED, 
			ME4000_AI_SIMULTANEOUS_DISABLE,
			0,
			ulChanTicks, 
			ulScanTicksLow, 
			ulScanTicksHigh,
			iExtTriggerMode, 
			iExtTriggerEdge);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIConfig()", err);
		return err;
	}

	for(i = 0; i < uiMuxChanListCount; i++){
		pucMuxChanList[i] |= 0xF00;
	}

	err = AOWraparound(
			&boardContextVec[uiBoardNumber].multiSigAIContext.aoContext,
			pusMuxChanList,
			uiMuxChanListCount,
			0);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIConfig()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAIContinuous(
		unsigned int uiBoardNumber,
		ME4000_P_AI_CALLBACK_PROC pCallbackProc, 
		void *pCallbackContext, 
		unsigned int uiRefreshFrequency, 
		unsigned long ulTimeOutSeconds){
	int err;

	err = MultiSigAICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIContinuous()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIContinuous()", err);
		return err;
	}

	err = AIContinuous(
			&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext,
			pCallbackProc, 
			pCallbackContext, 
			uiRefreshFrequency, 
			ulTimeOutSeconds);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIContinuous()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIContinuous()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}


static int calc_te_temp(
		short sDigit,
		int iGain,
		double dTeGain,
		double *pdTable,
		unsigned long ulTableSize,
		double dMinTemp,
		double dTempOffset,
		double *pdSize){
	int i;
	int err;
	double voltage;
	double tevoltage;

	err = me4000AIDigitToVolt(
			sDigit, 
			iGain, 
			&voltage);
	if(err) return err;

	tevoltage = voltage / dTeGain * 1E6; // The table holds the voltage in uV

	syslog(LOG_DEBUG, "Digits = %i, Gain = %i, tevoltage = %f, Min = %f, Off = %f\n", sDigit, iGain, tevoltage, dMinTemp, dTempOffset);

	if((tevoltage < pdTable[0]) || (tevoltage > pdTable[ulTableSize - 1])){
		errno = EINVAL;
		my_errno = ERROR_NO_TEMP_RANGE;
		return my_errno;
	}

	for(i = 0; i < ulTableSize; i++){
		if(tevoltage == pdTable[i]){
			*pdSize = dMinTemp + i + dTempOffset;
			break;
		}
		else if(tevoltage > pdTable[i]){
			continue;
		}
		else{
			*pdSize = (dMinTemp + i) + (tevoltage - pdTable[i]) / (pdTable[i + 1] - pdTable[i]);
			*pdSize += dTempOffset;
			break;
		}
	}

	syslog(LOG_DEBUG, "Temperature %f K\n", *pdSize);

	return ME4000_NO_ERROR;
}


int me4000MultiSigAIDigitToSize(
		short sDigit, 
		int iGain, 
		int iModuleType, 
		double dRefValue,
		double *pdSize){
	int err;
	double divisor;
	double voltage;
	double resistance;

	switch(iGain){
		case ME4000_MULTISIG_GAIN_1:
			divisor = 1;
			break;
		case ME4000_MULTISIG_GAIN_10:
			divisor = 10;
			break;
		case ME4000_MULTISIG_GAIN_100:
			divisor = 100;
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_MULTI_SIG_GAIN;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
			return ERROR_NO_INVALID_MULTI_SIG_GAIN;
	}

	switch(iModuleType){
		case ME4000_MULTISIG_MODULE_NONE:
		case ME4000_MULTISIG_MODULE_DIFF16_10V:
			err = me4000AIDigitToVolt(
					sDigit, 
					ME4000_AI_RANGE_BIPOLAR_10, 
					&voltage);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}

			*pdSize = voltage / divisor;
			break;
		case ME4000_MULTISIG_MODULE_DIFF16_20V:
			divisor /= 2;
			err = me4000AIDigitToVolt(
					sDigit, 
					ME4000_AI_RANGE_BIPOLAR_10, 
					&voltage);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}

			*pdSize = voltage / divisor;
			break;
		case ME4000_MULTISIG_MODULE_DIFF16_50V:
			divisor *= 5;
			err = me4000AIDigitToVolt(
					sDigit, 
					ME4000_AI_RANGE_BIPOLAR_10, 
					&voltage);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}

			*pdSize = voltage / divisor;
			break;
		case ME4000_MULTISIG_MODULE_CURRENT16_0_20MA:
			*pdSize = 40.0 / 65536.0 * sDigit / divisor;
			break;
		case ME4000_MULTISIG_MODULE_RTD8_PT100:
			err = me4000AIDigitToVolt(
					sDigit, 
					ME4000_AI_RANGE_BIPOLAR_10, 
					&voltage);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}
			resistance = voltage / divisor / dRefValue / 40;

			*pdSize = me4000MultiSigCalcTemp(resistance, dRefValue);
			break;
		case ME4000_MULTISIG_MODULE_RTD8_PT500:
			err = me4000AIDigitToVolt(
					sDigit, 
					ME4000_AI_RANGE_BIPOLAR_10, 
					&voltage);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}
			resistance = voltage / divisor / dRefValue / 5 / 8;

			*pdSize = me4000MultiSigCalcTemp(resistance, dRefValue);
			break;
		case ME4000_MULTISIG_MODULE_RTD8_PT1000:
			err = me4000AIDigitToVolt(
					sDigit, 
					ME4000_AI_RANGE_BIPOLAR_10, 
					&voltage);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}
			resistance = voltage / divisor / dRefValue / 10 / 4;

			*pdSize = me4000MultiSigCalcTemp(resistance, dRefValue);
			break;
		case ME4000_MULTISIG_MODULE_TE8_TYPE_B:
			err = calc_te_temp(
					sDigit,
					iGain,
					ME4000_TE_TYPE_B_GAIN,
					te_type_b,
					sizeof(te_type_b) / sizeof(double),
					ME4000_TE_TYPE_B_MIN_TEMP,
					dRefValue,
					pdSize);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}

			break;
		case ME4000_MULTISIG_MODULE_TE8_TYPE_E:
			err = calc_te_temp(
					sDigit,
					iGain,
					ME4000_TE_TYPE_E_GAIN,
					te_type_e,
					sizeof(te_type_e) / sizeof(double),
					ME4000_TE_TYPE_E_MIN_TEMP,
					dRefValue,
					pdSize);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}

			break;
		case ME4000_MULTISIG_MODULE_TE8_TYPE_J:
			err = calc_te_temp(
					sDigit,
					iGain,
					ME4000_TE_TYPE_J_GAIN,
					te_type_j,
					sizeof(te_type_j) / sizeof(double),
					ME4000_TE_TYPE_J_MIN_TEMP,
					dRefValue,
					pdSize);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}

			break;
		case ME4000_MULTISIG_MODULE_TE8_TYPE_K:
			err = calc_te_temp(
					sDigit,
					iGain,
					ME4000_TE_TYPE_K_GAIN,
					te_type_k,
					sizeof(te_type_k) / sizeof(double),
					ME4000_TE_TYPE_K_MIN_TEMP,
					dRefValue,
					pdSize);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}

			break;
		case ME4000_MULTISIG_MODULE_TE8_TYPE_N:
			err = calc_te_temp(
					sDigit,
					iGain,
					ME4000_TE_TYPE_N_GAIN,
					te_type_n,
					sizeof(te_type_n) / sizeof(double),
					ME4000_TE_TYPE_N_MIN_TEMP,
					dRefValue,
					pdSize);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}

			break;
		case ME4000_MULTISIG_MODULE_TE8_TYPE_R:
			err = calc_te_temp(
					sDigit,
					iGain,
					ME4000_TE_TYPE_R_GAIN,
					te_type_r,
					sizeof(te_type_r) / sizeof(double),
					ME4000_TE_TYPE_R_MIN_TEMP,
					dRefValue,
					pdSize);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}

			break;
		case ME4000_MULTISIG_MODULE_TE8_TYPE_S:
			err = calc_te_temp(
					sDigit,
					iGain,
					ME4000_TE_TYPE_S_GAIN,
					te_type_s,
					sizeof(te_type_s) / sizeof(double),
					ME4000_TE_TYPE_S_MIN_TEMP,
					dRefValue,
					pdSize);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}

			break;
		case ME4000_MULTISIG_MODULE_TE8_TYPE_T:
			err = calc_te_temp(
					sDigit,
					iGain,
					ME4000_TE_TYPE_T_GAIN,
					te_type_t,
					sizeof(te_type_t) / sizeof(double),
					ME4000_TE_TYPE_T_MIN_TEMP,
					dRefValue,
					pdSize);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}

			break;
		case ME4000_MULTISIG_MODULE_TE8_TEMP_SENSOR:
			err = me4000AIDigitToVolt(
					sDigit, 
					ME4000_AI_RANGE_BIPOLAR_10, 
					&voltage);
			if(err){
				if(errorDefaultProcFlag)
					errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
				else if(errorUserProcPtr)
					errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
				return err;
			}

			*pdSize = (voltage / 4 - 500E-3) / 10E-3;
			break;
		default:
			my_errno = ERROR_NO_INVALID_MULTI_SIG_MODULE_TYPE;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigAIDigitToSize()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigAIDigitToSize()", my_errno);
			return ERROR_NO_INVALID_MULTI_SIG_MODULE_TYPE;
	}

	return ME4000_NO_ERROR;
}



static double me4000MultiSigCalcTemp(double resistance, int iIMeasured){
	int i;
	double grad;

	if(resistance < pt_100[i]){
		grad = ME4000_PT_100_TEMP_OFFSET;
		return grad;
	}

	for(i = 0; i < ME4000_PT_100_TABLE_COUNT; i++){
		if(resistance > pt_100[i]){
			continue;
		}
		else if(resistance == pt_100[i]){
			grad = i + ME4000_PT_100_TEMP_OFFSET;
			break;
		}
		else if(resistance < pt_100[i]){
			grad = (i - 1) + (1 / (pt_100[i] - pt_100[i - 1])) * (resistance - pt_100[i - 1]) + ME4000_PT_100_TEMP_OFFSET;
			break;
		}
	}

	if(i == ME4000_PT_100_TABLE_COUNT){
		grad = ME4000_PT_100_TABLE_COUNT - 1 + ME4000_PT_100_TEMP_OFFSET;
	}

	return grad;
}



int me4000MultiSigAIGetNewValues(
		unsigned int uiBoardNumber, 
		short *psBuffer, 
		unsigned long ulNumberOfValuesToRead,
		int iExecutionMode,
		unsigned long *pulNumberOfValuesRead,
		int *piLastError){
	int err;

	err = MultiSigAICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIGetNewValues()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIGetNewValues()", err);
		return err;
	}

	err = AIGetNewValues(
			&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext,
			psBuffer, 
			ulNumberOfValuesToRead, 
			iExecutionMode,
			pulNumberOfValuesRead,
			piLastError);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIGetNewValues()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIGetNewValues()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAIGetStatus(
		unsigned int uiBoardNumber,
		int iWaitIdle,
		int *piStatus){
	int err;

	err = MultiSigAICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIGetStatus()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIGetStatus()", err);
		return err;
	}

	err = AIGetStatus(
			&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext,
			iWaitIdle,
			piStatus);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIGetStatus()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIGetStatus()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAIScan(
		unsigned int uiBoardNumber,
		unsigned int uiNumberOfMuxLists,
		short *psBuffer, 
		unsigned long ulBufferSizeValues,
		int iExecutionMode, 
		ME4000_P_AI_CALLBACK_PROC pCallbackProc, 
		void *pCallbackContext, 
		unsigned int uiRefreshFrequency,
		ME4000_P_AI_CALLBACK_PROC pTerminateProc, 
		void *pTerminateContext, 
		unsigned long ulTimeOutSeconds){
	int err;

	err = MultiSigAICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIScan()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIScan()", err);
		return err;
	}

	err = AIScan(
			&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext,
			0,
			psBuffer, 
			ulBufferSizeValues,
			iExecutionMode, 
			pCallbackProc, 
			pCallbackContext, 
			uiRefreshFrequency,
			pTerminateProc, 
			pTerminateContext, 
			ulTimeOutSeconds);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIScan()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIScan()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAISingle(
		unsigned int uiBoardNumber,
		unsigned int uiAIChannelNumber,
		unsigned int uiMuxChannelNumber,
		int iGain,
		int iTriggerMode,
		int iExtTriggerEdge,
		unsigned long ulTimeOutSeconds,
		short *psDigitalValue){
	int err;
	unsigned char channel;

	if(uiMuxChannelNumber > 255){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_MUX_CHANNEL;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAISingle()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAISingle()", my_errno);
		return ERROR_NO_INVALID_MUX_CHANNEL;
	}

	channel = uiMuxChannelNumber;

	err = me4000MultiSigAIConfig(
			uiBoardNumber,
			uiAIChannelNumber,
			&channel,
			1, 
			0, 
			66, 
			132, 
			0, 
			ME4000_AI_ACQ_MODE_SOFTWARE,
			iTriggerMode, 
			iExtTriggerEdge);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAISingle()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAISingle()", my_errno);
		return err;
	}

	err = me4000MultiSigAIScan(
			uiBoardNumber,
			ME4000_VALUE_NOT_USED,
			psDigitalValue, 
			1,
			ME4000_AI_SCAN_BLOCKING, 
			NULL, 
			NULL, 
			0,
			NULL, 
			NULL, 
			0);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAISingle()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAISingle()", my_errno);
		return err;
	}

	err = me4000MultiSigAIStart(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAISingle()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAISingle()", my_errno);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAIReset(unsigned int uiBoardNumber){
	int err;

	err = MultiSigAICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIReset()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIReset()", err);
		return err;
	}

	err = AIStop(&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIReset()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIReset()", err);
		return err;
	}

	return ME4000_NO_ERROR;

}



int me4000MultiSigAIStart(unsigned int uiBoardNumber){
	int err;

	err = MultiSigAICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIStart()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIStart()", err);
		return err;
	}

	err = AIStart(&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIStart()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIStart()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAIStop(unsigned int uiBoardNumber, int iReserved){
	int err;

	err = MultiSigAICheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIStop()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIStop()", err);
		return err;
	}

	err = AIStop(&boardContextVec[uiBoardNumber].multiSigAIContext.aiContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIStop()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIStop()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAIExtractValues(
		unsigned int uiMuxChannelNumber, 
		short *psAIBuffer, 
		unsigned long ulAIDataCount, 
		unsigned char *pucMuxChanList, 
		unsigned int uiMuxChanListCount, 
		short *psChanBuffer, 
		unsigned long ulChanBufferSizeValues, 
		unsigned long *pulChanDataCount){
	int chan_found = 0;
	unsigned char *chanList = pucMuxChanList;
	unsigned long index_chan = 0;
	unsigned long index_AI_buffer = 0;
	int i;

	*pulChanDataCount = 0;

	/* Check the channel number, is it contained in the channel list */
	for(i = 0; i < uiMuxChanListCount; i++){
		if((*chanList & 0xFF) == uiMuxChannelNumber){
			chan_found = 1;
			break;
		}
		++chanList;
	}
	if(!chan_found){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_CHANNEL;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAIExtractValues()", my_errno);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAIExtractValues()", my_errno);
		return ERROR_NO_INVALID_CHANNEL;
	}

	for(index_chan = 0, index_AI_buffer = 0; index_AI_buffer < ulAIDataCount; index_AI_buffer++){
		if((unsigned long)(pucMuxChanList[index_chan] & 0xFF) == uiMuxChannelNumber){
			/* This value belongs to the channel we are extracting
			   so write it to the buffer */
			psAIBuffer[*pulChanDataCount] = psAIBuffer[index_AI_buffer];

			if(++(*pulChanDataCount) >= ulChanBufferSizeValues){
				break;
			}
		}

		if(++index_chan >= uiMuxChanListCount){
			index_chan = 0;
		}
	}

	return ME4000_NO_ERROR;
}



/*===========================================================================
  Demux functions
  =========================================================================*/

int MultiSigAOCheckBoard(unsigned int uiBoardNumber){
	if(uiBoardNumber >= board_count){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_BOARD;
		return ERROR_NO_INVALID_BOARD;
	}
	return ME4000_NO_ERROR;
}



int MultiSigAOCheckBoardFD(unsigned int uiBoardNumber){
	int err;

	err = MultiSigAOCheckBoard(uiBoardNumber);
	if(err) return err;

	if(boardContextVec[uiBoardNumber].multiSigAOContext.dioContext.fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}

	if(boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_0.fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}

	if(boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_3.fd < 0){
		errno = EINVAL;
		my_errno = ERROR_NO_NOT_OPEN;
		return ERROR_NO_NOT_OPEN;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAOOpen(unsigned int uiBoardNumber, int iConversionMode){
	int err;

	err = MultiSigAOCheckBoard(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOOpen()", err);
		return err;
	}

	if(boardContextVec[uiBoardNumber].multiSigAOContext.dioContext.fd != -1){
		return ME4000_NO_ERROR; // Already open
	}

	switch(iConversionMode){
		case ME4000_AO_CONV_MODE_SINGLE:
			iConversionMode = ME4000_AO_CONV_MODE_CONTINUOUS;
			break;
		case ME4000_AO_CONV_MODE_WRAPAROUND:
		case ME4000_AO_CONV_MODE_CONTINUOUS:
			break;
		default:
			errno = EINVAL;
			my_errno = ERROR_NO_INVALID_CONV_MODE;
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigAOOpen()", my_errno);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigAOOpen()", my_errno);
			return ERROR_NO_INVALID_CONV_MODE;
	}

	err = DIOOpen(&boardContextVec[uiBoardNumber].multiSigAOContext.dioContext, uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOOpen()", err);
		return err;
	}

	err =  DIOConfig(
			&boardContextVec[uiBoardNumber].multiSigAOContext.dioContext,
			ME4000_DIO_PORT_A,
			ME4000_DIO_FIFO_LOW,
			ME4000_DIO_FUNCTION_DEMUX);
	if(err){
		DIOClose(&boardContextVec[uiBoardNumber].multiSigAOContext.dioContext);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOOpen()", err);
		return err;
	}

	if(opto_isolated(uiBoardNumber)){
		err =  DIOConfig(
				&boardContextVec[uiBoardNumber].multiSigAOContext.dioContext,
				ME4000_DIO_PORT_C,
				ME4000_DIO_FIFO_HIGH,
				ME4000_DIO_FUNCTION_DEMUX);
		if(err){
			DIOClose(&boardContextVec[uiBoardNumber].multiSigAOContext.dioContext);
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigAOOpen()", err);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigAOOpen()", err);
			return err;
		}
	}
	else{
		err =  DIOConfig(
				&boardContextVec[uiBoardNumber].multiSigAOContext.dioContext, 
				ME4000_DIO_PORT_B, 
				ME4000_DIO_FIFO_HIGH, 
				ME4000_DIO_FUNCTION_DEMUX);
		if(err){
			DIOClose(&boardContextVec[uiBoardNumber].multiSigAOContext.dioContext);
			if(errorDefaultProcFlag)
				errorDefaultProc("me4000MultiSigAOOpen()", err);
			else if(errorUserProcPtr)
				errorUserProcPtr("me4000MultiSigAOOpen()", err);
			return err;
		}
	}

	err =  AOOpen(&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_0, uiBoardNumber, 0, iConversionMode);
	if(err){
		DIOClose(&boardContextVec[uiBoardNumber].multiSigAOContext.dioContext);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOOpen()", err);
		return err;
	}

	err =  AOOpen(&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_3, uiBoardNumber, 3, ME4000_AO_CONV_MODE_WRAPAROUND);
	if(err){
		DIOClose(&boardContextVec[uiBoardNumber].multiSigAOContext.dioContext);
		AOClose(&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_0);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOOpen()", err);
		return err;
	}

	err = ioctl(boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_3.fd, ME4000_AO_ENABLE_DO);
	if(err){
		AOClose(&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_3);
		AOClose(&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_0);
		DIOClose(&boardContextVec[uiBoardNumber].multiSigAOContext.dioContext);
		err = storeSystemError(errno);
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOOpen()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOOpen()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAOClose(unsigned int uiBoardNumber){
	int err;

	err = MultiSigAOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOClose()", err);
		return err;
	}

	err = DIOClose(&boardContextVec[uiBoardNumber].multiSigAOContext.dioContext);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOClose()", err);
		return err;
	}

	err = AOClose(&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_3);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOClose()", err);
		return err;
	}

	err = AOClose(&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_0);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOClose()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOClose()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAOAppendNewValues(
		unsigned int uiBoardNumber,
		unsigned short *pusBuffer, 
		unsigned long ulNumberOfValuesToAppend, 
		int iExecutionMode,
		unsigned long *pulNumberOfValuesAppended){
	int err;

	err = MultiSigAOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOAppendNewValues()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOAppendNewValues()", err);
		return err;
	}

	err = AOAppendNewValues(
			&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_0,
			pusBuffer, 
			ulNumberOfValuesToAppend, 
			iExecutionMode, 
			pulNumberOfValuesAppended);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOAppendNewValues()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOAppendNewValues()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAOConfig(
		unsigned int uiBoardNumber, 
		unsigned char *pucDemuxChanList, 
		unsigned int uiDemuxChanListCount,
		unsigned long ulTicks, 
		int iTriggerMode,
		int iExtTriggerEdge){
	int err;
	int i;
	unsigned short pusDemuxChanList[uiDemuxChanListCount];

	err = MultiSigAOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOConfig()", err);
		return err;
	}

	for(i = 0; i < uiDemuxChanListCount; i++){
		pusDemuxChanList[i] = pucDemuxChanList[i];
	}

	err = AOWraparound(
			&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_3,
			pusDemuxChanList,
			uiDemuxChanListCount,
			0);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOConfig()", err);
		return err;
	}

	err = AOConfig(
			&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_0, 
			ulTicks, 
			iTriggerMode, 
			iExtTriggerEdge);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOConfig()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOConfig()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAOContinuous(
		unsigned int uiBoardNumber,
		unsigned short *pusBuffer, 
		unsigned long ulDataCount, 
		ME4000_P_AO_CALLBACK_PROC pCallbackProc,
		void *pCallbackContext,
		unsigned long ulTimeOutSeconds,
		unsigned long *pulNumberOfValuesWritten){
	int err;

	err = MultiSigAOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOContinuous()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOContinuous()", err);
		return err;
	}

	err = AOContinuous(
			&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_0, 
			pusBuffer, 
			ulDataCount, 
			pCallbackProc,
			pCallbackContext,
			ulTimeOutSeconds, 
			pulNumberOfValuesWritten);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOContinuous()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOContinuous()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAOGetStatus(unsigned int uiBoardNumber, int iWaitIdle, int *piStatus){
	int err;

	err = MultiSigAOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOGetStatus()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOGetStatus()", err);
		return err;
	}

	err = AOGetStatus(
			&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_0, 
			iWaitIdle, 
			piStatus);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOGetStatus()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOGetStatus()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAOReset(unsigned int uiBoardNumber){
	int err;

	err = MultiSigAOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOReset()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOReset()", err);
		return err;
	}

	err = AOReset(&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_0);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOReset()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOReset()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAOSingle(
		unsigned int uiBoardNumber,
		unsigned int uiDemuxChannelNumber,
		int iTriggerMode,
		int iExtTriggerEdge,
		unsigned long ulTimeOutSeconds,
		unsigned short usValue){
	int err;
	unsigned char demuxChannel = uiDemuxChannelNumber;
	unsigned long ulBufferWritten;

	err = MultiSigAOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOSingle()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOSingle()", err);
		return err;
	}

	err = me4000MultiSigAOConfig(
			uiBoardNumber,
			&demuxChannel, 
			1,
			66, 
			iTriggerMode,
			iExtTriggerEdge);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOSingle()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOSingle()", err);
		return err;
	}

	err = me4000MultiSigAOContinuous(
			uiBoardNumber,
			&usValue, 
			1, 
			NULL,
			NULL,
			ulTimeOutSeconds,
			&ulBufferWritten);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOSingle()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOSingle()", err);
		return err;
	}

	err = me4000MultiSigAOStart(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOSingle()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOSingle()", err);
		return err;
	}

	err = me4000MultiSigAOStop(uiBoardNumber, ME4000_AO_STOP_MODE_IMMEDIATE);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOSingle()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOSingle()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAOStart(unsigned int uiBoardNumber){
	int err;

	err = MultiSigAOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOStart()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOStart()", err);
		return err;
	}

	err = AOStart(&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_0);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOStart()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOStart()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAOStop(unsigned int uiBoardNumber, int iStopMode){
	int err;

	err = MultiSigAOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOStop()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOStop()", err);
		return err;
	}

	err = AOStop(&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_0, iStopMode);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOStop()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOStop()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAOVoltToDigit(double dVolt, unsigned short *pusDigit){
	int err;

	err = me4000AOVoltToDigit(dVolt, pusDigit);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOVoltToDigit()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOVoltToDigit()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}



int me4000MultiSigAOWraparound(
		unsigned int uiBoardNumber,
		unsigned short *pusBuffer, 
		unsigned long ulDataCount, 
		unsigned long ulLoops,
		int iExecutionMode,
		ME4000_P_AO_TERMINATE_PROC pTerminateProc,
		void *pTerminateContext,
		unsigned long ulTimeOutSeconds){
	int err;

	err = MultiSigAOCheckBoardFD(uiBoardNumber);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOWraparound()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOWraparound()", err);
		return err;
	}

	if(iExecutionMode != ME4000_AO_WRAPAROUND_ASYNCHRONOUS){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_EXEC_MODE;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOWraparound()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOWraparound()", err);
		return ERROR_NO_INVALID_EXEC_MODE;
	}

	if(ulLoops != ME4000_AO_WRAPAROUND_INFINITE){
		errno = EINVAL;
		my_errno = ERROR_NO_INVALID_LOOPS;
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOWraparound()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOWraparound()", err);
		return ERROR_NO_INVALID_LOOPS;
	}
	err = AOWraparound(
			&boardContextVec[uiBoardNumber].multiSigAOContext.aoContext_0,
			pusBuffer,
			ulDataCount,
			ulTimeOutSeconds);
	if(err){
		if(errorDefaultProcFlag)
			errorDefaultProc("me4000MultiSigAOWraparound()", err);
		else if(errorUserProcPtr)
			errorUserProcPtr("me4000MultiSigAOWraparound()", err);
		return err;
	}

	return ME4000_NO_ERROR;
}
