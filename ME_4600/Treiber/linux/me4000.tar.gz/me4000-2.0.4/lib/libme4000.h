#ifndef LIBME4000_H
#define LIBME4000_H

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include <errno.h>
#include <string.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <math.h>
#include <linux/param.h>
#include <pthread.h>
#include <time.h>


#include <me4000.h>


/*=============================================================================
  General definitions
  ===========================================================================*/

/* Timer capabilities */
#define ME4000_BASE_FREQUENCY   ((double)33000000.0)    // 33 MHz
#define ME4000_TIMER_FREQ       ((double)33000000.0)    // 33 MHz
#define ME4000_MIN_TIMER_TICK   ((double)66.0)          // 66 * 30,3 ns = 2 us


/* Board numbers */
#define ME4000_BOARD_0	0
#define ME4000_BOARD_1	1
#define ME4000_BOARD_2	2
#define ME4000_BOARD_3	3


#define ME4000_POINTER_NOT_USED	NULL

#define ME4000_VALUE_NOT_USED	0


/* Board information */
typedef struct{
    unsigned long dwBoardNumber;
    unsigned long dwVendorID;
    unsigned long dwDeviceID;
    unsigned long dwSystemSlotNumber;
    unsigned long dwPortBase;
    unsigned long dwPortCount;
    unsigned long dwIntChannel;
    unsigned long dwPortBasePLX;
    unsigned long dwPortCountPLX;
    unsigned long dwSerialNumber;
    unsigned long dwBusNumber;
    unsigned long dwHWRevision;
    unsigned long dwIrqCnt;
    unsigned long dwVersion;
} DEVICEINFOSTRUCT;



/*=============================================================================
  External interrupt definitions
  ===========================================================================*/

typedef void (*ME4000_P_EXT_IRQ_PROC)(void *pExtIrqContext);



/*=============================================================================
  Error definitions
  ===========================================================================*/

#define ME4000_NO_ERROR				0

#define ME4000_ERROR_DEFAULT_PROC_DISABLE	0
#define ME4000_ERROR_DEFAULT_PROC_ENABLE	1

typedef void (*ME4000_P_ERROR_PROC) (char *pcFunctionName, int iErrorCode);



/*=============================================================================
  Analog input definitions
  ===========================================================================*/

#define ME4000_AI_MAX_CHANNELS			32

#define ME4000_AI_WAIT_NONE                     0
#define ME4000_AI_WAIT_IDLE                     1

#define ME4000_AI_SCAN_BLOCKING			0x0
#define ME4000_AI_SCAN_ASYNCHRONOUS		0x1
#define ME4000_AI_SCAN_CONTINUOUS		0x2  // Only for internal usage

#define ME4000_AI_INPUT_SINGLE_ENDED		0x0
#define ME4000_AI_INPUT_DIFFERENTIAL		0x1

#define ME4000_AI_RANGE_BIPOLAR_10		0x0
#define ME4000_AI_RANGE_BIPOLAR_2_5		0x1
#define ME4000_AI_RANGE_UNIPOLAR_10		0x2
#define ME4000_AI_RANGE_UNIPOLAR_2_5		0x3

#define ME4000_AI_GET_NEW_VALUES_BLOCKING	0x0
#define ME4000_AI_GET_NEW_VALUES_NON_BLOCKING	0x1

#define ME4000_AI_DIGITAL_VALUE_ADJUSTED	0x0
#define ME4000_AI_DIGITAL_VALUE_RAW		0x1


typedef void (*ME4000_P_AI_CALLBACK_PROC) (
	short *psValues, 
	unsigned int uiNumberOfValues, 
	void *pCallbackContext, 
	int iLastError);

typedef void (*ME4000_P_AI_TERMINATE_PROC) (
	short *psValues, 
	unsigned int uiNumberOfValues, 
	void *pTerminateContext, 
	int iLastError);



/*=============================================================================
  Analog output definitions
  ===========================================================================*/

#define ME4000_AO_MAX_FREQUENCY      			((double)500000.0)      // 500 kHz
#define ME4000_AO_MIN_FREQUENCY      			((double)ME4000_TIMER_FREQ/0xffffffff)

#define ME4000_AO_APPEND_NEW_VALUES_BLOCKING		0x0
#define ME4000_AO_APPEND_NEW_VALUES_NON_BLOCKING	0x1

#define ME4000_AO_TRIGGER_EXT_DISABLE			0x0
#define ME4000_AO_TRIGGER_EXT_ENABLE			0x1

#define ME4000_AO_TRIGGER_SOFTWARE			0x0
#define ME4000_AO_TRIGGER_EXT_DIGITAL			0x1

#define ME4000_AO_STOP_MODE_LAST_VALUE			0x0
#define ME4000_AO_STOP_MODE_IMMEDIATE			0x1

#define ME4000_AO_SHAPE_RECTANGLE			0x0
#define ME4000_AO_SHAPE_TRIANGLE			0x1
#define ME4000_AO_SHAPE_SINUS				0x2
#define ME4000_AO_SHAPE_COSINUS				0x3
#define ME4000_AO_SHAPE_POS_RAMP			0x4
#define ME4000_AO_SHAPE_NEG_RAMP			0x5

#define ME4000_AO_MIN_DIGIT				0x0000UL
#define ME4000_AO_MAX_DIGIT				0xFFFFUL

#define ME4000_AO_WAIT_NONE				0
#define ME4000_AO_WAIT_IDLE				1

#define ME4000_AO_WRAPAROUND_ASYNCHRONOUS		0
#define ME4000_AO_WRAPAROUND_BLOCKING			1 // Not supported by Linux

#define ME4000_AO_WRAPAROUND_INFINITE			0 // The only supported option by Linux


typedef void (*ME4000_P_AO_CALLBACK_PROC) (unsigned long ulBufferAvailable, void* pCallbackContext);
typedef void (*ME4000_P_AO_TERMINATE_PROC) (void* pCallbackContext);



/*=============================================================================
  DIO Bit Pattern definitions
  ===========================================================================*/

#define ME4000_DIOBP_PORT_A				ME4000_DIO_PORT_A
#define ME4000_DIOBP_PORT_B				ME4000_DIO_PORT_B
#define ME4000_DIOBP_PORT_C				ME4000_DIO_PORT_C
#define ME4000_DIOBP_PORT_D				ME4000_DIO_PORT_D

#define ME4000_DIOBP_OUTPUT_MODE_BYTE_LOW		ME4000_DIO_FIFO_LOW
#define ME4000_DIOBP_OUTPUT_MODE_BYTE_HIGH		ME4000_DIO_FIFO_HIGH

#define ME4000_DIOBP_TRIGGER_SOFTWARE			ME4000_AO_TRIGGER_SOFTWARE
#define ME4000_DIOBP_TRIGGER_EXT_DIGITAL		ME4000_AO_TRIGGER_EXT_DIGITAL
#define ME4000_DIOBP_TRIGGER_EXT_EDGE_RISING		ME4000_AO_TRIGGER_EXT_EDGE_RISING
#define ME4000_DIOBP_TRIGGER_EXT_EDGE_FALLING		ME4000_AO_TRIGGER_EXT_EDGE_FALLING

#define ME4000_DIOBP_APPEND_NEW_VALUES_BLOCKING		ME4000_AO_APPEND_NEW_VALUES_BLOCKING
#define ME4000_DIOBP_APPEND_NEW_VALUES_NON_BLOCKING	ME4000_AO_APPEND_NEW_VALUES_NON_BLOCKING

#define ME4000_DIOBP_STATUS_IDLE			ME4000_AO_STATUS_IDLE
#define ME4000_DIOBP_STATUS_BUSY			ME4000_AO_STATUS_BUSY

#define ME4000_DIOBP_WAIT_IDLE				ME4000_AO_WAIT_IDLE
#define ME4000_DIOBP_WAIT_NONE				ME4000_AO_WAIT_NONE

#define ME4000_DIOBP_STOP_MODE_LAST_VALUE		ME4000_AO_STOP_MODE_LAST_VALUE
#define ME4000_DIOBP_STOP_MODE_IMMEDIATE		ME4000_AO_STOP_MODE_IMMEDIATE

#define ME4000_DIOBP_CONV_MODE_CONTINUOUS		ME4000_AO_CONV_MODE_CONTINUOUS
#define ME4000_DIOBP_CONV_MODE_WRAPAROUND		ME4000_AO_CONV_MODE_WRAPAROUND

#define ME4000_DIOBP_WRAPAROUND_ASYNCHRONOUS		ME4000_AO_WRAPAROUND_ASYNCHRONOUS
#define ME4000_DIOBP_WRAPAROUND_BLOCKING		ME4000_AO_WRAPAROUND_BLOCKING	// Not supported by Linux

#define ME4000_DIOBP_WRAPAROUND_INFINITE		ME4000_AO_WRAPAROUND_INFINITE	// The only supported option by Linux


typedef void (*ME4000_P_DIOBP_TERMINATE_PROC) (void* pCallbackContext);
typedef void (*ME4000_P_DIOBP_CALLBACK_PROC) (unsigned long ulBufferAvailable, void* pCallbackContext);



/*=============================================================================
  Multi Sig definitions
  ===========================================================================*/

#define ME4000_MULTISIG_LED_OFF		0x0
#define ME4000_MULTISIG_LED_ON		0x1

#define ME4000_MULTISIG_GROUP_A		0x1
#define ME4000_MULTISIG_GROUP_B		0x0

#define ME4000_MULTISIG_GAIN_1		0x0
#define ME4000_MULTISIG_GAIN_10		0x1
#define ME4000_MULTISIG_GAIN_100	0x2

#define ME4000_MULTISIG_MODULE_NONE					0x0
#define ME4000_MULTISIG_MODULE_DIFF16_10V			0x1
#define ME4000_MULTISIG_MODULE_DIFF16_20V			0x2
#define ME4000_MULTISIG_MODULE_DIFF16_50V			0x3
#define ME4000_MULTISIG_MODULE_CURRENT16_0_20MA		0x4
#define ME4000_MULTISIG_MODULE_RTD8_PT100			0x5
#define ME4000_MULTISIG_MODULE_RTD8_PT500			0x6
#define ME4000_MULTISIG_MODULE_RTD8_PT1000			0x7
#define ME4000_MULTISIG_MODULE_TE8_TYPE_B			0x8
#define ME4000_MULTISIG_MODULE_TE8_TYPE_E			0x9
#define ME4000_MULTISIG_MODULE_TE8_TYPE_J			0xA
#define ME4000_MULTISIG_MODULE_TE8_TYPE_K			0xB
#define ME4000_MULTISIG_MODULE_TE8_TYPE_N			0xC
#define ME4000_MULTISIG_MODULE_TE8_TYPE_R			0xD
#define ME4000_MULTISIG_MODULE_TE8_TYPE_S			0xE
#define ME4000_MULTISIG_MODULE_TE8_TYPE_T			0xF
#define ME4000_MULTISIG_MODULE_TE8_TEMP_SENSOR		0x10

#define ME4000_MULTISIG_I_MEASURED_DEFAULT			500E-6



#ifdef __cplusplus
extern "C" {
#endif

    /*===========================================================================
      Error Functions
      =========================================================================*/

    int me4000ErrorGetMessage(
	    int iErrorCode, 
	    char *pcBuffer, 
	    unsigned int uiBufferSize);

    int me4000ErrorGetLastMessage(char *pcBuffer, unsigned int uiBufferSize);

    int me4000ErrorSetDefaultProc(int iDefaultProcStatus);

    int me4000ErrorSetUserProc(ME4000_P_ERROR_PROC pErrorProc);


    /*===========================================================================
      General Functions
      =========================================================================*/

    int me4000FrequencyToTicks(
	    double dRequiredFreq, 
	    unsigned long *pulTicksLowPart,
	    unsigned long *pulTicksHighPart, 
	    double *pdAchievedFreq);

    int me4000TimeToTicks(
	    double dRequiredTime, 
	    unsigned long *pulTicksLowPart, 
	    unsigned long *pulTicksHighPart, 
	    double *pdAchievedTime);

    int me4000GetBoardVersion(unsigned int uiBoardNumber, unsigned short *pusVersion);
    int me4000GetDLLVersion(unsigned long *pulVersion);
    int me4000GetNetDLLVersion(unsigned long *pulVersion);
    int me4000GetDriverVersion(unsigned long *pulVersion);
    int me4000GetSerialNumber(unsigned int uiBoardNumber, unsigned long *pulSerialNumber);
    int me4000GetDevInfo(unsigned int uiBoardNumber, DEVICEINFOSTRUCT *pDevInfo);
    int me4000GetBoardCount(void);


    /*===========================================================================
      Analog Input Functions
      =========================================================================*/

    int me4000AIOpen(unsigned int uiBoardNumber, int iAcqMode);
    int me4000AIClose(unsigned int uiBoardNumber);

    int me4000AIConfig(
	    unsigned int uiBoardNumber, 
	    unsigned char *pucChanList, 
	    unsigned int uiChanListCount, 
	    int iSDMode, 
	    int iSimultaneous,
	    unsigned long ulReserved,
	    unsigned long ulChanTicks, 
	    unsigned long ulScanTicksLow, 
	    unsigned long ulScanTicksHigh, 
	    int iAcqMode,
	    int iExtTriggerMode, 
	    int iExtTriggerEdge);

    int me4000AIContinuous(
	    unsigned int uiBaordNumber,
	    ME4000_P_AI_CALLBACK_PROC pCallbackProc, 
	    void *pCallbackContext, 
	    unsigned int uiRefreshFrequency,
	    unsigned long ulTimeOutSeconds);

    int me4000AIDigitToVolt(
	    short sDigit, 
	    int iRange, 
	    double *pdVolt);

    int me4000AIDigitToVoltAdjusted(
	    unsigned int uiBoardNumber,
	    short sDigit, 
	    int iRange, 
	    int iSDMode,
	    double *pdVolt);

    int me4000AIExtractValues(
	    unsigned int uiChannelNumber, 
	    short *psAIBuffer, 
	    unsigned long ulAIDataCount, 
	    unsigned char *pucChanList, 
	    unsigned int uiChanListCount, 
	    short *psChanBuffer, 
	    unsigned long ulChanBufferSizeValues, 
	    unsigned long *pulChanDataCount);

    int me4000AIGetNewValues(
	    unsigned int uiBoardNumber, 
	    short *psBuffer, 
	    unsigned long ulNumberOfValuesToRead,
	    int iExecutionMode,
	    unsigned long *pulNumberOfValuesRead,
	    int *piLastError);

    int me4000AIGetStatus(
	    unsigned int uiBoardNumber,
	    int iWaitIdle,
	    int *piStatus);

    int me4000AIMakeChannelListEntry(
	    unsigned int uiChannelNumber, 
	    int iRange, 
	    unsigned char *pucChanListEntry);

    int me4000AIReset(unsigned int uiBoardNumber);

    int me4000AIScan(
	    unsigned int uiBaordNumber,
	    unsigned int uiNumberOfChanLists,
	    short *psBuffer, 
	    unsigned long ulBufferSizeValues,
	    int iExecutionMode, 
	    ME4000_P_AI_CALLBACK_PROC pCallbackProc, 
	    void *pCallbackContext, 
	    unsigned int uiRefreshFrequency,
	    ME4000_P_AI_TERMINATE_PROC pTerminateProc, 
	    void *pTerminateContext, 
	    unsigned long ulTimeOutSeconds);

    int me4000AISingle(
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber,
	    int iRange, 
	    int iSDMode, 
	    int iTriggerMode,
	    int iExtTriggerEdge, 
	    unsigned long ulTimeOutSeconds, 
	    short *psDigitalValue);

    int me4000AIStart(unsigned int uiBoardNumber);

    int me4000AIStop(unsigned int uiBoardNumber, int iReserved);


    /*===========================================================================
      Analog output functions
      =========================================================================*/

    int me4000AOOpen(
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber, 
	    int iConversionMode);

    int me4000AOClose(unsigned int uiBoardNumber, unsigned int uiChannelNumber);

    int me4000AOAppendNewValues(
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber, 
	    unsigned short *pusBuffer, 
	    unsigned long ulNumberOfValuesToAppend, 
	    int iExecutionMode,
	    unsigned long *pulNumberOfValuesAppended);

    int me4000AOConfig(
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber,
	    unsigned long ulTicks, 
	    int iTriggerMode,
	    int iExtTriggerEdge);

    int me4000AOContinuous(
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber,
	    unsigned short *pusBuffer, 
	    unsigned long ulDataCount, 
	    ME4000_P_AO_CALLBACK_PROC pCallbackProc,
	    void *pCallbackContext,
	    unsigned long ulTimeOutSeconds,
	    unsigned long *pulNumberOfValuesWritten);

    int me4000AOGetStatus(
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber,
	    int iWaitIdle,
	    int *piStatus);

    int me4000AOReset(unsigned int uiBoardNumber, unsigned int uiChannelNumber);

    int me4000AOSingle(
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber, 
	    int iTriggerMode,
	    int iExtTriggerEdge,
	    unsigned long ulTimeOutSeconds,
	    unsigned short usValue);

    int me4000AOSingleSimultaneous(
	    unsigned int uiBoardNumber,
	    unsigned int *puiChannelNumber,
	    unsigned long ulCount,
	    int iTriggerMode,
	    int *piExtTriggerEnable,
	    int *piExtTriggerEdge,
	    unsigned long ulTimeOutSeconds,
	    unsigned short *pusValue);

    int me4000AOStart(unsigned int uiBoardNumber, unsigned int uiChannelNumber);

    int me4000AOStartSynchronous(
	    unsigned int uiBoardNumber, 
	    unsigned int *puiChannelNumber, 
	    unsigned long ulCount, 
	    int iTriggerMode, 
	    int *piExtTriggerEnable,
	    int *piExtTriggerEdge,
	    unsigned long ulTimeOutSeconds);

    int me4000AOStop(
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber, 
	    int iStopMode);

    int me4000AOVoltToDigit(double dVolt, unsigned short *pusDigit);

    int me4000AOWaveGen(
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber, 
	    int iShape, 
	    double dAmplitude, 
	    double dOffset, 
	    double dFrequency);

    int me4000AOWraparound(
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber, 
	    unsigned short *pusBuffer, 
	    unsigned long ulDataCount, 
	    unsigned long ulLoops,
	    int iExecutionMode,
	    ME4000_P_AO_TERMINATE_PROC pTerminateProc,
	    void *pTerminateContext,
	    unsigned long ulTimeOutSeconds);


    /*===========================================================================
      Bit pattern functions
      =========================================================================*/

    int me4000DIOBPOpen(unsigned int uiBoardNumber, int iConversionMode);
    int me4000DIOBPClose(unsigned int uiBoardNumber);

    int me4000DIOBPAppendNewValues(
	    unsigned int uiBoardNumber,
	    unsigned short *pusBuffer, 
	    unsigned long ulNumberOfValuesToAppend, 
	    int iExecutionMode,
	    unsigned long *pulNumberOfValuesAppended);

    int me4000DIOBPConfig(
	    unsigned int uiBoardNumber, 
	    unsigned long ulTicks, 
	    int iTriggerMode,
	    int iExtTriggerEdge);

    int me4000DIOBPContinuous(
	    unsigned int uiBoardNumber,
	    unsigned short *pusBuffer, 
	    unsigned long ulDataCount, 
	    ME4000_P_DIOBP_CALLBACK_PROC pCallback,
	    void *pCallbackContext,
	    unsigned long ulTimeOutSeconds,
	    unsigned long *pulNumberOfValuesWritten);

    int me4000DIOBPGetStatus(
	    unsigned int uiBoardNumber, 
	    int iWaitIdle, 
	    int *piStatus);

    int me4000DIOBPPortConfig(
	    unsigned int uiBoardNumber, 
	    unsigned int uiPortNumber, 
	    int iOutputMode);

    int me4000DIOBPReset(unsigned int uiBoardNumber);

    int me4000DIOBPStart(unsigned int uiBoardNumber);

    int me4000DIOBPStop(unsigned int uiBoardNumber, int iStopMode);

    int me4000DIOBPWraparound(
	    unsigned int uiBoardNumber, 
	    unsigned short *pusBuffer, 
	    unsigned long ulDataCount, 
	    unsigned long ulLoops,
	    int iExecutionMode,
	    ME4000_P_DIOBP_TERMINATE_PROC pTerminateProc,
	    void *pTerminateContext,
	    unsigned long ulTimeOutSeconds);


    /*===========================================================================
      Digital I/O functions
      =========================================================================*/

    int me4000DIOOpen(unsigned int uiBoardNumber);
    int me4000DIOClose(unsigned int uiBoardNumber);

    int me4000DIOConfig(
	    unsigned int uiBoardNumber, 
	    unsigned int uiPortNumber, 
	    int iPortDirection);

    int me4000DIOGetBit(
	    unsigned int uiBoardNumber, 
	    unsigned int uiPortNumber, 
	    unsigned int uiBitNumber, 
	    int *piBitValue);

    int me4000DIOGetByte(
	    unsigned int uiBoardNumber, 
	    unsigned int uiPortNumber, 
	    unsigned char *pucByteValue);

    int me4000DIOResetAll(unsigned int uiBoardNumber);

    int me4000DIOSetBit(
	    unsigned int uiBoardNumber, 
	    unsigned int uiPortNumber, 
	    unsigned int uiBitNumber, 
	    int iBitValue);

    int me4000DIOSetByte(
	    unsigned int uiBoardNumber, 
	    unsigned int uiPortNumber, 
	    unsigned char ucByteValue);


    /*===========================================================================
      Counter functions
      =========================================================================*/

    int me4000CntOpen(unsigned int uiBoardNumber);
    int me4000CntClose(unsigned int uiBoardNumber);

    int me4000CntPWMStart(
	    unsigned int uiBoardNumber,
	    int iPrescaler,
	    int iDutyCycle);

    int me4000CntPWMStop(unsigned int uiBoardNumber);

    int me4000CntRead(
	    unsigned int uiBoardNumber,
	    unsigned int uiCounterNumber,
	    unsigned short *pusValue);

    int me4000CntWrite(
	    unsigned int uiBoardNumber,
	    unsigned int uiCounterNumber,
	    int iMode,
	    unsigned short usValue);


    /*===========================================================================
      External interrupt functions
      =========================================================================*/

    int me4000ExtIrqOpen(unsigned int uiBoardNumber);
    int me4000ExtIrqClose(unsigned int uiBoardNumber);

    int me4000ExtIrqDisable(unsigned int uiBoardNumber);

    int me4000ExtIrqEnable(
	    unsigned int uiBoardNumber,
	    ME4000_P_EXT_IRQ_PROC pExtIrqProc,
	    void *pExtIrqContext);

    int me4000ExtIrqGetCount(unsigned int uiBoardNumber, unsigned int *puiIrqCount);


    /*===========================================================================
      MultiSig Functions
      =========================================================================*/

    int me4000MultiSigOpen(unsigned int uiBoardNumber);
    int me4000MultiSigClose(unsigned int uiBoardNumber);

    int me4000MultiSigAddressLED(
	    unsigned int uiBoardNumber, 
	    unsigned int uiBase, 
	    int iLEDStatus);

    int me4000MultiSigReset(unsigned int uiBoardNumber);

    int me4000MultiSigSetGain(
	    unsigned int uiBoardNumber, 
	    unsigned int uiBase, 
	    int iChannelGroup, 
	    int iGain);


    /*===========================================================================
      MultiSig AI Functions
      =========================================================================*/

    int me4000MultiSigAIOpen(unsigned int uiBoardNumber, int iAcqMode);
    int me4000MultiSigAIClose(unsigned int uiBoardNumber);

    int me4000MultiSigAIConfig(
	    unsigned int uiBoardNumber,
	    unsigned int uiAIChannelNumber,
	    unsigned char *pucMuxChanList, 
	    unsigned int uiMuxChanListCount, 
	    unsigned long ulReserved, 
	    unsigned long ulChanTicks, 
	    unsigned long ulScanTicksLow, 
	    unsigned long ulScanTicksHigh, 
	    int iAcqMode,
	    int iExtTriggerMode, 
	    int iExtTriggerEdge);

    int me4000MultiSigAIContinuous(
	    unsigned int uiBoardNumber,
	    ME4000_P_AI_CALLBACK_PROC pCallbackProc, 
	    void *pCallbackContext, 
	    unsigned int uiRefreshFrequency, 
	    unsigned long ulTimeOutSeconds);

    int me4000MultiSigAIDigitToSize(
	    short sDigit, 
	    int iGain, 
	    int iModuleType,
	    double dRefValue,
	    double *pdSize);

    int me4000MultiSigAIExtractValues(
	    unsigned int uiMuxChannelNumber, 
	    short *psAIBuffer, 
	    unsigned long ulAIDataCount, 
	    unsigned char *pucMuxChanList, 
	    unsigned int uiMuxChanListCount, 
	    short *psChanBuffer, 
	    unsigned long ulChanBufferSizeValues, 
	    unsigned long *pulChanDataCount);

    int me4000MultiSigAIGetNewValues(
	    unsigned int uiBoardNumber, 
	    short *psBuffer, 
	    unsigned long ulNumberOfValuesToRead,
	    int iExecutionMode,
	    unsigned long *pulNumberOfValuesRead,
	    int *piLastError);

    int me4000MultiSigAIGetStatus(
	    unsigned int uiBoardNumber,
	    int iWaitIdle,
	    int *piStatus);

    int me4000MultiSigAIReset(unsigned int uiBoardNumber);

    int me4000MultiSigAIScan(
	    unsigned int uiBoardNumber,
	    unsigned int uiNumberOfMuxLists,
	    short *psBuffer, 
	    unsigned long ulBufferSizeValues,
	    int iExecutionMode, 
	    ME4000_P_AI_CALLBACK_PROC pCallbackProc, 
	    void *pCallbackContext, 
	    unsigned int uiRefreshFrequency,
	    ME4000_P_AI_CALLBACK_PROC pTerminateProc, 
	    void *pTerminateContext, 
	    unsigned long ulTimeOutSeconds);

    int me4000MultiSigAISingle(
	    unsigned int uiBoardNumber,
	    unsigned int uiAIChannelNumber,
	    unsigned int uiMuxChannelNumber,
	    int iGain,
	    int iTriggerMode,
	    int iExtTriggerEdge,
	    unsigned long ulTimeOutSeconds,
	    short *psDigitalValue);

    int me4000MultiSigAIStart(unsigned int uiBoardNumber);

    int me4000MultiSigAIStop(unsigned int uiBoardNumber, int iReserved);



    /*===========================================================================
      MultiSig AO functions
      =========================================================================*/

    int me4000MultiSigAOOpen(unsigned int uiBoardNumber, int iConversionMode);
    int me4000MultiSigAOClose(unsigned int uiBoardNumber);

    int me4000MultiSigAOAppendNewValues(
	    unsigned int uiBoardNumber,
	    unsigned short *pusBuffer, 
	    unsigned long ulNumberOfValuesToAppend, 
	    int iExecutionMode,
	    unsigned long *pulNumberOfValuesAppended);

    int me4000MultiSigAOConfig(
	    unsigned int uiBoardNumber, 
	    unsigned char *pucDemuxChanList, 
	    unsigned int uiDemuxChanListCount,
	    unsigned long ulTicks, 
	    int iTriggerMode,
	    int iExtTriggerEdge);

    int me4000MultiSigAOContinuous(
	    unsigned int uiBoardNumber,
	    unsigned short *pusBuffer, 
	    unsigned long ulDataCount, 
	    ME4000_P_AO_CALLBACK_PROC pCallbackProc,
	    void *pCallbackContext,
	    unsigned long ulTimeOutSeconds,
	    unsigned long *pulNumberOfValuesWritten);

    int me4000MultiSigAOGetStatus(
	    unsigned int uiBoardNumber, 
	    int iWaitIdle, 
	    int *piStatus);

    int me4000MultiSigAOReset(unsigned int uiBoardNumber);

    int me4000MultiSigAOSingle(
	    unsigned int uiBoardNumber,
	    unsigned int uiDemuxChannelNumber,
	    int iTriggerMode,
	    int iExtTriggerEdge,
	    unsigned long ulTimeOutSeconds,
	    unsigned short usValue);

    int me4000MultiSigAOStart(unsigned int uiBoardNumber);

    int me4000MultiSigAOStop(unsigned int uiBoardNumber, int iStopMode);

    int me4000MultiSigAOVoltToDigit(double dVolt, unsigned short *pusDigit);

    int me4000MultiSigAOWraparound(
	    unsigned int uiBoardNumber,
	    unsigned short *pusBuffer, 
	    unsigned long ulDataCount, 
	    unsigned long ulLoops,
	    int iExecutionMode,
	    ME4000_P_AO_TERMINATE_PROC pTerminateProc,
	    void *pTerminateContext,
	    unsigned long ulTimeOutSeconds);


#ifdef __cplusplus
}
#endif

#endif
