#ifndef LIBME4000_ERROR_H
#define LIBME4000_ERROR_H

#define ERROR_NO_MIN				0
#define ERROR_NO_MAX				(ERROR_NO_MIN + 52)

#define ERROR_STR_SUCCESS			"Success"
#define ERROR_NO_SUCCESS			(ERROR_NO_MIN + 0)

#define ERROR_STR_UNSPECIFIED			"Unspecified error occured"
#define ERROR_NO_UNSPECIFIED			(ERROR_NO_MIN + 1)

#define ERROR_STR_INVALID_FREQUENCY		"Invalid frequency specified"
#define ERROR_NO_INVALID_FREQUENCY		(ERROR_NO_MIN + 2)

#define ERROR_STR_INVALID_TIME			"Invalid time specified"
#define ERROR_NO_INVALID_TIME			(ERROR_NO_MIN + 3)

#define ERROR_STR_INVALID_BOARD			"Invalid board number specified"
#define ERROR_NO_INVALID_BOARD			(ERROR_NO_MIN + 4)

#define ERROR_STR_INVALID_ACQ_MODE		"Invalid acquisition mode specified"
#define ERROR_NO_INVALID_ACQ_MODE		(ERROR_NO_MIN + 5)

#define ERROR_STR_NOT_OPEN			"Device is not open"
#define ERROR_NO_NOT_OPEN			(ERROR_NO_MIN + 6)

#define ERROR_STR_INVALID_CHANNEL		"Invalid channel number specified"
#define ERROR_NO_INVALID_CHANNEL		(ERROR_NO_MIN + 7)

#define ERROR_STR_INVALID_RANGE			"Invalid range specified"
#define ERROR_NO_INVALID_RANGE			(ERROR_NO_MIN + 8)

#define ERROR_STR_INVALID_SDMODE		"Invalid single ended/differential mode specified"
#define ERROR_NO_INVALID_SDMODE			(ERROR_NO_MIN + 9)

#define ERROR_STR_INVALID_TRIGGER_MODE		"Invalid trigger mode specified"
#define ERROR_NO_INVALID_TRIGGER_MODE		(ERROR_NO_MIN + 10)

#define ERROR_STR_INVALID_CHANLIST		"Invalid channel list length"
#define ERROR_NO_INVALID_CHANLIST		(ERROR_NO_MIN + 11)

#define ERROR_STR_INITIAL_TICKS			"Initial ticks to low"
#define ERROR_NO_INITIAL_TICKS			(ERROR_NO_MIN + 12)

#define ERROR_STR_CHAN_TICKS			"Channel ticks to low"
#define ERROR_NO_CHAN_TICKS			(ERROR_NO_MIN + 13)

#define ERROR_STR_SCAN_TICKS			"Scan ticks to low"
#define ERROR_NO_SCAN_TICKS			(ERROR_NO_MIN + 14)

#define ERROR_STR_INVALID_TRIGGER_EDGE		"Invalid trigger edge specified"
#define ERROR_NO_INVALID_TRIGGER_EDGE		(ERROR_NO_MIN + 15)

#define ERROR_STR_REFRESH_FREQUENCY		"No refresh frequency specified"
#define ERROR_NO_REFRESH_FREQUENCY		(ERROR_NO_MIN + 16)

#define ERROR_STR_CALLBACK_USED			"A callback routine is installed to get the new values"
#define ERROR_NO_CALLBACK_USED			(ERROR_NO_MIN + 17)

#define ERROR_STR_INVALID_EXEC_MODE		"Invalid execution mode specified"
#define ERROR_NO_INVALID_EXEC_MODE		(ERROR_NO_MIN + 18)

#define ERROR_STR_START_THREAD			"Cannot start asynchronous thread"
#define ERROR_NO_START_THREAD			(ERROR_NO_MIN + 19)

#define ERROR_STR_CANCEL_THREAD			"Cannot cancel asynchronous thread"
#define ERROR_NO_CANCEL_THREAD			(ERROR_NO_MIN + 20)

#define ERROR_STR_INVALID_PORT			"Invalid port specified"
#define ERROR_NO_INVALID_PORT			(ERROR_NO_MIN + 21)

#define ERROR_STR_INVALID_PORT_MODE		"Invalid port mode specified"
#define ERROR_NO_INVALID_PORT_MODE		(ERROR_NO_MIN + 22)

#define ERROR_STR_INVALID_BIT			"Invalid bit specified"
#define ERROR_NO_INVALID_BIT			(ERROR_NO_MIN + 23)

#define ERROR_STR_INVALID_CONV_MODE		"Invalid conversion mode specified"
#define ERROR_NO_INVALID_CONV_MODE		(ERROR_NO_MIN + 24)

#define ERROR_STR_INVALID_STOP_MODE		"Invalid stop mode specified"
#define ERROR_NO_INVALID_STOP_MODE		(ERROR_NO_MIN + 25)

#define ERROR_STR_INVALID_PORT_FUNCTION		"Invalid port function specified"
#define ERROR_NO_INVALID_PORT_FUNCTION		(ERROR_NO_MIN + 26)

#define ERROR_STR_INVALID_MULTI_SIG_BASE	"Invalid MultiSig base board specified"
#define ERROR_NO_INVALID_MULTI_SIG_BASE		(ERROR_NO_MIN + 27)

#define ERROR_STR_INVALID_MULTI_SIG_IDENT	"Invalid MultiSig identification specified"
#define ERROR_NO_INVALID_MULTI_SIG_IDENT	(ERROR_NO_MIN + 28)

#define ERROR_STR_INVALID_MULTI_SIG_GAIN	"Invalid MultiSig gain specified"
#define ERROR_NO_INVALID_MULTI_SIG_GAIN		(ERROR_NO_MIN + 29)

#define ERROR_STR_INVALID_MULTI_SIG_GROUP	"Invalid Multi Sig group specified"
#define ERROR_NO_INVALID_MULTI_SIG_GROUP	(ERROR_NO_MIN + 30)

#define ERROR_STR_SIMULTANEOUS			"Invalid simultaneous mode specified"
#define ERROR_NO_SIMULTANEOUS			(ERROR_NO_MIN + 31)

#define ERROR_STR_SIMULTANEOUS_CHAN		"Channel timer must be at maximum when simultaneous is enabled"
#define ERROR_NO_SIMULTANEOUS_CHAN		(ERROR_NO_MIN + 32)

#define ERROR_STR_INVALID_SHAPE			"Invalid signal shape specified"
#define ERROR_NO_INVALID_SHAPE			(ERROR_NO_MIN + 33)

#define ERROR_STR_INVALID_AMPLITUDE		"Invalid signal amplitude specified"
#define ERROR_NO_INVALID_AMPLITUDE		(ERROR_NO_MIN + 34)

#define ERROR_STR_INVALID_OFFSET		"Invalid signal offset specified"
#define ERROR_NO_INVALID_OFFSET			(ERROR_NO_MIN + 35)

#define ERROR_STR_AMPLITUDE_OFFSET		"Amplitude plus offset exceeds voltage range"
#define ERROR_NO_AMPLITUDE_OFFSET		(ERROR_NO_MIN + 36)

#define ERROR_STR_INVALID_COUNTER		"Invalid counter specified"
#define ERROR_NO_INVALID_COUNTER		(ERROR_NO_MIN + 37)

#define ERROR_STR_INVALID_DUTY_CYCLE		"Invalid duty cycle"
#define ERROR_NO_INVALID_DUTY_CYCLE		(ERROR_NO_MIN + 38)

#define ERROR_STR_INVALID_COUNTER_MODE		"Invalid counter mode specified"
#define ERROR_NO_INVALID_COUNTER_MODE		(ERROR_NO_MIN + 39)

#define ERROR_STR_BUSY				"Device is already in use"
#define ERROR_NO_BUSY				(ERROR_NO_MIN + 40)

#define ERROR_STR_INVALID_OUTPUT_MODE		"Invalid ouput mode specified"
#define ERROR_NO_INVALID_OUTPUT_MODE		(ERROR_NO_MIN + 41)

#define ERROR_STR_INVALID_MULTI_SIG_MODULE_TYPE	"Invalid module type specified"
#define ERROR_NO_INVALID_MULTI_SIG_MODULE_TYPE	(ERROR_NO_MIN + 42)

#define ERROR_STR_INVALID_ERROR_NO		"Invalid error number specified"
#define ERROR_NO_INVALID_ERROR_NO		(ERROR_NO_MIN + 43)

#define ERROR_STR_ERROR_BUFFER_TO_LITTLE	"Buffer for error string to little"
#define ERROR_NO_ERROR_BUFFER_TO_LITTLE		(ERROR_NO_MIN + 44)

#define ERROR_STR_NO_SAMPLE_HOLD		"Sample and Hold not available for this board"
#define ERROR_NO_NO_SAMPLE_HOLD			(ERROR_NO_MIN + 45)

#define ERROR_STR_NO_DIFF			"Differential inputs are not available for this board"
#define ERROR_NO_NO_DIFF			(ERROR_NO_MIN + 46)

#define ERROR_STR_NO_ANALOG			"External analog trigger not available for this board"
#define ERROR_NO_NO_ANALOG			(ERROR_NO_MIN + 47)

#define ERROR_STR_INVALID_ADJUSTMENT		"Invalid adjustment mode specified"
#define ERROR_NO_INVALID_ADJUSTMENT		(ERROR_NO_MIN + 48)

#define ERROR_STR_INVALID_MUX_CHANNEL		"Invalid mux channel specified"
#define ERROR_NO_INVALID_MUX_CHANNEL		(ERROR_NO_MIN + 49)

#define ERROR_STR_INVALID_LOOPS			"Invalid loop count specified"
#define ERROR_NO_INVALID_LOOPS			(ERROR_NO_MIN + 50)

#define ERROR_STR_TEMP_RANGE			"Temperature out of range"
#define ERROR_NO_TEMP_RANGE				(ERROR_NO_MIN + 51)

#define ERROR_STR_SYSTEM			"System error in libme4000.so occured"
#define ERROR_NO_SYSTEM				(ERROR_NO_MIN + 52)

#endif
