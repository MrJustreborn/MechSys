/* Network API for Meilhaus ME-4000 board family.
 * ==============================================
 *
 *  Copyright (C) 2004 Meilhaus Electronic GmbH (support@meilhaus.de)
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Author:	Guenter Gebhardt	<g.gebhardt@meilhaus.de>
 */


#define _GNU_SOURCE // For pselect

#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>

#include <libme4000net.h>
#include <libme4000net_error.h>
#include <libme4000_error.h>
#include <me4000_srv_error.h>


#define ME4000_NET_DLL_VERSION 0x10000

/* Library stuff */
void _init(void);
void _fini(void);


/* Wrappers for read and write system calls */
static ssize_t readn(int fd, void *vptr, size_t n);
static ssize_t writen(int fd, const void *vptr, size_t n);


/* Doubly linked list declarations */
typedef struct connection_list_entry {
    struct connection_list_entry *prev;
    struct connection_list_entry *next;
    char *IPAddress;
    int sockfd;
} connection_list_entry_t;

static int connection_list_add_entry(
	struct connection_list_entry *head,
	const char *IPAddress,
	int sockfd);

static int connection_list_remove_entry(
	struct connection_list_entry *head,
	const char *IPAddress);

static int connection_list_get_sockfd(
	struct connection_list_entry *head,
	const char *IPAddress);


/* Function to catch answer to command from remote host */
static int catch_return_value(const char *IPAddress);


/* Head of global connection list */
static struct connection_list_entry connection_list_head = { NULL, NULL, "", -1 };


/* Global error number */
static int my_errno = 0;

/* Stores the system error message after a ERROR_NO_SYSTEM */
static char sysErrMsg[ME4000_MSG_MAXBUF + 1];
static int storeSystemError(int error);

/* Stores an error message received from a remote host */
static char srvErrMsg[ME4000_MSG_MAXBUF + 1];

/* Global error tables */
static char *libNetErrorTable[] = {
    LIB_NET_ERROR_STR_UNSPECIFIED,
    LIB_NET_ERROR_STR_INVALID_ERROR_NO,
    LIB_NET_ERROR_STR_ERROR_BUFFER_TO_LITTLE,
    LIB_NET_ERROR_STR_NO_CONNECTION,
    LIB_NET_ERROR_STR_INVALID_ANSWER,
    LIB_NET_ERROR_STR_INVALID_HEADER,
    LIB_NET_ERROR_STR_CONNECTION_CLOSED,
    LIB_NET_ERROR_STR_SYSTEM,
    LIB_NET_ERROR_STR_SERVER_ERROR
};

/* Flag for default error function */
static int errorDefaultProcFlag = 0;

/* Pointer to user defined error function */
static ME4000_P_ERROR_PROC errorUserProcPtr = NULL;

/* Internal default error handler */
static void errorDefaultProc(char *function, int iErrorCode);



/*============================================================================= 
  Initialization and cleanup of shared object
  ===========================================================================*/

void _init(void){
    /* Ignore the SIGPIPE in cases, when we make subsequent writes
       to a broken connection. Let the second write() to the socket
       catch the error EPIPE */
    signal(SIGPIPE, SIG_IGN);
    return;
}

void _fini(void){
    return;
}


/*============================================================================= 
  Wrappers for read and write
  ===========================================================================*/

ssize_t readn(int fd, void *vptr, size_t n){
    size_t nleft;
    ssize_t nread;
    char *ptr;

    ptr = vptr;
    nleft = n;
    while (nleft > 0) {
	if ((nread = read(fd, ptr, nleft)) < 0){
	    if (errno == EINTR)
		nread = 0; /* and call read() again */
	    else
		return(-1);
	} else if (nread == 0)
	    break; /* EOF */

	nleft -= nread;
	ptr += nread;
    }
    return(n - nleft); /* return >= 0 */
}


ssize_t writen(int fd, const void *vptr, size_t n){
    size_t nleft;
    ssize_t nwritten;
    const char	*ptr;

    ptr = vptr;
    nleft = n;
    while(nleft > 0){
	if((nwritten = write(fd, ptr, nleft)) <= 0){
	    if (errno == EINTR)
		nwritten = 0; /* and call write() again */
	    else
		return(-1); /* error */
	}

	nleft -= nwritten;
	ptr += nwritten;
    }
    return(n);
}


/*=============================================================================
  Connection list methods
  ===========================================================================*/

static int connection_list_add_entry(
	struct connection_list_entry *head,
	const char *IPAddress,
	int sockfd){
    struct connection_list_entry *pentry = head;

    /* Search last entry in list */
    while(pentry->next != NULL){
	pentry = pentry->next;
    }

    /* Allocate new entry */
    pentry->next = malloc(sizeof(struct connection_list_entry));
    if(!pentry->next) return 1;

    /* Allocate space for the IP address */
    pentry->next->IPAddress = malloc(strlen(IPAddress) + 1);
    if(!pentry->next->IPAddress){
	free(pentry->next);
	return 1;
    }

    /* Save new data in entry */
    strcpy(pentry->next->IPAddress, IPAddress);
    pentry->next->prev = pentry;
    pentry->next->next = NULL;
    pentry->next->sockfd = sockfd;

    return 0;
}


static int connection_list_remove_entry(
	struct connection_list_entry *head,
	const char *IPAddress){
    struct connection_list_entry *pentry = head;
    int removed = 0;

    while(pentry->next != 0){
	pentry = pentry->next;
	if(!strcmp(pentry->IPAddress, IPAddress)){
	    pentry->prev->next = pentry->next;
	    if(pentry->next){
		pentry->next->prev = pentry->prev;
	    }
	    free(pentry->IPAddress);
	    free(pentry);
	    removed++;
	    break;
	}
    }

    return removed;
}


static int connection_list_get_sockfd(
	struct connection_list_entry *head,
	const char *IPAddress){
    struct connection_list_entry *pentry = head;

    while(pentry->next != 0){
	pentry = pentry->next;
	if(!strcmp(pentry->IPAddress, IPAddress)){
	    return pentry->sockfd;
	}
    }

    return -1;
}


/*=============================================================================
  Connect and disconnect to the server
  ===========================================================================*/

int me4000NetConnect(const char *IPAddress){
    int	sockfd;
    struct sockaddr_in servaddr;

    /* Check if a connection to IPAddress is already established */
    if(connection_list_get_sockfd(&connection_list_head, IPAddress) >= 0)
       	return 0; // Already established

    /* Create a socket */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if(sockfd < 0){
	return storeSystemError(errno);
    }

    /* Create and fill the socket address structure */
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(ME4000_SERVER_PORT);
    if(inet_pton(AF_INET, IPAddress, &servaddr.sin_addr) != 1){
    	close(sockfd);
	return storeSystemError(errno);
    }

    /* Connect to the server */
    if(connect(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr))){
    	close(sockfd);
	return storeSystemError(errno);
    }

    /* Connect was successful so add entry to connection list */
    if(connection_list_add_entry( &connection_list_head, IPAddress, sockfd)){
    	close(sockfd);
	return storeSystemError(errno);
    }

    return 0;
}


int me4000NetDisconnect(const char *IPAddress){
    int	sockfd;

    /* Check if a connection to IPAddress is established */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0) return 0; // Already disconnected

    connection_list_remove_entry(&connection_list_head, IPAddress);
    close(sockfd);

    return 0;
}


typedef struct infoContainer {
    char **entries;
    int count;
} infoContainer_t;


static struct infoContainer *infoContainerInit(void){
    struct infoContainer *info;

    info = malloc(sizeof(struct infoContainer));
    if(!info){
	return NULL;
    }
    else{
	info->entries = NULL;
	info->count = 0;
    }
    return info;
}

static void infoContainerDel(struct infoContainer *info){
    int i;

    for(i = 0; i < info->count; i++)
	free(info->entries[i]);
    free(info);
}

static int infoContainerAdd(struct infoContainer *info, char *entry){
    int i;
    int n = info->count + 1;
    char **entries;

    entries = malloc(sizeof(char *) * n);
    if(!entries){
	return 1;
    }
    else{
	for(i = 0; i < info->count; i++){
	    entries[i] = info->entries[i];
	}
	entries[i] = entry;
	free(info->entries);
	info->entries = entries;
	info->count++;
    }

    return 0;
}

static int infoContainerGetCount(struct infoContainer *info){
    return info->count;
}

static char **infoContainerGetPointer(struct infoContainer *info){
    return info->entries;
}


static void recvfrom_alarm(int signo){
    return;
}


int me4000NetLookup(const char *IPAddress, char ***pcInfo, int *piEntryCount){
    int	sockfd;
    struct sockaddr_in	servaddr;
    int	n;
    const int on = 1;
    struct infoContainer *container;
    char sendline[ME4000_MSG_MAXBUF];
    char recvline[ME4000_MSG_MAXBUF + 1];
    char serverip[ME4000_MSG_MAXBUF];
    struct hostent *servername = NULL;
    char *entry;
    fd_set rset;
    sigset_t sigset_alrm, sigset_empty;
    socklen_t len;
    struct sockaddr_in *preply_addr;

    container = infoContainerInit();
    if(!container){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetLookup()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetLookup()", my_errno);
	return my_errno;
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(ME4000_SERVER_PORT);
    if(inet_pton(AF_INET, IPAddress, &servaddr.sin_addr) != 1){
	infoContainerDel(container);
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetLookup()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetLookup()", my_errno);
	return my_errno;
    }

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if(sockfd < 0){
	infoContainerDel(container);
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetLookup()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetLookup()", my_errno);
	return my_errno;
    }

    preply_addr = malloc(sizeof(servaddr));
    if(!preply_addr){
	infoContainerDel(container);
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetLookup()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetLookup()", my_errno);
	return my_errno;
    }

    if(setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &on, sizeof(on))){
	infoContainerDel(container);
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetLookup()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetLookup()", my_errno);
	return my_errno;
    }

    FD_ZERO(&rset);
    sigemptyset(&sigset_empty);
    sigemptyset(&sigset_alrm);
    sigaddset(&sigset_alrm, SIGALRM);

    if(signal(SIGALRM, recvfrom_alarm) == SIG_ERR){
	infoContainerDel(container);
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetLookup()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetLookup()", my_errno);
	return my_errno;
    }

    snprintf(sendline, sizeof(sendline), "Hello, server!");
    n = sendto(sockfd, sendline, strlen(sendline), 0, (struct sockaddr *) &servaddr, sizeof(servaddr));
    if(n < 0){
	infoContainerDel(container);
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetLookup()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetLookup()", my_errno);
	return my_errno;
    }

    sigprocmask(SIG_BLOCK, &sigset_alrm, NULL);
    alarm(5);
    while(1){
	FD_SET(sockfd, &rset);
	n = pselect(sockfd + 1, &rset, NULL, NULL, NULL, &sigset_empty);
	if (n < 0){
	    if (errno == EINTR)
		break;
	    else{
		infoContainerDel(container);
		storeSystemError(errno);
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetLookup()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetLookup()", my_errno);
		return my_errno;
	    }
	}
       	else if (n != 1){
	    infoContainerDel(container);
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetLookup()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetLookup()", my_errno);
	    return my_errno;
	}

	len = sizeof(struct sockaddr_in);
	n = recvfrom(sockfd, recvline, ME4000_MSG_MAXBUF, 0, (struct sockaddr *) preply_addr, &len);
	if(n < 0){
	    infoContainerDel(container);
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetLookup()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetLookup()", my_errno);
	    return my_errno;
	}
	recvline[n] = 0; /* null terminate */

	if(!inet_ntop(AF_INET, &preply_addr->sin_addr.s_addr, serverip, sizeof(serverip))){
	    infoContainerDel(container);
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetLookup()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetLookup()", my_errno);
	    return my_errno;
	}

	entry = malloc(ME4000_MSG_MAXBUF);
	if(!entry){
	    infoContainerDel(container);
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetLookup()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetLookup()", my_errno);
	    return my_errno;
	}

	servername = gethostbyaddr(&preply_addr->sin_addr, sizeof(struct in_addr), AF_INET);
	if(!servername){
	    snprintf(entry, ME4000_MSG_MAXBUF, "%s %s %s", "Unknown", serverip, recvline);
	}
	else{
	    snprintf(entry, ME4000_MSG_MAXBUF, "%s %s %s", servername->h_name, serverip, recvline);
	}

	if(infoContainerAdd(container, entry)){
	    infoContainerDel(container);
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetLookup()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetLookup()", my_errno);
	    return my_errno;
	}
    }

    *piEntryCount = infoContainerGetCount(container);
    *pcInfo = infoContainerGetPointer(container);
    return 0;
}



/*=============================================================================
  Function to catch return value from function calls to remote host
  ===========================================================================*/

/* This function catches the error code from function calls to
   the remote host which only return an error code and no more data */
static int catch_return_value(const char *IPAddress){
    int iReturnValue;
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int n;
    int sockfd;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
       	return LIB_NET_ERROR_NO_NO_CONNECTION;
    }

    /* Catch the return value from the remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	return storeSystemError(errno);
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n != 1){
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
       	return my_errno;
    }

    if(iReturnValue){
	memset(srvErrMsg, 0, ME4000_MSG_MAXBUF);
	n = sscanf(msg, "%i %"ME4000_MSG_MAXBUF_STR"c", &iReturnValue, srvErrMsg);
	if(n != 2){
	    my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	    return my_errno;
	}
	my_errno = LIB_NET_ERROR_NO_SERVER_ERROR;
	return my_errno;
    }

    return ME4000_NO_ERROR;
}


/*===========================================================================
  Error handling functions
  =========================================================================*/

int me4000NetErrorGetMessage(
	int iErrorCode, 
	char *pcBuffer, 
	unsigned int uiBufferSize){

    if((iErrorCode >= LIB_NET_ERROR_NO_MIN) && (iErrorCode <= LIB_NET_ERROR_NO_MAX)){
	if(iErrorCode == LIB_NET_ERROR_NO_SYSTEM){
	    strncpy(pcBuffer, sysErrMsg, uiBufferSize);
	}
	else if(iErrorCode == LIB_NET_ERROR_NO_SERVER_ERROR){
	    strncpy(pcBuffer, srvErrMsg, uiBufferSize);
	}
	else{
	    strncpy(pcBuffer, libNetErrorTable[iErrorCode - LIB_NET_ERROR_NO_MIN], uiBufferSize);
	}
    }
    else if((iErrorCode >= ERROR_NO_MIN) && (iErrorCode <= ERROR_NO_MAX)){ // Standard library error
	return me4000ErrorGetMessage(iErrorCode, pcBuffer, uiBufferSize);
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ERROR_NO;
	strncpy(pcBuffer, libNetErrorTable[my_errno - LIB_NET_ERROR_NO_MIN], uiBufferSize);
       	return LIB_NET_ERROR_NO_INVALID_ERROR_NO;
    }

    return 0;
}


int me4000NetErrorGetLastMessage(
	char *pcBuffer,
       	unsigned int uiBufferSize){
    return me4000NetErrorGetMessage(my_errno, pcBuffer, uiBufferSize);
}


int me4000NetErrorSetDefaultProc(int iDefaultProcStatus){
    errorDefaultProcFlag = iDefaultProcStatus;
    return ME4000_NO_ERROR;
}



int me4000NetErrorSetUserProc(ME4000_P_ERROR_PROC pErrorProc){
    errorUserProcPtr = pErrorProc;
    return ME4000_NO_ERROR;
}


static int storeSystemError(int error){
    strcpy(sysErrMsg, strerror(error));
    my_errno = LIB_NET_ERROR_NO_SYSTEM;
    return LIB_NET_ERROR_NO_SYSTEM;
}


static int storeServerError(const char *msg){
    int iReturnValue;
    int n;

    memset(srvErrMsg, 0, ME4000_MSG_MAXBUF);
    n = sscanf(msg, "%i %"ME4000_MSG_MAXBUF_STR"c", &iReturnValue, srvErrMsg);
    if(n != 2)
	return (my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER);

    return (my_errno = LIB_NET_ERROR_NO_SERVER_ERROR);
}


static void errorDefaultProc(char *function, int iErrorCode){
    char msg[64] = {0};
    me4000NetErrorGetMessage(iErrorCode, msg, sizeof(msg));
    fprintf(stderr, "In function %s: %s (%d)\n", function, msg, iErrorCode);
}



/*===========================================================================
  General Functions
  =========================================================================*/

int me4000NetFrequencyToTicks(
	double dRequiredFreq, 
	unsigned long *pulTicksLowPart, 
	unsigned long *pulTicksHighPart, 
	double *pdAchievedFreq){
    int iReturnValue;

    iReturnValue = me4000FrequencyToTicks(
	    dRequiredFreq, 
	    pulTicksLowPart,
	    pulTicksHighPart, 
	    pdAchievedFreq);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetFrequencyToTicks()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetFrequencyToTicks()", my_errno);
	return iReturnValue;
    }

    return ME4000_NO_ERROR;
}



int me4000NetTimeToTicks(
	double dRequiredTime, 
	unsigned long *pulTicksLowPart, 
	unsigned long *pulTicksHighPart, 
	double *pdAchievedTime){
    int iReturnValue;

    iReturnValue = me4000TimeToTicks(
	    dRequiredTime, 
	    pulTicksLowPart, 
	    pulTicksHighPart, 
	    pdAchievedTime);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetTimeToTicks()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetTimeToTicks()", my_errno);
	return iReturnValue;
    }

    return ME4000_NO_ERROR;
}



int me4000NetGetBoardVersion(const char *IPAddress, unsigned int uiBoardNumber, unsigned short *pusVersion){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int iReturnValue;
    int sockfd;
    int n;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetBoardVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetBoardVersion()", my_errno);
       	return LIB_NET_ERROR_NO_NO_CONNECTION;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_GET_BOARD_VERSION_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	iReturnValue = storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetBoardVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetBoardVersion()", my_errno);
       	return iReturnValue;
    }

    /* Catch the return value from the remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	iReturnValue = storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetBoardVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetBoardVersion()", my_errno);
       	return iReturnValue;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetBoardVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetBoardVersion()", my_errno);
	return my_errno;
    }

    msg[n] = '\0'; // Null terminate the string
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetGetBoardVersion()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetGetBoardVersion()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %hu", &iReturnValue, pusVersion);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetGetBoardVersion()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetGetBoardVersion()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetBoardVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetBoardVersion()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}


int me4000NetGetDLLVersion(const char *IPAddress, unsigned long *pulVersion){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int iReturnValue;
    int sockfd;
    int n;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetDLLVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetDLLVersion()", my_errno);
       	return LIB_NET_ERROR_NO_NO_CONNECTION;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i", ME4000_GET_DLL_VERSION_ID);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	iReturnValue = storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetDLLVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetDLLVersion()", my_errno);
       	return iReturnValue;
    }

    /* Catch the return value from the remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	iReturnValue = storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetDLLVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetDLLVersion()", my_errno);
       	return iReturnValue;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetDLLVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetDLLVersion()", my_errno);
	return my_errno;
    }

    msg[n] = '\0'; // Null terminate the string
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetGetDLLVersion()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetGetDLLVersion()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %lu", &iReturnValue, pulVersion);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetGetDLLVersion()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetGetDLLVersion()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetDLLVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetDLLVersion()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}


int me4000NetGetNetDLLVersion(unsigned long *pulVersion){
    *pulVersion = ME4000_NET_DLL_VERSION;
    return ME4000_NO_ERROR;
}


int me4000NetGetDriverVersion(const char *IPAddress, unsigned long *pulVersion){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int iReturnValue;
    int sockfd;
    int n;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetDriverVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetDriverVersion()", my_errno);
       	return LIB_NET_ERROR_NO_NO_CONNECTION;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i", ME4000_GET_DRIVER_VERSION_ID);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	iReturnValue = storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetDriverVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetDriverVersion()", my_errno);
       	return iReturnValue;
    }

    /* Catch the return value from the remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	iReturnValue = storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetDriverVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetDriverVersion()", my_errno);
       	return iReturnValue;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetDriverVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetDriverVersion()", my_errno);
	return my_errno;
    }

    msg[n] = '\0'; // Null terminate the string
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetGetDriverVersion()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetGetDriverVersion()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %lu", &iReturnValue, pulVersion);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetGetDriverVersion()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetGetDriverVersion()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetDriverVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetDriverVersion()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}


int me4000NetGetSerialNumber(const char *IPAddress, unsigned int uiBoardNumber, unsigned long *pulSerialNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int iReturnValue;
    int sockfd;
    int n;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetSerialNumber()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetSerialNumber()", my_errno);
       	return LIB_NET_ERROR_NO_NO_CONNECTION;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_GET_SERIAL_NUMBER_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	iReturnValue = storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetSerialNumber()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetSerialNumber()", my_errno);
       	return iReturnValue;
    }

    /* Catch the return value from the remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	iReturnValue = storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetSerialNumber()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetSerialNumber()", my_errno);
       	return iReturnValue;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetSerialNumber()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetSerialNumber()", my_errno);
	return my_errno;
    }

    msg[n] = '\0'; // Null terminate the string
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetGetSerialNumber()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetGetSerialNumber()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %lu", &iReturnValue, pulSerialNumber);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetGetSerialNumber()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetGetSerialNumber()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetSerialNumber()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetSerialNumber()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}


int me4000NetGetBoardCount(void){
    return me4000GetBoardCount();
}


/*=============================================================================
  Analog input functions
  ===========================================================================*/

int me4000NetAIOpen(const char *IPAddress, unsigned int uiBoardNumber, int iAcqMode){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIOpen()", my_errno);
       	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %i", ME4000_AI_OPEN_ID, uiBoardNumber, iAcqMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIOpen()", my_errno);
       	return my_errno;
    }

    /* Get the answer */
    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIOpen()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetAIClose(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIClose()", my_errno);
	return my_errno;
    }

    /* Send request to remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_AI_CLOSE_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIClose()", my_errno);
	return my_errno;
    }

    /* Get the answer */
    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIClose()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}


int me4000NetAIConfig(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned char *pucChanList, 
	unsigned int uiChanListCount, 
	int iSDMode, 
	int iSimultaneous,
	unsigned long ulChanTicks, 
	unsigned long ulScanTicksLow, 
	unsigned long ulScanTicksHigh, 
	int iAcqMode,
	int iExtTriggerMode, 
	int iExtTriggerEdge){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIConfig()", my_errno);
	return my_errno;
    }

    /* Send request to remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %i %i %lu %lu %lu %i %i %i",
	    ME4000_AI_CONFIG_ID,
	    uiBoardNumber,
	    uiChanListCount,
	    iSDMode,
	    iSimultaneous,
	    ulChanTicks,
	    ulScanTicksLow,
	    ulScanTicksHigh,
	    iAcqMode,
	    iExtTriggerMode,
	    iExtTriggerEdge);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIConfig()", my_errno);
	return my_errno;
    }

    /* Transfer the channel list */
    if(writen(sockfd, pucChanList, sizeof(unsigned char) * uiChanListCount) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIConfig()", my_errno);
	return my_errno;
    }

    /* Get the answer */
    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIConfig()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}


int me4000NetAIContinuous(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned int uiRefreshFrequency,
	unsigned long ulTimeOutSeconds){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIContinuous()", my_errno);
	return my_errno;
    }

    /* Send request to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %lu",
	    ME4000_AI_CONTINUOUS_ID,
	    uiBoardNumber,
	    uiRefreshFrequency,
	    ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIContinuous()", my_errno);
	return my_errno;
    }

    /* Get the answer */
    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIContinuous()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}


int me4000NetAIDigitToVolt(
	short sDigit, 
	int iRange, 
	double *pdVolt){
    int iReturnValue;

    iReturnValue = me4000AIDigitToVolt(
	    sDigit, 
	    iRange, 
	    pdVolt);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIDigitToVolt()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIDigitToVolt()", my_errno);
	return iReturnValue;
    }

    return ME4000_NO_ERROR;
}



int me4000NetAIExtractValues(
	unsigned int uiChannelNumber, 
	short *psAIBuffer, 
	unsigned long ulAIDataCount, 
	unsigned char *pucChanList, 
	unsigned int uiChanListCount, 
	short *psChanBuffer, 
	unsigned long ulChanBufferSizeValues, 
	unsigned long *pulChanDataCount){
    int iReturnValue;

    iReturnValue = me4000AIExtractValues(
	    uiChannelNumber, 
	    psAIBuffer, 
	    ulAIDataCount, 
	    pucChanList, 
	    uiChanListCount, 
	    psChanBuffer, 
	    ulChanBufferSizeValues, 
	    pulChanDataCount);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIExtractValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIExtractValues()", my_errno);
	return iReturnValue;
    }

    return ME4000_NO_ERROR;
}



int me4000NetAIGetNewValues(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	short *psBuffer, 
	unsigned long ulNumberOfValuesToRead,
	int iExecutionMode,
	unsigned long *pulNumberOfValuesRead){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;
    int n;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetNewValues()", my_errno);
	return my_errno;
    }

    /* Send the request */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %lu %i",
	    ME4000_AI_GET_NEW_VALUES_ID,
	    uiBoardNumber,
	    ulNumberOfValuesToRead,
	    iExecutionMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetNewValues()", my_errno);
	return my_errno;
    }

    /* Get the answer */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetNewValues()", my_errno);
	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetNewValues()", my_errno);
	return my_errno;
    }

    msg[n] = '\0'; // Null terminate the string
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetAIGetNewValues()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetAIGetNewValues()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %lu", &iReturnValue, pulNumberOfValuesRead);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetAIGetNewValues()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetAIGetNewValues()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetNewValues()", my_errno);
       	return my_errno;
    }

    if(*pulNumberOfValuesRead){
	/* Catch the data from the remote host */
	n = readn(sockfd, psBuffer, sizeof(short) * (*pulNumberOfValuesRead));
	if(n < 0){
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetAIGetNewValues()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetAIGetNewValues()", my_errno);
	    return my_errno;
	}
	else if(n == 0){ // Connection closed by remote host
	    me4000NetDisconnect(IPAddress);
	    my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetAIGetNewValues()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetAIGetNewValues()", my_errno);
	    return my_errno;
	}
    }

    return ME4000_NO_ERROR;
}


int me4000NetAIGetStatus(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	int iWaitIdle,
	int *piStatus){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int n;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetStatus()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %i",
	    ME4000_AI_GET_STATUS_ID,
	    uiBoardNumber,
	    iWaitIdle);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetStatus()", my_errno);
       	return my_errno;
    }

    /* Catch return values from remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetStatus()", my_errno);
       	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetStatus()", my_errno);
	return my_errno;
    }

    msg[n] = '\0'; // Null terminate the string
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetAIGetStatus()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetAIGetStatus()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %i", &iReturnValue, piStatus);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetAIGetStatus()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetAIGetStatus()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetStatus()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}


int me4000NetAIMakeChannelListEntry(
	unsigned int uiChannelNumber, 
	int iRange, 
	unsigned char *pucChanListEntry){
    int iReturnValue;

    iReturnValue = me4000AIMakeChannelListEntry(
	    uiChannelNumber, 
	    iRange, 
	    pucChanListEntry);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIMakeChannelListEntry()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIMakeChannelListEntry()", my_errno);
	return iReturnValue;
    }

    return ME4000_NO_ERROR;
}



int me4000NetAIReset(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIReset()", my_errno);
	return my_errno;
    }

    /* Send the request */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_AI_RESET_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIReset()", my_errno);
	return my_errno;
    }

    /* Get the reply */
    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIReset()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}


int me4000NetAIScan(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned int uiNumberOfChanLists,
	short *psBuffer, 
	unsigned long ulBufferSizeValues,
	unsigned long ulTimeOutSeconds){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;
    int n;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIScan()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIScan()", my_errno);
	return my_errno;
    }

    /* Send the request */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %lu %lu",
	    ME4000_AI_SCAN_ID,
	    uiBoardNumber,
	    uiNumberOfChanLists,
	    ulBufferSizeValues,
	    ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIScan()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIScan()", my_errno);
	return my_errno;
    }

    /* Get the error code */
    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIScan()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIScan()", my_errno);
       	return my_errno;
    }

    if(ulBufferSizeValues){
	/* Catch the data from the remote host */
	n = readn(sockfd, psBuffer, sizeof(short) * ulBufferSizeValues);
	if(n < 0){
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetAIScan()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetAIScan()", my_errno);
	    return my_errno;
	}
	else if(n == 0){ // Connection closed by remote host
	    me4000NetDisconnect(IPAddress);
	    my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetAIScan()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetAIScan()", my_errno);
	    return my_errno;
	}
    }

    return iReturnValue;
}


int me4000NetAISingle(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned int uiChannelNumber,
	int iRange, 
	int iSDMode, 
	int iTriggerMode,
	int iExtTriggerEdge, 
	unsigned long ulTimeOutSeconds, 
	short *psDigitalValue){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int n;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetSingle()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %i %i %i %i %lu",
	    ME4000_AI_SINGLE_ID,
	    uiBoardNumber,
	    uiChannelNumber,
	    iRange,
	    iSDMode,
	    iTriggerMode,
	    iExtTriggerEdge,
	    ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetSingle()", my_errno);
       	return my_errno;
    }

    /* Catch return values from remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetSingle()", my_errno);
	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetSingle()", my_errno);
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetAIGetSingle()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetAIGetSingle()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %hi", &iReturnValue, psDigitalValue);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetAIGetSingle()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetAIGetSingle()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIGetSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIGetSingle()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}


int me4000NetAIStop(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIStop()", my_errno);
	return my_errno;
    }

    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_AI_STOP_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIStop()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAIStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAIStop()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}



/*=============================================================================
  Analog output functions
  ===========================================================================*/

int me4000NetAOOpen(
	const char *IPAddress,
       	unsigned int uiBoardNumber,
	unsigned int uiChannelNumber, 
       	int iConversionMode){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
       	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOOpen()", my_errno);
       	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %i",
	    ME4000_AO_OPEN_ID,
	    uiBoardNumber,
	    uiChannelNumber,
	    iConversionMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
       	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOOpen()", my_errno);
       	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOOpen()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}



int me4000NetAOClose(
	const char *IPAddress,
       	unsigned int uiBoardNumber,
	unsigned int uiChannelNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOClose()", my_errno);
       	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u",
	    ME4000_AO_CLOSE_ID,
	    uiBoardNumber,
	    uiChannelNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOClose()", my_errno);
       	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOClose()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}



int me4000NetAOAppendNewValues(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned int uiChannelNumber,
	unsigned short *pusBuffer, 
	unsigned long ulNumberOfValuesToAppend, 
	int iExecutionMode,
	unsigned long *pulNumberOfValuesAppended){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int n;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOAppendNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOAppendNewValues()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %lu %i",
	    ME4000_AO_APPEND_NEW_VALUES_ID,
	    uiBoardNumber,
	    uiChannelNumber,
	    ulNumberOfValuesToAppend,
	    iExecutionMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOAppendNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOAppendNewValues()", my_errno);
       	return my_errno;
    }

    if(ulNumberOfValuesToAppend){
	/* Send the data to the remote host */
	if(writen(sockfd, pusBuffer, sizeof(*pusBuffer) * ulNumberOfValuesToAppend) < 0){
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetAOAppendNewValues()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetAOAppendNewValues()", my_errno);
	    return my_errno;
	}
    }

    /* Catch return values from remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOAppendNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOAppendNewValues()", my_errno);
       	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOAppendNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOAppendNewValues()", my_errno);
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetAOAppendNewValues()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetAOAppendNewValues()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %lu", &iReturnValue, pulNumberOfValuesAppended);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetAOAppendNewValues()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetAOAppendNewValues()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOAppendNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOAppendNewValues()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetAOConfig(
	const char *IPAddress,
       	unsigned int uiBoardNumber,
	unsigned int uiChannelNumber,
       	unsigned long ulTicks,
       	int iTriggerMode,
	int iExtTriggerEdge){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOConfig()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %lu %i %i",
	    ME4000_AO_CONFIG_ID,
	    uiBoardNumber,
	    uiChannelNumber,
	    ulTicks,
	    iTriggerMode,
	    iExtTriggerEdge);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOConfig()", my_errno);
       	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOConfig()", my_errno);
       	return my_errno;
    }

    return 0;
}



int me4000NetAOContinuous(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned int uiChannelNumber,
	unsigned short *pusBuffer, 
	unsigned long ulDataCount, 
	unsigned long ulTimeOutSeconds,
	unsigned long *pulNumberOfValuesWritten){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int n;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOContinuous()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %lu %lu",
	    ME4000_AO_CONTINUOUS_ID,
	    uiBoardNumber,
	    uiChannelNumber,
	    ulDataCount,
	    ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOContinuous()", my_errno);
       	return my_errno;
    }

    if(ulDataCount){
	/* Send the data to the remote host */
	if(writen(sockfd, pusBuffer, sizeof(unsigned short) * ulDataCount) < 0){
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetAOContinuous()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetAOContinuous()", my_errno);
	    return my_errno;
	}
    }

    /* Catch return values from remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOContinuous()", my_errno);
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOContinuous()", my_errno);
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetAOContinuous()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetAOContinuous()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %lu", &iReturnValue, pulNumberOfValuesWritten);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetAOContinuous()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetAOContinuous()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOContinuous()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetAOGetStatus(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned int uiChannelNumber,
	int iWaitIdle,
	int *piStatus){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int n;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOGetStatus()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %i",
	    ME4000_AO_GET_STATUS_ID,
	    uiBoardNumber,
	    uiChannelNumber,
	    iWaitIdle);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOGetStatus()", my_errno);
	return my_errno;
    }

    /* Catch return values from remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	return storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOGetStatus()", my_errno);
       	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOGetStatus()", my_errno);
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetGetBoardVersion()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetGetBoardVersion()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %i", &iReturnValue, piStatus);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetGetBoardVersion()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetGetBoardVersion()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetGetBoardVersion()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetGetBoardVersion()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetAOReset(
	const char *IPAddress,
       	unsigned int uiBoardNumber,
	unsigned int uiChannelNumber){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOReset()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u",
	    ME4000_AO_RESET_ID,
	    uiBoardNumber,
	    uiChannelNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOReset()", my_errno);
       	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOReset()", my_errno);
	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetAOSingle(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned int uiChannelNumber, 
	int iTriggerMode,
	int iExtTriggerEdge,
	unsigned long ulTimeOutSeconds,
	unsigned short usValue){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOSingle()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %i %i %lu %hu",
	    ME4000_AO_SINGLE_ID,
	    uiBoardNumber,
	    uiChannelNumber,
	    iTriggerMode,
	    iExtTriggerEdge,
	    ulTimeOutSeconds,
	    usValue);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOSingle()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOSingle()", my_errno);
	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetAOSingleSimultaneous(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned int *puiChannelNumber,
	unsigned long ulCount,
	int iTriggerMode,
	int *piExtTriggerEnable,
	int *piExtTriggerEdge,
	unsigned long ulTimeOutSeconds,
	unsigned short *pusValue){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOSingleSimultaneous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOSingleSimultaneous()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %lu %i %lu",
	    ME4000_AO_SINGLE_SIMULTANEOUS_ID,
	    uiBoardNumber,
	    ulCount,
	    iTriggerMode,
	    ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOSingleSimultaneous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOSingleSimultaneous()", my_errno);
       	return my_errno;
    }

    /* Send the channel list to the remote host */
    if(writen(sockfd, puiChannelNumber, sizeof(unsigned int) * ulCount) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOSingleSimultaneous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOSingleSimultaneous()", my_errno);
       	return my_errno;
    }

    /* Send the external trigger enable list to the remote host */
    if(writen(sockfd, piExtTriggerEnable, sizeof(int) * ulCount) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOSingleSimultaneous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOSingleSimultaneous()", my_errno);
       	return my_errno;
    }

    /* Send the external trigger edge list to the remote host */
    if(writen(sockfd, piExtTriggerEdge, sizeof(int) * ulCount) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOSingleSimultaneous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOSingleSimultaneous()", my_errno);
       	return my_errno;
    }

    /* Send the data to the remote host */
    if(writen(sockfd, pusValue, sizeof(unsigned short) * ulCount) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOSingleSimultaneous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOSingleSimultaneous()", my_errno);
       	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOSingleSimultaneous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOSingleSimultaneous()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetAOStart(
	const char *IPAddress,
       	unsigned int uiBoardNumber,
	unsigned int uiChannelNumber){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOStart()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOStart()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u",
	    ME4000_AO_START_ID,
	    uiBoardNumber,
	    uiChannelNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOStart()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOStart()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOStart()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOStart()", my_errno);
	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetAOStartSynchronous(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned int *puiChannelNumber, 
	unsigned long ulCount, 
	int iTriggerMode, 
	int *piExtTriggerEnable,
	int *piExtTriggerEdge,
	unsigned long ulTimeOutSeconds){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOStartSynchronous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOStartSynchronous()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %lu %i %lu",
	    ME4000_AO_START_SYNCHRONOUS_ID,
	    uiBoardNumber,
	    ulCount,
	    iTriggerMode,
	    ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOStartSynchronous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOStartSynchronous()", my_errno);
       	return my_errno;
    }

    /* Send the channel list to the remote host */
    if(writen(sockfd, puiChannelNumber, sizeof(unsigned int) * ulCount) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOStartSynchronous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOStartSynchronous()", my_errno);
       	return my_errno;
    }

    /* Send the external trigger enable list to the remote host */
    if(writen(sockfd, piExtTriggerEnable, sizeof(int) * ulCount) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOStartSynchronous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOStartSynchronous()", my_errno);
       	return my_errno;
    }

    /* Send the external trigger edge list to the remote host */
    if(writen(sockfd, piExtTriggerEdge, sizeof(int) * ulCount) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOStartSynchronous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOStartSynchronous()", my_errno);
       	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOStartSynchronous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOStartSynchronous()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetAOStop(
	const char *IPAddress,
       	unsigned int uiBoardNumber,
	unsigned int uiChannelNumber,
	int iStopMode){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOStop()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %i",
	    ME4000_AO_STOP_ID,
	    uiBoardNumber,
	    uiChannelNumber,
	    iStopMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOStop()", my_errno);
       	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOStop()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetAOVoltToDigit(
	double dVolt,
	unsigned short *pusDigit){
    int iReturnValue;

    iReturnValue = me4000AOVoltToDigit(dVolt, pusDigit);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOVoltToDigit()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOVoltToDigit()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetAOWaveGen(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned int uiChannelNumber, 
	int iShape, 
	double dAmplitude, 
	double dOffset, 
	double dFrequency){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOWaveGen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOWaveGen()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %i %lf %lf %lf",
	    ME4000_AO_WAVE_GEN_ID,
	    uiBoardNumber,
	    uiChannelNumber,
	    iShape,
	    dAmplitude,
	    dOffset,
	    dFrequency);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOWaveGen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOWaveGen()", my_errno);
       	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOWaveGen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOWaveGen()", my_errno);
	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetAOWraparound(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned int uiChannelNumber,
	unsigned short *pusBuffer, 
	unsigned long ulDataCount, 
	unsigned long ulTimeOutSeconds){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOWraparound()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOWraparound()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %lu %lu",
	    ME4000_AO_WRAPAROUND_ID,
	    uiBoardNumber,
	    uiChannelNumber,
	    ulDataCount,
	    ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOWraparound()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOWraparound()", my_errno);
	return my_errno;
    }

    if(ulDataCount){
	/* Send the data to the remote host */
	if(writen(sockfd, pusBuffer, sizeof(*pusBuffer) * ulDataCount) < 0){
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetAOWraparound()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetAOWraparound()", my_errno);
	    return my_errno;
	}
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetAOWraparound()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetAOWraparound()", my_errno);
	return my_errno;
    }

    return ME4000_NO_ERROR;
}



/*=============================================================================
  Digital I/O functions
  ===========================================================================*/

int me4000NetDIOOpen(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOOpen()", my_errno);
	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_DIO_OPEN_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOOpen()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOOpen()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetDIOClose(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOClose()", my_errno);
	return my_errno;
    }

    /* Try to close device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_DIO_CLOSE_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOClose()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOClose()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetDIOConfig(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned int uiPortNumber, 
	int iPortDirection){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOConfig()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %i",
	    ME4000_DIO_CONFIG_ID,
	    uiBoardNumber,
	    uiPortNumber,
	    iPortDirection);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOConfig()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOConfig()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetDIOGetBit(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned int uiPortNumber, 
	unsigned int uiBitNumber, 
	int *piBitValue){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int iReturnValue;
    int sockfd;
    int n;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOGetBit()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOGetBit()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %u",
	    ME4000_DIO_GET_BIT_ID,
	    uiBoardNumber,
	    uiPortNumber,
	    uiBitNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOGetBit()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOGetBit()", my_errno);
	return my_errno;
    }

    /* Catch the return value from the remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOGetBit()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOGetBit()", my_errno);
	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOGetBit()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOGetBit()", my_errno);
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetDIOGetBit()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetDIOGetBit()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %i", &iReturnValue, piBitValue);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetDIOGetBit()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetDIOGetBit()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOGetBit()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOGetBit()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetDIOGetByte(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned int uiPortNumber, 
	unsigned char *pucByteValue){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int iReturnValue;
    int sockfd;
    int n;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOGetByte()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOGetByte()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u",
	    ME4000_DIO_GET_BYTE_ID,
	    uiBoardNumber,
	    uiPortNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOGetByte()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOGetByte()", my_errno);
	return my_errno;
    }

    /* Catch the return value from the remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOGetByte()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOGetByte()", my_errno);
	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOGetByte()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOGetByte()", my_errno);
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetDIOGetByte()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetDIOGetByte()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %hhu", &iReturnValue, pucByteValue);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetDIOGetByte()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetDIOGetByte()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOGetByte()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOGetByte()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetDIOResetAll(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOResetAll()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOResetAll()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_DIO_RESET_ALL_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOResetAll()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOResetAll()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOResetAll()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOResetAll()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetDIOSetBit(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned int uiPortNumber, 
	unsigned int uiBitNumber, 
	int iBitValue){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOSetBit()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOSetBit()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %u %i", ME4000_DIO_SET_BIT_ID, uiBoardNumber, uiPortNumber, uiBitNumber, iBitValue);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOSetBit()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOSetBit()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOSetBit()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOSetBit()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetDIOSetByte(
	const char *IPAddress,
       	unsigned int uiBoardNumber,
       	unsigned int uiPortNumber,
       	unsigned char ucByteValue){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOSetByte()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOSetByte()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %hhu", ME4000_DIO_SET_BYTE_ID, uiBoardNumber, uiPortNumber, ucByteValue);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOSetByte()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOSetByte()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOSetByte()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOSetByte()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



/*=============================================================================
  Bit Pattern Functions
  ===========================================================================*/


int me4000NetDIOBPOpen(const char *IPAddress, unsigned int uiBoardNumber, int iConversionMode){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPOpen()", my_errno);
	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %i", ME4000_DIOBP_OPEN_ID, uiBoardNumber, iConversionMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPOpen()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPOpen()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetDIOBPClose(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPClose()", my_errno);
	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_DIOBP_CLOSE_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPClose()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPClose()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetDIOBPAppendNewValues(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned short *pusBuffer, 
	unsigned long ulNumberOfValuesToAppend, 
	int iExecutionMode,
	unsigned long *pulNumberOfValuesAppended){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int n;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPAppenNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPAppenNewValues()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %lu %i",
	    ME4000_DIOBP_APPEND_NEW_VALUES_ID,
	    uiBoardNumber,
	    ulNumberOfValuesToAppend,
	    iExecutionMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPAppenNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPAppenNewValues()", my_errno);
	return my_errno;
    }

    if(ulNumberOfValuesToAppend){
	/* Send the data to the remote host */
	if(writen(sockfd, pusBuffer, sizeof(*pusBuffer) * ulNumberOfValuesToAppend) < 0){
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetDIOBPAppenNewValues()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetDIOBPAppenNewValues()", my_errno);
	    return my_errno;
	}
    }

    /* Catch return values from remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPAppenNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPAppenNewValues()", my_errno);
	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPAppenNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPAppenNewValues()", my_errno);
	return my_errno;
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
     n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetDIOBPAppenNewValues()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetDIOBPAppenNewValues()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %lu", &iReturnValue, pulNumberOfValuesAppended);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetDIOBPAppenNewValues()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetDIOBPAppenNewValues()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPAppenNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPAppenNewValues()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetDIOBPConfig(
	const char *IPAddress,
       	unsigned int uiBoardNumber,
       	unsigned long ulTicks,
       	int iTriggerMode,
	int iExtTriggerEdge){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPConfig()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %lu %i %i",
	    ME4000_DIOBP_CONFIG_ID,
	    uiBoardNumber,
	    ulTicks,
	    iTriggerMode,
	    iExtTriggerEdge);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPConfig()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPConfig()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetDIOBPContinuous(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned short *pusBuffer, 
	unsigned long ulDataCount, 
	unsigned long ulTimeOutSeconds,
	unsigned long *pulNumberOfValuesWritten){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int n;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPContinuous()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %lu %lu",
	    ME4000_DIOBP_CONTINUOUS_ID,
	    uiBoardNumber,
	    ulDataCount,
	    ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPContinuous()", my_errno);
	return my_errno;
    }

    if(ulDataCount){
	/* Send the data to the remote host */
	if(writen(sockfd, pusBuffer, sizeof(unsigned short) * ulDataCount) < 0){
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetDIOBPContinuous()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetDIOBPContinuous()", my_errno);
	    return my_errno;
	}
    }

    /* Catch return values from remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPContinuous()", my_errno);
	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPContinuous()", my_errno);
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetDIOBPContinuous()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetDIOBPContinuous()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %lu", &iReturnValue, pulNumberOfValuesWritten);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetDIOBPContinuous()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetDIOBPContinuous()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPContinuous()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetDIOBPGetStatus(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	int iWaitIdle,
	int *piStatus){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int n;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPGetStatus()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %i",
	    ME4000_DIOBP_GET_STATUS_ID,
	    uiBoardNumber,
	    iWaitIdle);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPGetStatus()", my_errno);
	return my_errno;
    }

    /* Catch return values from remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPGetStatus()", my_errno);
	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPGetStatus()", my_errno);
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetDIOBPGetStatus()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetDIOBPGetStatus()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %i", &iReturnValue, piStatus);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetDIOBPGetStatus()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetDIOBPGetStatus()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPGetStatus()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetDIOBPPortConfig(
	const char *IPAddress,
       	unsigned int uiBoardNumber,
	unsigned int uiPortNumber,
	int iOutputMode){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPPortConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPPortConfig()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %i",
	    ME4000_DIOBP_PORT_CONFIG_ID,
	    uiBoardNumber,
	    uiPortNumber,
	    iOutputMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPPortConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPPortConfig()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPPortConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPPortConfig()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetDIOBPReset(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPReset()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_DIOBP_RESET_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPReset()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPReset()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetDIOBPStop(
	const char *IPAddress,
       	unsigned int uiBoardNumber,
	int iStopMode){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPStop()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %i",
	    ME4000_DIOBP_STOP_ID,
	    uiBoardNumber,
	    iStopMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPStop()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPStop()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetDIOBPWraparound(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned short *pusBuffer, 
	unsigned long ulDataCount, 
	unsigned long ulTimeOutSeconds){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPWraparound()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPWraparound()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %lu %lu",
	    ME4000_DIOBP_WRAPAROUND_ID, uiBoardNumber, ulDataCount, ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPWraparound()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPWraparound()", my_errno);
	return my_errno;
    }

    if(ulDataCount){
	/* Send the data to the remote host */
	if(writen(sockfd, pusBuffer, sizeof(*pusBuffer) * ulDataCount) < 0){
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetDIOBPWraparound()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetDIOBPWraparound()", my_errno);
	    return my_errno;
	}
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetDIOBPWraparound()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetDIOBPWraparound()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



/*=============================================================================
  Counter functions
  ===========================================================================*/

int me4000NetCntOpen(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntOpen()", my_errno);
	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_CNT_OPEN_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntOpen()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntOpen()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetCntClose(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntClose()", my_errno);
	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_CNT_CLOSE_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntClose()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntClose()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetCntPWMStart(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	int iPrescaler,
	int iDutyCycle){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntPWMStart()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntPWMStart()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %i %i",
	    ME4000_CNT_PWM_START_ID,
	    uiBoardNumber,
	    iPrescaler,
	    iDutyCycle);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntPWMStart()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntPWMStart()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntPWMStart()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntPWMStart()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetCntPWMStop(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntPWMStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntPWMStop()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_CNT_PWM_STOP_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntPWMStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntPWMStop()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntPWMStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntPWMStop()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetCntRead(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned int uiCounterNumber,
	unsigned short *pusValue){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int iReturnValue;
    int sockfd;
    int n;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntRead()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntRead()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %i", ME4000_CNT_READ_ID, uiBoardNumber, uiCounterNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	return storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntRead()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntRead()", my_errno);
	return my_errno;
    }

    /* Catch the return value from the remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntRead()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntRead()", my_errno);
	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntRead()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntRead()", my_errno);
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetCntRead()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetCntRead()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %hu", &iReturnValue, pusValue);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetCntRead()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetCntRead()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntRead()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntRead()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetCntWrite(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned int uiCounterNumber,
	int iMode,
	unsigned short usValue){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntWrite()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntWrite()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %i %hu",
	    ME4000_CNT_WRITE_ID,
	    uiBoardNumber,
	    uiCounterNumber,
	    iMode,
	    usValue);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntWrite()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntWrite()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetCntWrite()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetCntWrite()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



/*=============================================================================
  MultiSig Functions
  ===========================================================================*/

int me4000NetMultiSigOpen(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigOpen()", my_errno);
	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_MULTISIG_OPEN_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigOpen()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigOpen()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetMultiSigClose(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigClose()", my_errno);
	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_MULTISIG_CLOSE_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigClose()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigClose()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetMultiSigAddressLED(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned int uiBase, 
	int iLEDStatus){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAddressLED()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAddressLED()", my_errno);
	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %i",
	    ME4000_MULTISIG_ADDRESS_LED_ID,
	    uiBoardNumber,
	    uiBase,
	    iLEDStatus);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAddressLED()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAddressLED()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAddressLED()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAddressLED()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}


int me4000NetMultiSigReset(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigReset()", my_errno);
	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u",
	    ME4000_MULTISIG_RESET_ID,
	    uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigReset()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigReset()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetMultiSigSetGain(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned int uiBase, 
	int iChannelGroup, 
	int iGain){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigSetGain()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigSetGain()", my_errno);
	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %i %i",
	    ME4000_MULTISIG_SET_GAIN_ID,
	    uiBoardNumber,
	    uiBase,
	    iChannelGroup,
	    iGain);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigSetGain()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigSetGain()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigSetGain()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigSetGain()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}


/*=============================================================================
  MulitSig analog input functions
  ===========================================================================*/

int me4000NetMultiSigAIOpen(
	const char *IPAddress,
       	unsigned int uiBoardNumber,
       	int iAcqMode){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIOpen()", my_errno);
       	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %i",
	    ME4000_MULTISIG_AI_OPEN_ID,
	    uiBoardNumber,
	    iAcqMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIOpen()", my_errno);
       	return my_errno;
    }

    /* Get the answer */
    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIOpen()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}



int me4000NetMultiSigAIClose(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIClose()", my_errno);
	return my_errno;
    }

    /* Send request to remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_MULTISIG_AI_CLOSE_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIClose()", my_errno);
	return my_errno;
    }

    /* Get the answer */
    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIClose()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}


int me4000NetMultiSigAIConfig(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned int uiAIChannelNumber,
	unsigned char *pucMuxChanList, 
	unsigned int uiMuxChanListCount, 
	unsigned long ulChanTicks, 
	unsigned long ulScanTicksLow, 
	unsigned long ulScanTicksHigh, 
	int iAcqMode,
	int iExtTriggerMode, 
	int iExtTriggerEdge){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMulitSigAIConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMulitSigAIConfig()", my_errno);
	return my_errno;
    }

    /* Send request to remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %u %lu %lu %lu %i %i %i",
	    ME4000_MULTISIG_AI_CONFIG_ID,
	    uiBoardNumber,
	    uiAIChannelNumber,
	    uiMuxChanListCount,
	    ulChanTicks,
	    ulScanTicksLow,
	    ulScanTicksHigh,
	    iAcqMode,
	    iExtTriggerMode,
	    iExtTriggerEdge);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMulitSigAIConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMulitSigAIConfig()", my_errno);
	return my_errno;
    }

    /* Transfer the channel list */
    if(writen(sockfd, pucMuxChanList, sizeof(unsigned char) * uiMuxChanListCount) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMulitSigAIConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMulitSigAIConfig()", my_errno);
	return my_errno;
    }

    /* Get the answer */
    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMulitSigAIConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMulitSigAIConfig()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}


int me4000NetMultiSigAIContinuous(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned int uiRefreshFrequency, 
	unsigned long ulTimeOutSeconds){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIContinuous()", my_errno);
	return my_errno;
    }

    /* Send request to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %lu",
	    ME4000_MULTISIG_AI_CONTINUOUS_ID,
	    uiBoardNumber,
	    uiRefreshFrequency, 
	    ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIContinuous()", my_errno);
	return my_errno;
    }

    /* Get the answer */
    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIContinuous()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}


int me4000NetMultiSigAIDigitToSize(
	short sDigit, 
	int iGain, 
	int iModuleType,
	double dIMeasured,
	double *pdSize){
    int iReturnValue;

    iReturnValue = me4000MultiSigAIDigitToSize(
	    sDigit, 
	    iGain, 
	    iModuleType,
	    dIMeasured,
	    pdSize);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIDigitToSize()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIDigitToSize()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}



int me4000NetMultiSigAIExtractValues(
	unsigned int uiChannelNumber, 
	short *psAIBuffer, 
	unsigned long ulAIDataCount, 
	unsigned char *pucChanList, 
	unsigned int uiChanListCount, 
	short *psChanBuffer, 
	unsigned long ulChanBufferSizeValues, 
	unsigned long *pulChanDataCount){
    int iReturnValue;

    iReturnValue = me4000AIExtractValues(
	    uiChannelNumber, 
	    psAIBuffer, 
	    ulAIDataCount, 
	    pucChanList, 
	    uiChanListCount, 
	    psChanBuffer, 
	    ulChanBufferSizeValues, 
	    pulChanDataCount);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIExtractValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIExtractValues()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}



int me4000NetMultiSigAIGetNewValues(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	short *psBuffer, 
	unsigned long ulNumberOfValuesToRead,
	int iExecutionMode,
	unsigned long *pulNumberOfValuesRead){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;
    int n;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetNewValues()", my_errno);
	return my_errno;
    }

    /* Send the request */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %lu %i",
	    ME4000_MULTISIG_AI_GET_NEW_VALUES_ID,
	    uiBoardNumber,
	    ulNumberOfValuesToRead,
	    iExecutionMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetNewValues()", my_errno);
	return my_errno;
    }

    /* Get the answer */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetNewValues()", my_errno);
	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetNewValues()", my_errno);
	return my_errno;
    }

    msg[n] = '\0'; // Null terminate the string
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetMultiSigAIGetNewValues()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetMultiSigAIGetNewValues()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %lu", &iReturnValue, pulNumberOfValuesRead);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetMultiSigAIGetNewValues()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetMultiSigAIGetNewValues()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetNewValues()", my_errno);
       	return my_errno;
    }

    /* Catch the data from the remote host */
    if(*pulNumberOfValuesRead){
	n = readn(sockfd, psBuffer, sizeof(short) * (*pulNumberOfValuesRead));
	if(n < 0){
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetMultiSigAIGetNewValues()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetMultiSigAIGetNewValues()", my_errno);
	    return my_errno;
	}
	else if(n == 0){ // Connection closed by remote host
	    me4000NetDisconnect(IPAddress);
	    my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetMultiSigAIGetNewValues()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetMultiSigAIGetNewValues()", my_errno);
	    return my_errno;
	}
    }

    return ME4000_NO_ERROR;
}


int me4000NetMultiSigAIGetStatus(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	int iWaitIdle,
	int *piStatus){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int n;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetStatus()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %i",
	    ME4000_MULTISIG_AI_GET_STATUS_ID,
	    uiBoardNumber,
	    iWaitIdle);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetStatus()", my_errno);
       	return my_errno;
    }

    /* Catch return values from remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetStatus()", my_errno);
       	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetStatus()", my_errno);
	return my_errno;
    }

    msg[n] = '\0'; // Null terminate the string
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetMultiSigAIGetStatus()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetMultiSigAIGetStatus()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %i", &iReturnValue, piStatus);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetMultiSigAIGetStatus()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetMultiSigAIGetStatus()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetStatus()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}


int me4000NetMultiSigAIReset(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIReset()", my_errno);
	return my_errno;
    }

    /* Send the request */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_AI_RESET_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIReset()", my_errno);
	return my_errno;
    }

    /* Get the reply */
    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIReset()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}


int me4000NetMultiSigAIScan(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned int uiNumberOfMuxLists,
	short *psBuffer, 
	unsigned long ulBufferSizeValues,
	unsigned long ulTimeOutSeconds){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;
    int n;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIScan()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIScan()", my_errno);
	return my_errno;
    }

    /* Send the reply */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %lu %lu",
	    ME4000_MULTISIG_AI_SCAN_ID,
	    uiBoardNumber,
	    uiNumberOfMuxLists,
	    ulBufferSizeValues,
	    ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIScan()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIScan()", my_errno);
	return my_errno;
    }

    /* Get the error code */
    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIScan()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIScan()", my_errno);
       	return my_errno;
    }

    /* Catch the data from the remote host */
    if(ulBufferSizeValues){
	n = readn(sockfd, psBuffer, sizeof(short) * ulBufferSizeValues);
	if(n < 0){
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetMultiSigAIScan()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetMultiSigAIScan()", my_errno);
	    return my_errno;
	}
	else if(n == 0){ // Connection closed by remote host
	    me4000NetDisconnect(IPAddress);
	    my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetMultiSigAIScan()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetMultiSigAIScan()", my_errno);
	    return my_errno;
	}
    }

    return ME4000_NO_ERROR;
}



int me4000NetMultiSigAISingle(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned int uiAIChannelNumber,
	unsigned int uiMuxChannelNumber,
	int iGain, 
	int iTriggerMode,
	int iExtTriggerEdge, 
	unsigned long ulTimeOutSeconds, 
	short *psDigitalValue){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int n;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetSingle()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %u %i %i %i %lu",
	    ME4000_MULTISIG_AI_SINGLE_ID,
	    uiBoardNumber,
	    uiAIChannelNumber,
	    uiMuxChannelNumber,
	    iGain,
	    iTriggerMode,
	    iExtTriggerEdge,
	    ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetSingle()", my_errno);
       	return my_errno;
    }

    /* Catch return values from remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetSingle()", my_errno);
	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetSingle()", my_errno);
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetMultiSigAIGetSingle()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetMultiSigAIGetSingle()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %hi", &iReturnValue, psDigitalValue);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetMultiSigAIGetSingle()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetMultiSigAIGetSingle()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIGetSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIGetSingle()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}


int me4000NetMultiSigAIStop(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIStop()", my_errno);
	return my_errno;
    }

    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_MULTISIG_AI_STOP_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIStop()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAIStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAIStop()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}



/*=============================================================================
  MultiSig analog output functions
  ===========================================================================*/

int me4000NetMultiSigAOOpen(
	const char *IPAddress,
       	unsigned int uiBoardNumber,
       	int iConversionMode){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
       	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOOpen()", my_errno);
       	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %i",
	    ME4000_MULTISIG_AO_OPEN_ID,
	    uiBoardNumber,
	    iConversionMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
       	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOOpen()", my_errno);
       	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOOpen()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOOpen()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}



int me4000NetMultiSigAOClose(
	const char *IPAddress,
       	unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOClose()", my_errno);
       	return my_errno;
    }

    /* Try to open device on the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u",
	    ME4000_MULTISIG_AO_CLOSE_ID,
	    uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOClose()", my_errno);
       	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOClose()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOClose()", my_errno);
       	return my_errno;
    }

    return iReturnValue;
}



int me4000NetMultiSigAOAppendNewValues(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned short *pusBuffer, 
	unsigned long ulNumberOfValuesToAppend, 
	int iExecutionMode,
	unsigned long *pulNumberOfValuesAppended){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int n;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOAppendNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOAppendNewValues()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %lu %i",
	    ME4000_MULTISIG_AO_APPEND_NEW_VALUES_ID,
	    uiBoardNumber,
	    ulNumberOfValuesToAppend,
	    iExecutionMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOAppendNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOAppendNewValues()", my_errno);
       	return my_errno;
    }

    if(ulNumberOfValuesToAppend){
	/* Send the data to the remote host */
	if(writen(sockfd, pusBuffer, sizeof(*pusBuffer) * ulNumberOfValuesToAppend) < 0){
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetMultiSigAOAppendNewValues()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetMultiSigAOAppendNewValues()", my_errno);
	    return my_errno;
	}
    }

    /* Catch return values from remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOAppendNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOAppendNewValues()", my_errno);
       	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOAppendNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOAppendNewValues()", my_errno);
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetMultiSigAOAppendNewValues()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetMultiSigAOAppendNewValues()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %lu", &iReturnValue, pulNumberOfValuesAppended);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetMultiSigAOAppendNewValues()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetMultiSigAOAppendNewValues()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOAppendNewValues()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOAppendNewValues()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetMultiSigAOConfig(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned char *pucDemuxChanList, 
	unsigned int uiDemuxChanListCount,
	unsigned long ulTicks, 
	int iTriggerMode,
	int iExtTriggerEdge){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOConfig()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %lu %i %i",
	    ME4000_MULTISIG_AO_CONFIG_ID,
	    uiBoardNumber,
	    uiDemuxChanListCount,
	    ulTicks,
	    iTriggerMode,
	    iExtTriggerEdge);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOConfig()", my_errno);
       	return my_errno;
    }

    if(writen(sockfd, pucDemuxChanList, sizeof(unsigned char) * uiDemuxChanListCount) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOConfig()", my_errno);
       	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOConfig()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOConfig()", my_errno);
       	return my_errno;
    }

    return 0;
}



int me4000NetMultiSigAOContinuous(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned short *pusBuffer, 
	unsigned long ulDataCount, 
	unsigned long ulTimeOutSeconds,
	unsigned long *pulNumberOfValuesWritten){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int n;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOContinuous()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %lu %lu",
	    ME4000_MULTISIG_AO_CONTINUOUS_ID,
	    uiBoardNumber,
	    ulDataCount,
	    ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOContinuous()", my_errno);
       	return my_errno;
    }

    if(ulDataCount){
	/* Send the data to the remote host */
	if(writen(sockfd, pusBuffer, sizeof(unsigned short) * ulDataCount) < 0){
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetMultiSigAOContinuous()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetMultiSigAOContinuous()", my_errno);
	    return my_errno;
	}
    }

    /* Catch return values from remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOContinuous()", my_errno);
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOContinuous()", my_errno);
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetMultiSigAOContinuous()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetMultiSigAOContinuous()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %lu", &iReturnValue, pulNumberOfValuesWritten);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetMultiSigAOContinuous()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetMultiSigAOContinuous()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOContinuous()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOContinuous()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetMultiSigAOGetStatus(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	int iWaitIdle,
	int *piStatus){
    char msg[ME4000_MSG_MAXBUF + 1] = {0};
    int sockfd;
    int n;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOGetStatus()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %i",
	    ME4000_MULTISIG_AO_GET_STATUS_ID,
	    uiBoardNumber,
	    iWaitIdle);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOGetStatus()", my_errno);
	return my_errno;
    }

    /* Catch return values from remote host */
    n = readn(sockfd, msg, ME4000_MSG_MAXBUF);
    if(n < 0){
	return storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOGetStatus()", my_errno);
       	return my_errno;
    }
    else if(n == 0){ // Connection closed by remote host
	me4000NetDisconnect(IPAddress);
	my_errno = LIB_NET_ERROR_NO_CONNECTION_CLOSED;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOGetStatus()", my_errno);
	return my_errno;
    }

    /* Null terminate the string */
    msg[n] = '\0';
    n = sscanf(msg, "%i", &iReturnValue);
    if(n == 1){
	if(iReturnValue != ME4000_NO_ERROR){
	    storeServerError(msg);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetMultiSigAOGetStatus()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetMultiSigAOGetStatus()", my_errno);
	    return my_errno;
	}
	else{
	    n = sscanf(msg, "%i %i", &iReturnValue, piStatus);
	    if(n != 2){
		my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
		if(errorDefaultProcFlag)
		    errorDefaultProc("me4000NetMultiSigAOGetStatus()", my_errno);
		else if(errorUserProcPtr)
		    errorUserProcPtr("me4000NetMultiSigAOGetStatus()", my_errno);
		return my_errno;
	    }

	}
    }
    else{
	my_errno = LIB_NET_ERROR_NO_INVALID_ANSWER;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOGetStatus()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOGetStatus()", my_errno);
       	return my_errno;
    }

    return ME4000_NO_ERROR;
}



int me4000NetMultiSigAOReset(
	const char *IPAddress,
       	unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOReset()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_MULTISIG_AO_RESET_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOReset()", my_errno);
       	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOReset()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOReset()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetMultiSigAOSingle(
	const char *IPAddress,
	unsigned int uiBoardNumber, 
	unsigned int uiDemuxChannelNumber, 
	int iTriggerMode,
	int iExtTriggerEdge,
	unsigned long ulTimeOutSeconds,
	unsigned short usValue){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOSingle()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %u %i %i %lu %hu",
	    ME4000_MULTISIG_AO_SINGLE_ID,
	    uiBoardNumber,
	    uiDemuxChannelNumber,
	    iTriggerMode,
	    iExtTriggerEdge,
	    ulTimeOutSeconds,
	    usValue);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOSingle()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOSingle()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOSingle()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetMultiSigAOStart(const char *IPAddress, unsigned int uiBoardNumber){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOStart()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOStart()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u", ME4000_MULTISIG_AO_START_ID, uiBoardNumber);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOStart()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOStart()", my_errno);
	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOStart()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOStart()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetMultiSigAOStop(
	const char *IPAddress,
       	unsigned int uiBoardNumber,
	int iStopMode){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOStop()", my_errno);
       	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %i",
	    ME4000_MULTISIG_AO_STOP_ID,
	    uiBoardNumber,
	    iStopMode);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOStop()", my_errno);
       	return my_errno;
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOStop()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOStop()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetMultiSigAOVoltToDigit(double dVolt, unsigned short *pusDigit){
    int iReturnValue;

    iReturnValue = me4000MultiSigAOVoltToDigit(dVolt, pusDigit);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOVoltToDigit()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOVoltToDigit()", my_errno);
	return my_errno;
    }

    return iReturnValue;
}



int me4000NetMultiSigAOWraparound(
	const char *IPAddress,
	unsigned int uiBoardNumber,
	unsigned short *pusBuffer, 
	unsigned long ulDataCount, 
	unsigned long ulTimeOutSeconds){
    char msg[ME4000_MSG_MAXBUF] = {0};
    int sockfd;
    int iReturnValue;

    /* Look up socket file descriptor */
    sockfd = connection_list_get_sockfd(&connection_list_head, IPAddress);
    if(sockfd < 0){
       	my_errno = LIB_NET_ERROR_NO_NO_CONNECTION;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOWraparound()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOWraparound()", my_errno);
	return my_errno;
    }

    /* Send the command to the remote host */
    snprintf(msg, ME4000_MSG_MAXBUF, "%i %u %lu %lu",
	    ME4000_MULTISIG_AO_WRAPAROUND_ID,
	    uiBoardNumber,
	    ulDataCount,
	    ulTimeOutSeconds);
    if(writen(sockfd, msg, ME4000_MSG_MAXBUF) < 0){
	storeSystemError(errno);
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOWraparound()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOWraparound()", my_errno);
	return my_errno;
    }

    if(ulDataCount){
	/* Send the data to the remote host */
	if(writen(sockfd, pusBuffer, sizeof(*pusBuffer) * ulDataCount) < 0){
	    storeSystemError(errno);
	    if(errorDefaultProcFlag)
		errorDefaultProc("me4000NetMultiSigAOWraparound()", my_errno);
	    else if(errorUserProcPtr)
		errorUserProcPtr("me4000NetMultiSigAOWraparound()", my_errno);
	    return my_errno;
	}
    }

    iReturnValue = catch_return_value(IPAddress);
    if(iReturnValue){
	my_errno = iReturnValue;
	if(errorDefaultProcFlag)
	    errorDefaultProc("me4000NetMultiSigAOWraparound()", my_errno);
	else if(errorUserProcPtr)
	    errorUserProcPtr("me4000NetMultiSigAOWraparound()", my_errno);
	return my_errno;
    }

    return ME4000_NO_ERROR;
}
