#ifndef LIBME4000NET_H
#define LIBME4000NET_H


#include "libme4000.h"


/*===========================================================================
  General functions header id
  =========================================================================*/

#define ME4000_GET_BOARD_VERSION_ID		10
#define ME4000_GET_SERVER_VERSION_ID		11
#define ME4000_GET_DLL_VERSION_ID		12
#define ME4000_GET_DRIVER_VERSION_ID		13
#define ME4000_GET_SERIAL_NUMBER_ID		14


/*===========================================================================
  Analog Input functions header id
  =========================================================================*/

#define ME4000_AI_OPEN_ID			20
#define ME4000_AI_CLOSE_ID			21
#define ME4000_AI_CONFIG_ID			22
#define ME4000_AI_CONTINUOUS_ID			23
#define ME4000_AI_GET_NEW_VALUES_ID		24
#define ME4000_AI_GET_STATUS_ID			25
#define ME4000_AI_RESET_ID			26
#define ME4000_AI_SCAN_ID			27
#define ME4000_AI_SINGLE_ID			28
#define ME4000_AI_STOP_ID			30


/*===========================================================================
  Analog Output functions header id
  =========================================================================*/

#define ME4000_AO_OPEN_ID			40
#define ME4000_AO_CLOSE_ID			41
#define ME4000_AO_APPEND_NEW_VALUES_ID		42
#define ME4000_AO_CONFIG_ID			43
#define ME4000_AO_CONTINUOUS_ID			44
#define ME4000_AO_GET_STATUS_ID			45
#define ME4000_AO_RESET_ID			46
#define ME4000_AO_SINGLE_SIMULTANEOUS_ID	47
#define ME4000_AO_SINGLE_ID			48
#define ME4000_AO_START_ID			49
#define ME4000_AO_START_SYNCHRONOUS_ID		50
#define ME4000_AO_STOP_ID			51
#define ME4000_AO_WAVE_GEN_ID			52
#define ME4000_AO_WRAPAROUND_ID			53


/*===========================================================================
  Digital I/O Bit Pattern Functions header id
  =========================================================================*/

#define ME4000_DIOBP_OPEN_ID			60
#define ME4000_DIOBP_CLOSE_ID			61
#define ME4000_DIOBP_APPEND_NEW_VALUES_ID	62
#define ME4000_DIOBP_CONFIG_ID			63
#define ME4000_DIOBP_CONTINUOUS_ID		64
#define ME4000_DIOBP_GET_STATUS_ID		65
#define ME4000_DIOBP_PORT_CONFIG_ID		66
#define ME4000_DIOBP_RESET_ID			67
#define ME4000_DIOBP_STOP_ID			69
#define ME4000_DIOBP_WRAPAROUND_ID		70


/*===========================================================================
  Digital I/O functions header id
  =========================================================================*/

#define ME4000_DIO_OPEN_ID			80
#define ME4000_DIO_CLOSE_ID			81
#define ME4000_DIO_CONFIG_ID			82
#define ME4000_DIO_GET_BIT_ID			83
#define ME4000_DIO_GET_BYTE_ID			84
#define ME4000_DIO_RESET_ALL_ID			85
#define ME4000_DIO_SET_BIT_ID			86
#define ME4000_DIO_SET_BYTE_ID			87


/*===========================================================================
  Counter functions header id
  =========================================================================*/

#define ME4000_CNT_OPEN_ID			100
#define ME4000_CNT_CLOSE_ID			101
#define ME4000_CNT_PWM_START_ID			102
#define ME4000_CNT_PWM_STOP_ID			103
#define ME4000_CNT_READ_ID			104
#define ME4000_CNT_WRITE_ID			105


/*===========================================================================
  MultiSig functions header id
  =========================================================================*/

#define ME4000_MULTISIG_OPEN_ID			120
#define ME4000_MULTISIG_CLOSE_ID		121
#define ME4000_MULTISIG_ADDRESS_LED_ID		122
#define ME4000_MULTISIG_RESET_ID		123
#define ME4000_MULTISIG_SET_GAIN_ID		124


/*===========================================================================
  MultiSig AI functions header id
  =========================================================================*/

#define ME4000_MULTISIG_AI_OPEN_ID		140
#define ME4000_MULTISIG_AI_CLOSE_ID		141
#define ME4000_MULTISIG_AI_CONFIG_ID		142
#define ME4000_MULTISIG_AI_CONTINUOUS_ID	143
#define ME4000_MULTISIG_AI_GET_NEW_VALUES_ID	144
#define ME4000_MULTISIG_AI_GET_STATUS_ID	145
#define ME4000_MULTISIG_AI_RESET_ID		146
#define ME4000_MULTISIG_AI_SCAN_ID		147
#define ME4000_MULTISIG_AI_SINGLE_ID		148
#define ME4000_MULTISIG_AI_STOP_ID		149


/*===========================================================================
  MultiSig AI functions header id
  =========================================================================*/

#define ME4000_MULTISIG_AO_OPEN_ID		160
#define ME4000_MULTISIG_AO_CLOSE_ID		161
#define ME4000_MULTISIG_AO_APPEND_NEW_VALUES_ID	162
#define ME4000_MULTISIG_AO_CONFIG_ID		163
#define ME4000_MULTISIG_AO_CONTINUOUS_ID	164
#define ME4000_MULTISIG_AO_GET_STATUS_ID	165
#define ME4000_MULTISIG_AO_RESET_ID		166
#define ME4000_MULTISIG_AO_SINGLE_ID		167
#define ME4000_MULTISIG_AO_START_ID		168
#define ME4000_MULTISIG_AO_STOP_ID		169
#define ME4000_MULTISIG_AO_WRAPAROUND_ID	170


/*===========================================================================
  Server Properties
  =========================================================================*/

#define ME4000_SERVER_PORT		65000
#define ME4000_LISTEN_QUEUE		5


/*===========================================================================
  Length of commands and replys
  =========================================================================*/

#define ME4000_MSG_MAXBUF		256
#define ME4000_MSG_MAXBUF_STR		"256" // Needed for sscanf when specifying lengt of error messages


#ifdef __cplusplus
extern "C" {
#endif

    /*===========================================================================
      TCP/IP Functions
      =========================================================================*/

    int me4000NetConnect(const char *IPAddress);

    int me4000NetDisconnect(const char *IPAddress);

    int me4000NetLookup(const char *IPAddress, char ***pcInfo, int *piEntryCount);

    /*===========================================================================
      Error Functions
      =========================================================================*/

    int me4000NetErrorGetMessage(
	    int iErrorCode, 
	    char *pcBuffer, 
	    unsigned int uiBufferSize);

    int me4000NetErrorGetLastMessage(
	    char *pcBuffer,
	    unsigned int uiBufferSize);

    int me4000NetErrorSetDefaultProc(int iDefaultProcStatus);

    int me4000NetErrorSetUserProc(ME4000_P_ERROR_PROC pErrorProc);


    /*===========================================================================
      General Functions
      =========================================================================*/

    int me4000NetFrequencyToTicks(
	    double dRequiredFreq, 
	    unsigned long *pulTicksLowPart,
	    unsigned long *pulTicksHighPart, 
	    double *pdAchievedFreq);

    int me4000NetTimeToTicks(
	    double dRequiredTime, 
	    unsigned long *pulTicksLowPart, 
	    unsigned long *pulTicksHighPart, 
	    double *pdAchievedTime);

    int me4000NetGetBoardVersion(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned short *pusVersion);

    int me4000NetGetDLLVersion(const char *IPAddress, unsigned long *pulVersion);

    int me4000NetGetNetDLLVersion(unsigned long *pulVersion);

    int me4000NetGetDriverVersion(const char *IPAddress, unsigned long *pulVersion);

    int me4000NetGetSerialNumber(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned long *pulSerialNumber);

    int me4000NetGetBoardCount(void);


    /*===========================================================================
      Analog input functions
      =========================================================================*/

    int me4000NetAIOpen(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    int iAcqMode);

    int me4000NetAIClose(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetAIConfig(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned char *pucChanList, 
	    unsigned int uiChanListCount, 
	    int iSDMode, 
	    int iSimultaneous,
	    unsigned long ulChanTicks, 
	    unsigned long ulScanTicksLow, 
	    unsigned long ulScanTicksHigh, 
	    int iAcqMode,
	    int iExtTriggerMode, 
	    int iExtTriggerEdge);

    int me4000NetAIContinuous(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int uiRefreshFrequency,
	    unsigned long ulTimeOutSeconds);

    int me4000NetAIDigitToVolt(
	    short sDigit, 
	    int iRange, 
	    double *pdVolt);

    int me4000NetAIDigitToVoltAdjusted(
	    unsigned int uiBoardNumber,
	    short sDigit, 
	    int iRange, 
	    int iSDMode,
	    double *pdVolt);

    int me4000NetAIExtractValues(
	    unsigned int uiChannelNumber, 
	    short *psAIBuffer, 
	    unsigned long ulAIDataCount, 
	    unsigned char *pucChanList, 
	    unsigned int uiChanListCount, 
	    short *psChanBuffer, 
	    unsigned long ulChanBufferSizeValues, 
	    unsigned long *pulChanDataCount);

    int me4000NetAIGetNewValues(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    short *psBuffer, 
	    unsigned long ulNumberOfValuesToRead,
	    int iExecutionMode,
	    unsigned long *pulNumberOfValuesRead);

    int me4000NetAIGetStatus(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    int iWaitIdle,
	    int *piStatus);

    int me4000NetAIMakeChannelListEntry(
	    unsigned int uiChannelNumber, 
	    int iRange, 
	    unsigned char *pucChanListEntry);

    int me4000NetAIReset(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetAIScan(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int uiNumberOfChanLists,
	    short *psBuffer, 
	    unsigned long ulBufferSizeValues,
	    unsigned long ulTimeOutSeconds);

    int me4000NetAISingle(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber,
	    int iRange, 
	    int iSDMode, 
	    int iTriggerMode,
	    int iExtTriggerEdge, 
	    unsigned long ulTimeOutSeconds, 
	    short *psDigitalValue);

    int me4000NetAIStop(const char *IPAddress, unsigned int uiBoardNumber);



    /*===========================================================================
      Analog output functions
      =========================================================================*/

    int me4000NetAOOpen(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber, 
	    int iConversionMode);

    int me4000NetAOClose(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int uiChannelNumber);

    int me4000NetAOAppendNewValues(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber, 
	    unsigned short *pusBuffer, 
	    unsigned long ulNumberOfValuesToAppend, 
	    int iExecutionMode,
	    unsigned long *pulNumberOfValuesAppended);

    int me4000NetAOConfig(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber,
	    unsigned long ulTicks, 
	    int iTriggerMode,
	    int iExtTriggerEdge);

    int me4000NetAOContinuous(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber,
	    unsigned short *pusBuffer, 
	    unsigned long ulDataCount, 
	    unsigned long ulTimeOutSeconds,
	    unsigned long *pulNumberOfValuesWritten);

    int me4000NetAOGetStatus(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber,
	    int iWaitIdle,
	    int *piStatus);

    int me4000NetAOReset(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int uiChannelNumber);

    int me4000NetAOSingle(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber, 
	    int iTriggerMode,
	    int iExtTriggerEdge,
	    unsigned long ulTimeOutSeconds,
	    unsigned short usValue);

    int me4000NetAOSingleSimultaneous(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int *puiChannelNumber,
	    unsigned long ulCount,
	    int iTriggerMode,
	    int *piExtTriggerEnable,
	    int *piExtTriggerEdge,
	    unsigned long ulTimeOutSeconds,
	    unsigned short *pusValue);

    int me4000NetAOStart(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int uiChannelNumber);

    int me4000NetAOStartSynchronous(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int *puiChannelNumber, 
	    unsigned long ulCount, 
	    int iTriggerMode, 
	    int *piExtTriggerEnable,
	    int *piExtTriggerEdge,
	    unsigned long ulTimeOutSeconds);

    int me4000NetAOStop(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber, 
	    int iStopMode);

    int me4000NetAOVoltToDigit(double dVolt, unsigned short *pusDigit);

    int me4000NetAOWaveGen(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber, 
	    int iShape, 
	    double dAmplitude, 
	    double dOffset, 
	    double dFrequency);

    int me4000NetAOWraparound(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiChannelNumber, 
	    unsigned short *pusBuffer, 
	    unsigned long ulDataCount, 
	    unsigned long ulTimeOutSeconds);


    /*===========================================================================
      Digital I/O Functions
      =========================================================================*/

    int me4000NetDIOOpen(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetDIOClose(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetDIOConfig(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiPortNumber, 
	    int iPortDirection);

    int me4000NetDIOGetBit(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiPortNumber, 
	    unsigned int uiBitNumber, 
	    int *piBitValue);

    int me4000NetDIOGetByte(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiPortNumber, 
	    unsigned char *pucByteValue);

    int me4000NetDIOResetAll(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetDIOSetBit(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiPortNumber, 
	    unsigned int uiBitNumber, 
	    int iBitValue);

    int me4000NetDIOSetByte(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiPortNumber, 
	    unsigned char ucByteValue);


    /*=============================================================================
      Bit Pattern Functions
      ===========================================================================*/

    int me4000NetDIOBPOpen(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    int iConversionMode);

    int me4000NetDIOBPClose(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetDIOBPAppendNewValues(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned short *pusBuffer, 
	    unsigned long ulNumberOfValuesToAppend, 
	    int iExecutionMode,
	    unsigned long *pulNumberOfValuesAppended);

    int me4000NetDIOBPConfig(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned long ulTicks,
	    int iTriggerMode,
	    int iExtTriggerEdge);

    int me4000NetDIOBPContinuous(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned short *pusBuffer, 
	    unsigned long ulDataCount, 
	    unsigned long ulTimeOutSeconds,
	    unsigned long *pulNumberOfValuesWritten);

    int me4000NetDIOBPGetStatus(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    int iWaitIdle,
	    int *piStatus);

    int me4000NetDIOBPPortConfig(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int uiPortNumber,
	    int iOutputMode);

    int me4000NetDIOBPReset(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetDIOBPStart(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetDIOBPStop(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    int iStopMode);

    int me4000NetDIOBPWraparound(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned short *pusBuffer, 
	    unsigned long ulDataCount, 
	    unsigned long ulTimeOutSeconds);


    /*=============================================================================
      Counter functions
      ===========================================================================*/

    int me4000NetCntOpen(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetCntClose(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetCntPWMStart(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    int iPrescaler,
	    int iDutyCycle);

    int me4000NetCntPWMStop(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetCntRead(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int uiCounterNumber,
	    unsigned short *pusValue);

    int me4000NetCntWrite(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int uiCounterNumber,
	    int iMode,
	    unsigned short usValue);


    /*===========================================================================
      MultiSig Functions
      =========================================================================*/

    int me4000NetMultiSigOpen(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetMultiSigClose(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetMultiSigAddressLED(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiBase, 
	    int iLEDStatus);

    int me4000NetMultiSigReset(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetMultiSigSetGain(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned int uiBase, 
	    int iChannelGroup, 
	    int iGain);


    /*===========================================================================
      MultiSig AI Functions
      =========================================================================*/

    int me4000NetMultiSigAIOpen(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    int iAcqMode);

    int me4000NetMultiSigAIClose(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetMultiSigAIConfig(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int uiAIChannelNumber,
	    unsigned char *pucMuxChanList, 
	    unsigned int uiMuxChanListCount, 
	    unsigned long ulChanTicks, 
	    unsigned long ulScanTicksLow, 
	    unsigned long ulScanTicksHigh, 
	    int iAcqMode,
	    int iExtTriggerMode, 
	    int iExtTriggerEdge);

    int me4000NetMultiSigAIContinuous(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int uiRefreshFrequency,
	    unsigned long ulTimeOutSeconds);

    int me4000NetMultiSigAIDigitToSize(
	    short sDigit, 
	    int iGain, 
	    int iModuleType,
	    double dIMeasured,
	    double *pdSize);

    int me4000NetMultiSigAIExtractValues(
	    unsigned int uiMuxChannelNumber, 
	    short *psAIBuffer, 
	    unsigned long ulAIDataCount, 
	    unsigned char *pucMuxChanList, 
	    unsigned int uiMuxChanListCount, 
	    short *psChanBuffer, 
	    unsigned long ulChanBufferSizeValues, 
	    unsigned long *pulChanDataCount);

    int me4000NetMultiSigAIGetNewValues(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    short *psBuffer, 
	    unsigned long ulNumberOfValuesToRead,
	    int iExecutionMode,
	    unsigned long *pulNumberOfValuesRead);

    int me4000NetMultiSigAIGetStatus(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    int iWaitIdle,
	    int *piStatus);

    int me4000NetMultiSigAIReset(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetMultiSigAIScan(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int uiNumberOfMuxLists,
	    short *psBuffer, 
	    unsigned long ulBufferSizeValues,
	    unsigned long ulTimeOutSeconds);

    int me4000NetMultiSigAISingle(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int uiAIChannelNumber,
	    unsigned int uiMuxChannelNumber,
	    int iGain,
	    int iTriggerMode,
	    int iExtTriggerEdge,
	    unsigned long ulTimeOutSeconds,
	    short *psDigitalValue);

    int me4000NetMultiSigAIStop(const char *IPAddress, unsigned int uiBoardNumber);


    /*===========================================================================
      MultiSig AO functions
      =========================================================================*/

    int me4000NetMultiSigAOOpen(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    int iConversionMode);
    int me4000NetMultiSigAOClose(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetMultiSigAOAppendNewValues(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned short *pusBuffer, 
	    unsigned long ulNumberOfValuesToAppend, 
	    int iExecutionMode,
	    unsigned long *pulNumberOfValuesAppended);

    int me4000NetMultiSigAOConfig(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    unsigned char *pucDemuxChanList, 
	    unsigned int uiDemuxChanListCount,
	    unsigned long ulTicks, 
	    int iTriggerMode,
	    int iExtTriggerEdge);

    int me4000NetMultiSigAOContinuous(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned short *pusBuffer, 
	    unsigned long ulDataCount, 
	    unsigned long ulTimeOutSeconds,
	    unsigned long *pulNumberOfValuesWritten);

    int me4000NetMultiSigAOGetStatus(
	    const char *IPAddress,
	    unsigned int uiBoardNumber, 
	    int iWaitIdle, 
	    int *piStatus);

    int me4000NetMultiSigAOReset(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetMultiSigAOSingle(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned int uiDemuxChannelNumber,
	    int iTriggerMode,
	    int iExtTriggerEdge,
	    unsigned long ulTimeOutSeconds,
	    unsigned short usValue);

    int me4000NetMultiSigAOStart(const char *IPAddress, unsigned int uiBoardNumber);

    int me4000NetMultiSigAOStop(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    int iStopMode);

    int me4000NetMultiSigAOVoltToDigit(double dVolt, unsigned short *pusDigit);

    int me4000NetMultiSigAOWraparound(
	    const char *IPAddress,
	    unsigned int uiBoardNumber,
	    unsigned short *pusBuffer, 
	    unsigned long ulDataCount, 
	    unsigned long ulTimeOutSeconds);



#ifdef __cplusplus
}
#endif

#endif
