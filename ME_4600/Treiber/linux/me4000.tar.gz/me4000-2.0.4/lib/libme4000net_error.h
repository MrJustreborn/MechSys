#ifndef LIBME4000_NET_ERROR_H
#define LIBME4000_NET_ERROR_H

#define LIB_NET_ERROR_NO_MIN				0x40000000
#define LIB_NET_ERROR_NO_MAX				(LIB_NET_ERROR_NO_MIN + 8)

#define LIB_NET_ERROR_STR_UNSPECIFIED			"Unspecified error occured"
#define LIB_NET_ERROR_NO_UNSPECIFIED			(LIB_NET_ERROR_NO_MIN + 0)

#define LIB_NET_ERROR_STR_INVALID_ERROR_NO		"Invalid error number specified"
#define LIB_NET_ERROR_NO_INVALID_ERROR_NO		(LIB_NET_ERROR_NO_MIN + 1)

#define LIB_NET_ERROR_STR_ERROR_BUFFER_TO_LITTLE	"Buffer for error string to little"
#define LIB_NET_ERROR_NO_ERROR_BUFFER_TO_LITTLE		(LIB_NET_ERROR_NO_MIN + 2)

#define LIB_NET_ERROR_STR_NO_CONNECTION			"No connection to remote host established"
#define LIB_NET_ERROR_NO_NO_CONNECTION			(LIB_NET_ERROR_NO_MIN + 3)

#define LIB_NET_ERROR_STR_INVALID_ANSWER		"Invalid answer received from remote host"
#define LIB_NET_ERROR_NO_INVALID_ANSWER			(LIB_NET_ERROR_NO_MIN + 4)

#define LIB_NET_ERROR_STR_INVALID_HEADER		"Invalid header in answer from remote host"
#define LIB_NET_ERROR_NO_INVALID_HEADER			(LIB_NET_ERROR_NO_MIN + 5)

#define LIB_NET_ERROR_STR_CONNECTION_CLOSED		"Connection closed by remote host"
#define LIB_NET_ERROR_NO_CONNECTION_CLOSED		(LIB_NET_ERROR_NO_MIN + 6)

#define LIB_NET_ERROR_STR_SYSTEM			"System error in libme4000net.so occured"
#define LIB_NET_ERROR_NO_SYSTEM				(LIB_NET_ERROR_NO_MIN + 7)

#define LIB_NET_ERROR_STR_SERVER_ERROR			"Server error at the remote host occured"
#define LIB_NET_ERROR_NO_SERVER_ERROR			(LIB_NET_ERROR_NO_MIN + 8)

#endif
