#include <stdio.h>
#include <libme4000net.h>


int main(void){
	int err;
	int i;
	char **list = NULL;
	int count;
	char errMsg[256];

	err = me4000NetLookup("255.255.255.255", &list, &count);
	if(err){
		me4000NetErrorGetMessage(err, errMsg, sizeof(errMsg));
		fprintf(stderr, "Error in me4000NetLookup(): %s\n", errMsg);
		return err;
	}

	for(i = 0; i < count; i++){
		printf("%s\n", list[i]);
	}

	return 0;
}
