/* Server for the Meilhaus ME-4000 board.
 * ======================================
 *
 *  Copyright (C) 2003 Meilhaus Electronic GmbH (support@meilhaus.de)
 *  
 *  This file is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *  Author:	Guenter Gebhardt	<g.gebhardt@meilhaus.de>
 */

#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <syslog.h>

#include "libme4000net.h"



int main(int argc, char **argv){
    int	sockfd;
    struct sockaddr_in servaddr, cliaddr;
    socklen_t len;
    int	n;
    char msg[ME4000_MSG_MAXBUF + 1];


    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if(sockfd < 0){
	syslog(LOG_ERR, "In socket():");
	syslog(LOG_ERR, "%s: %s", argv[0], strerror(errno));
	return 1;
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family      = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port        = htons(ME4000_SERVER_PORT);

    if(bind(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr))){
	syslog(LOG_ERR, "In bind():");
	syslog(LOG_ERR, "%s: %s", argv[0], strerror(errno));
	return 1;
    }

    while(1){
	len = sizeof(cliaddr);
	n = recvfrom(sockfd, msg, ME4000_MSG_MAXBUF, 0, (struct sockaddr *) &cliaddr, &len);
	if(n < 0){
	    if(errno == EINTR){
		continue;
	    }
	    else{
		syslog(LOG_ERR, "In recvfrom():");
		syslog(LOG_ERR, "%s: %s", argv[0], strerror(errno));
		return 1;
	    }
	}

	snprintf(msg, ME4000_MSG_MAXBUF, "%i", me4000GetBoardCount());
	n = sendto(sockfd, msg, strlen(msg), 0, (struct sockaddr *) &cliaddr, len);
	if(n < 0){
	    if(errno == EINTR){
		continue;
	    }
	    else{
		syslog(LOG_ERR, "In sendto():");
		syslog(LOG_ERR, "%s: %s", argv[0], strerror(errno));
		return 1;
	    }
	}
    }

    return 0;
}
