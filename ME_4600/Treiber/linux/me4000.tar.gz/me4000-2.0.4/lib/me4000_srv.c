/* Server for the Meilhaus ME-4000 board.
 * ======================================
 *
 *  Copyright (C) 2003 Meilhaus Electronic GmbH (support@meilhaus.de)
 *  
 *  This file is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *  Author:	Guenter Gebhardt	<g.gebhardt@meilhaus.de>
 */

#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <syslog.h>

#include "me4000_srv.h"
#include "me4000_srv_error.h"
#include "libme4000.h"
#include "libme4000_error.h"
#include "libme4000net.h"


/* Wrappers for read and write system calls */
static ssize_t readn(int fd, void *vptr, size_t n);
static ssize_t writen(int fd, const void *vptr, size_t n);


int dispatch(int connfd);
void sig_chld(int signo);


static char *errorTable[] = {
	ME4000_SRV_ERROR_STR_INVALID_REQUEST,
	ME4000_SRV_ERROR_STR_CONNECTION_CLOSED,
	ME4000_SRV_ERROR_STR_SYSTEM
};


/*
 * Used to send back an error condition or
 * when only the return Value is to be sent
 */
static int sendReturnValue(int connfd, int iReturnValue){
	char returnline[ME4000_MSG_MAXBUF] = {0};
	char err[256];
	int n;

	if(iReturnValue == ME4000_NO_ERROR)
		snprintf(returnline, ME4000_MSG_MAXBUF, "%i", iReturnValue);
	else{
		if((iReturnValue >= ERROR_NO_MIN) && (iReturnValue <= ERROR_NO_MAX)){ // Standard library error
			me4000ErrorGetMessage(iReturnValue, err, sizeof(err));
			snprintf(returnline, ME4000_MSG_MAXBUF, "%i %s", iReturnValue, err);
		}
		else if((iReturnValue >= ME4000_SRV_ERROR_NO_MIN) && (ME4000_SRV_ERROR_NO_MAX)){
			if(iReturnValue == ME4000_SRV_ERROR_NO_SYSTEM)
				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %s", iReturnValue, strerror(errno));
			else
				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %s",iReturnValue, errorTable[iReturnValue - ME4000_SRV_ERROR_NO_MIN]);
		}
	}

	if((n = writen(connfd, returnline, ME4000_MSG_MAXBUF)) < 0){
		syslog(LOG_ERR, "sendReturnValue(): Cannot send return value\n");
		syslog(LOG_ERR, "sendReturnValue(): %s", strerror(errno));
		return ME4000_SRV_ERROR_NO_SYSTEM;
	}

	return iReturnValue;
}

/*
 * Used to send back an reply when operation was successfull
 */

static int sendReply(int connfd, char *returnline, size_t length){
	int n;

	if((n = writen(connfd, returnline, length)) < 0){
		syslog(LOG_ERR, "sendReply(): Cannot send return value\n");
		syslog(LOG_ERR, "sendReply(): %s", strerror(errno));
	}

	return 0;
}


/*============================================================================= 
  Wrappers for read and write
  ===========================================================================*/

ssize_t readn(int fd, void *vptr, size_t n){
	size_t nleft;
	ssize_t nread;
	char *ptr;

	ptr = vptr;
	nleft = n;
	while (nleft > 0) {
		if ((nread = read(fd, ptr, nleft)) < 0){
			if (errno == EINTR)
				nread = 0; /* and call read() again */
			else
				return(-1);
		} else if (nread == 0)
			break; /* EOF */

		nleft -= nread;
		ptr += nread;
	}
	return(n - nleft); /* return >= 0 */
}


ssize_t writen(int fd, const void *vptr, size_t n){
	size_t		nleft;
	ssize_t		nwritten;
	const char	*ptr;

	ptr = vptr;
	nleft = n;
	while(nleft > 0){
		if((nwritten = write(fd, ptr, nleft)) <= 0){
			if (errno == EINTR)
				nwritten = 0; /* and call write() again */
			else
				return(-1); /* error */
		}

		nleft -= nwritten;
		ptr += nwritten;
	}
	return(n);
}



/*============================================================================= 
  Supported functions of the server
  ===========================================================================*/

int dispatch(int connfd){
	char recvline[ME4000_MSG_MAXBUF + 1] = {0};
	char returnline[ME4000_MSG_MAXBUF + 1] = {0};
	int function;
	ssize_t n = 0;
	int iReturnValue;

	/* Read the request */
	n = readn(connfd, recvline, ME4000_MSG_MAXBUF);
	if(n < 0){
		syslog(LOG_ERR, "dispatch(): Cannot read request\n");
		syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
	}
	else if(n == 0){ // EOF, Connection closed by remote host
		syslog(LOG_DEBUG, "dispatch(): Connection closed by remote host\n");
		return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
	}

	syslog(LOG_DEBUG, "dispatch(): Received request: %s\n", recvline);

	/* Get the function name */
	sscanf(recvline, "%i", &function);

	switch(function){
		case ME4000_GET_BOARD_VERSION_ID:
			{
				unsigned int uiBoardNumber;
				unsigned short usVersion;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000GetBoardVersion(uiBoardNumber, &usVersion)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %hu", iReturnValue, usVersion);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_GET_SERVER_VERSION_ID:
			{
				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %hu", 0, ME4000_SRV_VERSION);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_GET_DLL_VERSION_ID:
			{
				unsigned long ulVersion;

				if((iReturnValue = me4000GetDLLVersion(&ulVersion)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %lu", iReturnValue, ulVersion);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_GET_DRIVER_VERSION_ID:
			{
				unsigned long ulVersion;

				if((iReturnValue = me4000GetDriverVersion(&ulVersion)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %lu", iReturnValue, ulVersion);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_GET_SERIAL_NUMBER_ID:
			{
				unsigned int uiBoardNumber;
				unsigned long ulVersion;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000GetSerialNumber(uiBoardNumber, &ulVersion)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %lu", iReturnValue, ulVersion);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_AI_OPEN_ID:
			{
				unsigned int uiBoardNumber;
				int iAcqMode;

				n = sscanf(recvline, "%i %u %i",
						&function,
						&uiBoardNumber,
						&iAcqMode);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000AIOpen(
						uiBoardNumber,
						iAcqMode);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AI_CLOSE_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000AIClose(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AI_CONFIG_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiChanListCount;
				int iSDMode;
				int iSimultaneous;
				unsigned long ulChanTicks;
				unsigned long ulScanTicksLow;
				unsigned long ulScanTicksHigh;
				int iAcqMode;
				int iExtTriggerMode;
				int iExtTriggerEdge;
				unsigned char *pucChanList = NULL;

				n = sscanf(recvline, "%i %u %u %i %i %lu %lu %lu %i %i %i",
						&function,
						&uiBoardNumber,
						&uiChanListCount,
						&iSDMode,
						&iSimultaneous,
						&ulChanTicks,
						&ulScanTicksLow,
						&ulScanTicksHigh,
						&iAcqMode,
						&iExtTriggerMode,
						&iExtTriggerEdge);
				if(n != 11)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				pucChanList = malloc(sizeof(unsigned char) * uiChanListCount);
				if(pucChanList == NULL){
					syslog(LOG_ERR, "dispatch(): Cannot allocate memory for channel list\n");
					syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}

				n = readn(connfd, pucChanList, sizeof(unsigned char) * uiChanListCount);
				if(n < 0){
					syslog(LOG_ERR, "dispatch(): Cannot read channel list\n");
					syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
					free(pucChanList);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}
				else if(n == 0){ // EOF, Connection closed by remote host
					syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
					free(pucChanList);
					return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
				}

				iReturnValue = me4000AIConfig(
						uiBoardNumber,
						pucChanList,
						uiChanListCount,
						iSDMode,
						iSimultaneous,
						ME4000_VALUE_NOT_USED,
						ulChanTicks,
						ulScanTicksLow,
						ulScanTicksHigh,
						iAcqMode,
						iExtTriggerMode,
						iExtTriggerEdge);

				free(pucChanList);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AI_CONTINUOUS_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiRefreshFrequency;
				unsigned long ulTimeOutSeconds;

				n = sscanf(recvline, "%i %u %u %lu",
						&function,
						&uiBoardNumber,
						&uiRefreshFrequency,
						&ulTimeOutSeconds);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000AIContinuous(
								uiBoardNumber,
								ME4000_POINTER_NOT_USED,
								ME4000_POINTER_NOT_USED,
								uiRefreshFrequency,
								ulTimeOutSeconds)))
					return sendReturnValue(connfd, iReturnValue);

				iReturnValue = me4000AIStart(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AI_GET_NEW_VALUES_ID:
			{
				unsigned int uiBoardNumber;
				unsigned long ulNumberOfValuesToRead;
				int iExecutionMode;
				unsigned long ulNumberOfValuesRead = 0;
				int iLastError;
				short *psBuffer;

				n = sscanf(recvline, "%i %u %lu %i",
						&function,
						&uiBoardNumber,
						&ulNumberOfValuesToRead,
						&iExecutionMode);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = 0;
				if(ulNumberOfValuesToRead){
					psBuffer = malloc(sizeof(short) * ulNumberOfValuesToRead);
					if(!psBuffer){
						syslog(LOG_ERR, "dispatch(): Cannot allocate buffer for measurement data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					if((iReturnValue = me4000AIGetNewValues(
									uiBoardNumber,
									psBuffer,
									ulNumberOfValuesToRead,
									iExecutionMode,
									&ulNumberOfValuesRead,
									&iLastError))){
						free(psBuffer);
						return sendReturnValue(connfd, iReturnValue);
					}

					snprintf(returnline, ME4000_MSG_MAXBUF, "%i %lu", iReturnValue, ulNumberOfValuesRead);
					iReturnValue = sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
					if(iReturnValue) return iReturnValue;

					if(writen(connfd, psBuffer, sizeof(short) * ulNumberOfValuesRead) <= 0){
						syslog(LOG_ERR, "dispatch(): Cannot send measurement data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(psBuffer);
						return ME4000_SRV_ERROR_NO_SYSTEM;
					}

					free(psBuffer);
				}
				else{
					snprintf(returnline, ME4000_MSG_MAXBUF, "%i %lu", iReturnValue, ulNumberOfValuesRead);
					iReturnValue = sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
					if(iReturnValue) return iReturnValue;
				}

				break;
			}
		case ME4000_AI_GET_STATUS_ID:
			{
				unsigned int uiBoardNumber;
				int iWaitIdle;
				int iStatus;

				n = sscanf(recvline, "%i %u %i",
						&function,
						&uiBoardNumber,
						&iWaitIdle);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000AIGetStatus(
								uiBoardNumber,
								iWaitIdle,
								&iStatus)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %i", iReturnValue, iStatus);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_AI_RESET_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000AIReset(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AI_SCAN_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiNumberOfChanLists;
				unsigned long ulBufferSizeValues;
				unsigned long ulTimeOutSeconds;
				short *psBuffer = NULL;

				n = sscanf(recvline, "%i %u %u %lu %lu",
						&function,
						&uiBoardNumber,
						&uiNumberOfChanLists,
						&ulBufferSizeValues,
						&ulTimeOutSeconds);
				if(n != 5)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = 0;
				if(ulBufferSizeValues){
					psBuffer = malloc(sizeof(short) * ulBufferSizeValues);
					if(!psBuffer){
						syslog(LOG_ERR, "dispatch(): Cannot allocate buffer for measurement data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					if((iReturnValue = me4000AIScan(
									uiBoardNumber,
									uiNumberOfChanLists,
									psBuffer,
									ulBufferSizeValues,
									ME4000_AI_SCAN_BLOCKING,
									ME4000_POINTER_NOT_USED,
									ME4000_POINTER_NOT_USED,
									ME4000_VALUE_NOT_USED,
									ME4000_POINTER_NOT_USED,
									ME4000_POINTER_NOT_USED,
									ulTimeOutSeconds))){
						free(psBuffer);
						return sendReturnValue(connfd, iReturnValue);
					}

					if((iReturnValue = me4000AIStart(uiBoardNumber))){
						free(psBuffer);
						return sendReturnValue(connfd, iReturnValue);
					}

					if((iReturnValue = sendReturnValue(connfd, iReturnValue))){
						free(psBuffer);
						return iReturnValue;
					}

					if(writen(connfd, psBuffer, sizeof(short) * ulBufferSizeValues) < 0){
						syslog(LOG_ERR, "dispatch(): Cannot send measurement data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(psBuffer);
						return ME4000_SRV_ERROR_NO_SYSTEM;
					}

					free(psBuffer);
				}
				else{
					return sendReturnValue(connfd, iReturnValue);
				}

				break;
			}
		case ME4000_AI_SINGLE_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				int iRange;
				int iSDMode;
				int iTriggerMode;
				int iTriggerEdge;
				unsigned long ulTimeOutSeconds;
				short sValue;

				n = sscanf(recvline, "%i %u %u %i %i %i %i %lu",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&iRange,
						&iSDMode,
						&iTriggerMode,
						&iTriggerEdge,
						&ulTimeOutSeconds);
				if(n != 8)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000AISingle(
								uiBoardNumber,
								uiPortNumber,
								iRange,
								iSDMode,
								iTriggerMode,
								iTriggerEdge,
								ulTimeOutSeconds,
								&sValue)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %hi", iReturnValue, sValue);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_AI_STOP_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000AIStop(uiBoardNumber, ME4000_VALUE_NOT_USED);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AO_OPEN_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				int iConversationMode;

				n = sscanf(recvline, "%i %u %u %i",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&iConversationMode);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000AOOpen(
						uiBoardNumber,
						uiPortNumber,
						iConversationMode);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AO_CLOSE_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;

				n = sscanf(recvline, "%i %u %u", &function, &uiBoardNumber, &uiPortNumber);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000AOClose(uiBoardNumber, uiPortNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AO_APPEND_NEW_VALUES_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				unsigned short *pusBuffer = NULL;
				unsigned long ulNumberOfValuesToAppend;
				int iExecutionMode;
				unsigned long ulNumberOfValuesAppended = 0;

				n = sscanf(recvline, "%i %u %u %lu %i",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&ulNumberOfValuesToAppend,
						&iExecutionMode);
				if(n != 5)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = 0;
				if(ulNumberOfValuesToAppend){
					pusBuffer = malloc(sizeof(unsigned short) * ulNumberOfValuesToAppend);
					if(pusBuffer == NULL){
						syslog(LOG_ERR, "dispatch(): Cannot allocate memory for data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					n = readn(connfd, pusBuffer, sizeof(unsigned short) * ulNumberOfValuesToAppend);
					if(n < 0){
						syslog(LOG_ERR, "dispatch(): Cannot read data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(pusBuffer);
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}
					else if(n == 0){ // EOF, Connection closed by remote host
						syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
						free(pusBuffer);
						return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
					}

					if((iReturnValue = me4000AOAppendNewValues(
									uiBoardNumber,
									uiPortNumber,
									pusBuffer,
									ulNumberOfValuesToAppend,
									iExecutionMode,
									&ulNumberOfValuesAppended))){
						free(pusBuffer);
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					free(pusBuffer);
				}

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %lu", iReturnValue, ulNumberOfValuesAppended);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_AO_CONFIG_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				unsigned long ulTicks;
				int iTriggerMode;
				int iExtTriggerEdge;

				n = sscanf(recvline, "%i %u %u %lu %i %i",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&ulTicks,
						&iTriggerMode,
						&iExtTriggerEdge);
				if(n != 6)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000AOConfig(
						uiBoardNumber,
						uiPortNumber,
						ulTicks,
						iTriggerMode,
						iExtTriggerEdge);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AO_CONTINUOUS_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				unsigned short *pusBuffer = NULL;
				unsigned long ulDataCount;
				unsigned long ulTimeOutSeconds;
				unsigned long ulNumberOfValuesWritten = 0;

				n = sscanf(recvline, "%i %u %u %lu %lu",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&ulDataCount,
						&ulTimeOutSeconds);
				if(n != 5)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = ME4000_NO_ERROR;
				if(ulDataCount){
					pusBuffer = malloc(sizeof(unsigned short) * ulDataCount);
					if(pusBuffer == NULL){
						syslog(LOG_ERR, "dispatch(): Cannot allocate memory for data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					n = readn(connfd, pusBuffer, sizeof(unsigned short) * ulDataCount);
					if(n < 0){
						syslog(LOG_ERR, "dispatch(): Cannot read data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(pusBuffer);
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}
					else if(n == 0){ // EOF, Connection closed by remote host
						syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
						free(pusBuffer);
						return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
					}

					if((iReturnValue = me4000AOContinuous(
									uiBoardNumber,
									uiPortNumber,
									pusBuffer,
									ulDataCount,
									NULL,
									NULL,
									ulTimeOutSeconds,
									&ulNumberOfValuesWritten))){
						free(pusBuffer);
						return sendReturnValue(connfd, iReturnValue);
					}

					free(pusBuffer);
				}

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %lu", iReturnValue, ulNumberOfValuesWritten);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_AO_GET_STATUS_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				int iWaitIdle;
				int iStatus;

				n = sscanf(recvline, "%i %u %u %i",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&iWaitIdle);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000AOGetStatus(
								uiBoardNumber,
								uiPortNumber,
								iWaitIdle,
								&iStatus)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %i", iReturnValue, iStatus);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_AO_RESET_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;

				n = sscanf(recvline, "%i %u %u", &function, &uiBoardNumber, &uiPortNumber);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000AOReset(uiBoardNumber, uiPortNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AO_SINGLE_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				int iTriggerMode;
				int iTriggerEdge;
				unsigned long ulTimeOutSeconds;
				unsigned short usValue;

				n = sscanf(recvline, "%i %u %u %i %i %lu %hu",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&iTriggerMode,
						&iTriggerEdge,
						&ulTimeOutSeconds,
						&usValue);
				if(n != 7)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000AOSingle(
						uiBoardNumber,
						uiPortNumber,
						iTriggerMode,
						iTriggerEdge,
						ulTimeOutSeconds,
						usValue);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AO_SINGLE_SIMULTANEOUS_ID:
			{
				unsigned int uiBoardNumber;
				unsigned long ulCount;
				int iTriggerMode;
				unsigned long ulTimeOutSeconds;
				unsigned int *puiChannelNumber = NULL;
				int *piExtTriggerEnable = NULL;
				int *piExtTriggerEdge = NULL;
				unsigned short *pusValue = NULL;

				n = sscanf(recvline, "%i %u %lu %i %lu",
						&function,
						&uiBoardNumber,
						&ulCount,
						&iTriggerMode,
						&ulTimeOutSeconds);
				if(n != 5)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				puiChannelNumber = malloc(sizeof(unsigned int) * ulCount);
				if(!puiChannelNumber){
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}

				piExtTriggerEnable = malloc(sizeof(unsigned int) * ulCount);
				if(!piExtTriggerEnable){
					free(puiChannelNumber);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}

				piExtTriggerEdge = malloc(sizeof(unsigned int) * ulCount);
				if(!piExtTriggerEdge){
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}

				pusValue = malloc(sizeof(unsigned int) * ulCount);
				if(!pusValue){
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}

				n = readn(connfd, puiChannelNumber, sizeof(unsigned int) * ulCount);
				if(n < 0){
					syslog(LOG_ERR, "dispatch(): Cannot read channel nunbers\n");
					syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					free(pusValue);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}
				else if(n == 0){ // EOF, Connection closed by remote host
					syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					free(pusValue);
					return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
				}

				n = readn(connfd, piExtTriggerEnable, sizeof(int) * ulCount);
				if(n < 0){
					syslog(LOG_ERR, "dispatch(): Cannot read trigger enable list\n");
					syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					free(pusValue);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}
				else if(n == 0){ // EOF, Connection closed by remote host
					syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					free(pusValue);
					return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
				}

				n = readn(connfd, piExtTriggerEdge, sizeof(int) * ulCount);
				if(n < 0){
					syslog(LOG_ERR, "dispatch(): Cannot read trigger edge list\n");
					syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					free(pusValue);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}
				else if(n == 0){ // EOF, Connection closed by remote host
					syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					free(pusValue);
					return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
				}

				n = readn(connfd, pusValue, sizeof(unsigned short) * ulCount);
				if(n < 0){
					syslog(LOG_ERR, "dispatch(): Cannot read values\n");
					syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					free(pusValue);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}
				else if(n == 0){ // EOF, Connection closed by remote host
					syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					free(pusValue);
					return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
				}

				iReturnValue = me4000AOSingleSimultaneous(
						uiBoardNumber,
						puiChannelNumber,
						ulCount,
						iTriggerMode,
						piExtTriggerEnable,
						piExtTriggerEdge,
						ulTimeOutSeconds,
						pusValue);

				free(puiChannelNumber);
				free(piExtTriggerEnable);
				free(piExtTriggerEdge);
				free(pusValue);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AO_START_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;

				n = sscanf(recvline, "%i %u %u",
						&function,
						&uiPortNumber,
						&uiBoardNumber);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000AOStart(uiBoardNumber, uiPortNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AO_START_SYNCHRONOUS_ID:
			{
				unsigned int uiBoardNumber;
				unsigned long ulCount;
				int iTriggerMode;
				unsigned long ulTimeOutSeconds;
				unsigned int *puiChannelNumber = NULL;
				int *piExtTriggerEnable = NULL;
				int *piExtTriggerEdge = NULL;

				n = sscanf(recvline, "%i %u %lu %i %lu",
						&function,
						&uiBoardNumber,
						&ulCount,
						&iTriggerMode,
						&ulTimeOutSeconds);
				if(n != 5)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				puiChannelNumber = malloc(sizeof(unsigned int) * ulCount);
				if(!puiChannelNumber){
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}

				piExtTriggerEnable = malloc(sizeof(unsigned int) * ulCount);
				if(!piExtTriggerEnable){
					free(puiChannelNumber);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}

				piExtTriggerEdge = malloc(sizeof(unsigned int) * ulCount);
				if(!piExtTriggerEdge){
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}

				n = readn(connfd, puiChannelNumber, sizeof(unsigned int) * ulCount);
				if(n < 0){
					syslog(LOG_ERR, "dispatch(): Cannot read channel nunbers\n");
					syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}
				else if(n == 0){ // EOF, Connection closed by remote host
					syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
				}

				n = readn(connfd, piExtTriggerEnable, sizeof(int) * ulCount);
				if(n < 0){
					syslog(LOG_ERR, "dispatch(): Cannot read trigger enable list\n");
					syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}
				else if(n == 0){ // EOF, Connection closed by remote host
					syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
				}

				n = readn(connfd, piExtTriggerEdge, sizeof(int) * ulCount);
				if(n < 0){
					syslog(LOG_ERR, "dispatch(): Cannot read trigger edge list\n");
					syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}
				else if(n == 0){ // EOF, Connection closed by remote host
					syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
					free(puiChannelNumber);
					free(piExtTriggerEnable);
					free(piExtTriggerEdge);
					return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
				}

				iReturnValue = me4000AOStartSynchronous(
						uiBoardNumber,
						puiChannelNumber,
						ulCount,
						iTriggerMode,
						piExtTriggerEnable,
						piExtTriggerEdge,
						ulTimeOutSeconds);

				free(puiChannelNumber);
				free(piExtTriggerEnable);
				free(piExtTriggerEdge);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AO_STOP_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				int iStopMode;

				n = sscanf(recvline, "%i %u %u %i",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&iStopMode);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000AOStop(uiBoardNumber, uiPortNumber, iStopMode);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AO_WAVE_GEN_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				int iShape;
				double dAmplitude;
				double dOffset;
				double dFrequency;

				n = sscanf(recvline, "%i %u %u %i %lf %lf %lf",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&iShape,
						&dAmplitude,
						&dOffset,
						&dFrequency);
				if(n != 7)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000AOWaveGen(
						uiBoardNumber,
						uiPortNumber,
						iShape,
						dAmplitude,
						dOffset,
						dFrequency);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_AO_WRAPAROUND_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				unsigned short *pusBuffer = NULL;
				unsigned long ulDataCount;
				unsigned long ulTimeOutSeconds;

				n = sscanf(recvline, "%i %u %u %lu %lu",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&ulDataCount,
						&ulTimeOutSeconds);
				if(n != 5)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = ME4000_NO_ERROR;
				if(ulDataCount){
					pusBuffer = malloc(sizeof(unsigned short) * ulDataCount);
					if(pusBuffer == NULL){
						syslog(LOG_ERR, "dispatch(): Cannot allocate memory for data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					n = readn(connfd, pusBuffer, sizeof(unsigned short) * ulDataCount);
					if(n < 0){
						syslog(LOG_ERR, "dispatch(): Cannot read data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(pusBuffer);
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}
					else if(n == 0){ // EOF, Connection closed by remote host
						syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
						free(pusBuffer);
						return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
					}

					iReturnValue = me4000AOWraparound(
							uiBoardNumber,
							uiPortNumber,
							pusBuffer,
							ulDataCount,
							ME4000_AO_WRAPAROUND_INFINITE,
							ME4000_AO_WRAPAROUND_ASYNCHRONOUS,
							ME4000_POINTER_NOT_USED,
							ME4000_POINTER_NOT_USED,
							ulTimeOutSeconds);

					free(pusBuffer);
				}

				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_DIO_OPEN_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000DIOOpen(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_DIO_CLOSE_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000DIOClose(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_DIO_CONFIG_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				int iPortDirection;

				n = sscanf(recvline, "%i %u %u %i",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&iPortDirection);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000DIOConfig(uiBoardNumber, uiPortNumber, iPortDirection);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_DIO_GET_BIT_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				unsigned int uiBitNumber;
				int iBitValue;

				n = sscanf(recvline, "%i %u %u %u",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&uiBitNumber);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000DIOGetBit(uiBoardNumber, uiPortNumber, uiBitNumber, &iBitValue)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %i", iReturnValue, iBitValue);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_DIO_GET_BYTE_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				unsigned char ucByteValue;

				n = sscanf(recvline, "%i %u %u",
						&function,
						&uiBoardNumber,
						&uiPortNumber);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000DIOGetByte(uiBoardNumber, uiPortNumber, &ucByteValue)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %hhu", iReturnValue, ucByteValue);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_DIO_RESET_ALL_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000DIOResetAll(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_DIO_SET_BIT_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				unsigned int uiBitNumber;
				int iBitValue;

				n = sscanf(recvline, "%i %u %u %u %i",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&uiBitNumber,
						&iBitValue);
				if(n != 5)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000DIOSetBit(uiBoardNumber, uiPortNumber, uiBitNumber, iBitValue);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_DIO_SET_BYTE_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				unsigned char ucByteValue;

				n = sscanf(recvline, "%i %u %u %hhu",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&ucByteValue);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000DIOSetByte(uiBoardNumber, uiPortNumber, ucByteValue);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_DIOBP_OPEN_ID:
			{
				unsigned int uiBoardNumber;
				int iConversationMode;

				n = sscanf(recvline, "%i %u %i",
						&function,
						&uiBoardNumber,
						&iConversationMode);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000DIOBPOpen(uiBoardNumber, iConversationMode);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_DIOBP_CLOSE_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000DIOBPClose(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_DIOBP_APPEND_NEW_VALUES_ID:
			{
				unsigned int uiBoardNumber;
				unsigned short *pusBuffer = NULL;
				unsigned long ulNumberOfValuesToAppend;
				int iExecutionMode;
				unsigned long ulNumberOfValuesAppended = 0;

				n = sscanf(recvline, "%i %u %lu %i",
						&function,
						&uiBoardNumber,
						&ulNumberOfValuesToAppend,
						&iExecutionMode);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = ME4000_NO_ERROR;
				if(ulNumberOfValuesToAppend){
					pusBuffer = malloc(sizeof(unsigned short) * ulNumberOfValuesToAppend);
					if(pusBuffer == NULL){
						syslog(LOG_ERR, "dispatch(): Cannot allocate memory for data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					n = readn(connfd, pusBuffer, sizeof(unsigned short) * ulNumberOfValuesToAppend);
					if(n < 0){
						syslog(LOG_ERR, "dispatch(): Cannot read data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(pusBuffer);
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}
					else if(n == 0){ // EOF, Connection closed by remote host
						syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
						free(pusBuffer);
						return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
					}

					if((iReturnValue = me4000DIOBPAppendNewValues(
									uiBoardNumber,
									pusBuffer,
									ulNumberOfValuesToAppend,
									iExecutionMode,
									&ulNumberOfValuesAppended))){
						free(pusBuffer);
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					free(pusBuffer);
				}

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %lu", iReturnValue, ulNumberOfValuesAppended);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_DIOBP_CONFIG_ID:
			{
				unsigned int uiBoardNumber;
				unsigned long ulTicks;
				int iTriggerMode;
				int iExtTriggerEdge;

				n = sscanf(recvline, "%i %u %lu %i %i",
						&function,
						&uiBoardNumber,
						&ulTicks,
						&iTriggerMode,
						&iExtTriggerEdge);
				if(n != 5)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000DIOBPConfig(
						uiBoardNumber,
						ulTicks,
						iTriggerMode,
						iExtTriggerEdge);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_DIOBP_CONTINUOUS_ID:
			{
				unsigned int uiBoardNumber;
				unsigned short *pusBuffer = NULL;
				unsigned long ulDataCount;
				unsigned long ulTimeOutSeconds;
				unsigned long ulNumberOfValuesWritten = 0;

				n = sscanf(recvline, "%i %u %lu %lu",
						&function,
						&uiBoardNumber,
						&ulDataCount,
						&ulTimeOutSeconds);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = ME4000_NO_ERROR;
				if(ulDataCount){
					pusBuffer = malloc(sizeof(unsigned short) * ulDataCount);
					if(pusBuffer == NULL){
						syslog(LOG_ERR, "dispatch(): Cannot allocate memory for data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					n = readn(connfd, pusBuffer, sizeof(unsigned short) * ulDataCount);
					if(n < 0){
						syslog(LOG_ERR, "dispatch(): Cannot read data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(pusBuffer);
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}
					else if(n == 0){ // EOF, Connection closed by remote host
						syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
						free(pusBuffer);
						return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
					}

					if((iReturnValue = me4000DIOBPContinuous(
									uiBoardNumber,
									pusBuffer,
									ulDataCount,
									NULL,
									NULL,
									ulTimeOutSeconds,
									&ulNumberOfValuesWritten))){
						free(pusBuffer);
						return sendReturnValue(connfd, iReturnValue);
					}

					free(pusBuffer);

					if((iReturnValue = me4000DIOBPStart(uiBoardNumber)))
						return sendReturnValue(connfd, iReturnValue);
				}

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %lu", iReturnValue, ulNumberOfValuesWritten);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_DIOBP_GET_STATUS_ID:
			{
				unsigned int uiBoardNumber;
				int iWaitIdle;
				int iStatus;

				n = sscanf(recvline, "%i %u %i",
						&function,
						&uiBoardNumber,
						&iWaitIdle);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000DIOBPGetStatus(
								uiBoardNumber,
								iWaitIdle,
								&iStatus)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %i", iReturnValue, iStatus);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_DIOBP_PORT_CONFIG_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				int iOutputMode;

				n = sscanf(recvline, "%i %u %u %i",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&iOutputMode);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000DIOBPPortConfig(
						uiBoardNumber,
						uiPortNumber,
						iOutputMode);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_DIOBP_RESET_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000DIOBPReset(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_DIOBP_STOP_ID:
			{
				unsigned int uiBoardNumber;
				int iStopMode;

				n = sscanf(recvline, "%i %u %i",
						&function,
						&uiBoardNumber,
						&iStopMode);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000DIOBPStop(uiBoardNumber, iStopMode);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_DIOBP_WRAPAROUND_ID:
			{
				unsigned int uiBoardNumber;
				unsigned short *pusBuffer = NULL;
				unsigned long ulDataCount;
				unsigned long ulTimeOutSeconds;

				n = sscanf(recvline, "%i %u %lu %lu",
						&function,
						&uiBoardNumber,
						&ulDataCount,
						&ulTimeOutSeconds);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = ME4000_NO_ERROR;
				if(ulDataCount){
					pusBuffer = malloc(sizeof(unsigned short) * ulDataCount);
					if(pusBuffer == NULL){
						syslog(LOG_ERR, "dispatch(): Cannot allocate memory for data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					n = readn(connfd, pusBuffer, sizeof(unsigned short) * ulDataCount);
					if(n < 0){
						syslog(LOG_ERR, "dispatch(): Cannot read data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(pusBuffer);
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}
					else if(n == 0){ // EOF, Connection closed by remote host
						syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
						free(pusBuffer);
						return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
					}

					if((iReturnValue = me4000DIOBPWraparound(
									uiBoardNumber,
									pusBuffer,
									ulDataCount,
									ME4000_DIOBP_WRAPAROUND_INFINITE,
									ME4000_DIOBP_WRAPAROUND_ASYNCHRONOUS,
									ME4000_POINTER_NOT_USED,
									ME4000_POINTER_NOT_USED,
									ulTimeOutSeconds)))
						return sendReturnValue(connfd, iReturnValue);


					if((iReturnValue = me4000DIOBPStart(uiBoardNumber)))
						return sendReturnValue(connfd, iReturnValue);

					free(pusBuffer);
				}

				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_CNT_OPEN_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000CntOpen(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_CNT_CLOSE_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000CntClose(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_CNT_PWM_START_ID:
			{
				unsigned int uiBoardNumber;
				int iPrescaler;
				int iDutyCycle;

				n = sscanf(recvline, "%i %u %i %i",
						&function,
						&uiBoardNumber,
						&iPrescaler,
						&iDutyCycle);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000CntPWMStart(
						uiBoardNumber,
						iPrescaler,
						iDutyCycle);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_CNT_PWM_STOP_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000CntPWMStop(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_CNT_READ_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiCounterNumber;
				unsigned short usValue;

				n = sscanf(recvline, "%i %u %i",
						&function,
						&uiBoardNumber,
						&uiCounterNumber);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000CntRead(uiBoardNumber, uiCounterNumber, &usValue)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %hu", iReturnValue, usValue);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_CNT_WRITE_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiCounterNumber;
				int iMode;
				unsigned short usValue;

				n = sscanf(recvline, "%i %u %i %i %hu",
						&function,
						&uiBoardNumber,
						&uiCounterNumber,
						&iMode,
						&usValue);
				if(n != 5)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000CntWrite(uiBoardNumber, uiCounterNumber, iMode, usValue);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_OPEN_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigOpen(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_CLOSE_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigClose(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_ADDRESS_LED_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiBase;
				int iLEDStatus;

				n = sscanf(recvline, "%i %u %u %i",
						&function,
						&uiBoardNumber,
						&uiBase,
						&iLEDStatus);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigAddressLED(
						uiBoardNumber,
						uiBase,
						iLEDStatus);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_RESET_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigReset(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_SET_GAIN_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiBase;
				int iChannelGroup;
				int iGain;

				n = sscanf(recvline, "%i %u %u %i %i",
						&function,
						&uiBoardNumber,
						&uiBase,
						&iChannelGroup,
						&iGain);
				if(n != 5)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigSetGain(
						uiBoardNumber,
						uiBase,
						iChannelGroup,
						iGain);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AI_OPEN_ID:
			{
				unsigned int uiBoardNumber;
				int iAcqMode;

				n = sscanf(recvline, "%i %u %i",
						&function,
						&uiBoardNumber,
						&iAcqMode);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigAIOpen(uiBoardNumber, iAcqMode);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AI_CLOSE_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigAIClose(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AI_CONFIG_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiAIChannelNumber;
				unsigned int uiChanListCount;
				unsigned long ulChanTicks;
				unsigned long ulScanTicksLow;
				unsigned long ulScanTicksHigh;
				int iAcqMode;
				int iExtTriggerMode;
				int iExtTriggerEdge;
				unsigned char *pucChanList = NULL;

				n = sscanf(recvline, "%i %u %u %u %lu %lu %lu %i %i %i",
						&function,
						&uiBoardNumber,
						&uiAIChannelNumber,
						&uiChanListCount,
						&ulChanTicks,
						&ulScanTicksLow,
						&ulScanTicksHigh,
						&iAcqMode,
						&iExtTriggerMode,
						&iExtTriggerEdge);
				if(n != 10)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				pucChanList = malloc(sizeof(unsigned char) * uiChanListCount);
				if(pucChanList == NULL){
					syslog(LOG_ERR, "dispatch(): Cannot allocate memory for channel list\n");
					syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}

				n = readn(connfd, pucChanList, sizeof(unsigned char) * uiChanListCount);
				if(n < 0){
					syslog(LOG_ERR, "dispatch(): Cannot read channel list\n");
					syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
					free(pucChanList);
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
				}
				else if(n == 0){ // EOF, Connection closed by remote host
					syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
					free(pucChanList);
					return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
				}

				iReturnValue = me4000MultiSigAIConfig(
						uiBoardNumber,
						uiAIChannelNumber,
						pucChanList,
						uiChanListCount,
						ME4000_VALUE_NOT_USED,
						ulChanTicks,
						ulScanTicksLow,
						ulScanTicksHigh,
						iAcqMode,
						iExtTriggerMode,
						iExtTriggerEdge);

				free(pucChanList);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AI_CONTINUOUS_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiRefreshFrequency;
				unsigned long ulTimeOutSeconds;

				n = sscanf(recvline, "%i %u %u %lu",
						&function,
						&uiBoardNumber,
						&uiRefreshFrequency,
						&ulTimeOutSeconds);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000MultiSigAIContinuous(
								uiBoardNumber,
								ME4000_POINTER_NOT_USED,
								ME4000_POINTER_NOT_USED,
								uiRefreshFrequency,
								ulTimeOutSeconds)))
					return sendReturnValue(connfd, iReturnValue);

				iReturnValue = me4000MultiSigAIStart(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AI_GET_NEW_VALUES_ID:
			{
				unsigned int uiBoardNumber;
				unsigned long ulNumberOfValuesToRead;
				int iExecutionMode;
				unsigned long ulNumberOfValuesRead = 0;
				int iLastError;
				short *psBuffer;

				n = sscanf(recvline, "%i %u %lu %i",
						&function,
						&uiBoardNumber,
						&ulNumberOfValuesToRead,
						&iExecutionMode);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = 0;
				if(ulNumberOfValuesToRead){
					psBuffer = malloc(sizeof(short) * ulNumberOfValuesToRead);
					if(!psBuffer){
						syslog(LOG_ERR, "dispatch(): Cannot allocate buffer for measurement data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					if((iReturnValue = me4000MultiSigAIGetNewValues(
									uiBoardNumber,
									psBuffer,
									ulNumberOfValuesToRead,
									iExecutionMode,
									&ulNumberOfValuesRead,
									&iLastError))){
						free(psBuffer);
						return sendReturnValue(connfd, iReturnValue);
					}

					snprintf(returnline, ME4000_MSG_MAXBUF, "%i %lu", iReturnValue, ulNumberOfValuesRead);
					iReturnValue = sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
					if(iReturnValue) return iReturnValue;

					if(writen(connfd, psBuffer, sizeof(short) * ulNumberOfValuesRead) <= 0){
						syslog(LOG_ERR, "dispatch(): Cannot send measurement data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(psBuffer);
						return ME4000_SRV_ERROR_NO_SYSTEM;
					}

					free(psBuffer);
				}
				else{
					snprintf(returnline, ME4000_MSG_MAXBUF, "%i %lu", iReturnValue, ulNumberOfValuesRead);
					iReturnValue = sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
					if(iReturnValue) return iReturnValue;
				}

				break;
			}
		case ME4000_MULTISIG_AI_GET_STATUS_ID:
			{
				unsigned int uiBoardNumber;
				int iWaitIdle;
				int iStatus;

				n = sscanf(recvline, "%i %u %i",
						&function,
						&uiBoardNumber,
						&iWaitIdle);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000MultiSigAIGetStatus(
								uiBoardNumber,
								iWaitIdle,
								&iStatus)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %i", iReturnValue, iStatus);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_MULTISIG_AI_RESET_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigAIReset(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AI_SCAN_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiNumberOfChanLists;
				unsigned long ulBufferSizeValues;
				unsigned long ulTimeOutSeconds;
				short *psBuffer = NULL;

				n = sscanf(recvline, "%i %u %u %lu %lu",
						&function,
						&uiBoardNumber,
						&uiNumberOfChanLists,
						&ulBufferSizeValues,
						&ulTimeOutSeconds);
				if(n != 5)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = 0;
				if(ulBufferSizeValues){
					psBuffer = malloc(sizeof(short) * ulBufferSizeValues);
					if(!psBuffer){
						syslog(LOG_ERR, "dispatch(): Cannot allocate buffer for measurement data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					if((iReturnValue = me4000MultiSigAIScan(
									uiBoardNumber,
									uiNumberOfChanLists,
									psBuffer,
									ulBufferSizeValues,
									ME4000_AI_SCAN_BLOCKING,
									ME4000_POINTER_NOT_USED,
									ME4000_POINTER_NOT_USED,
									ME4000_VALUE_NOT_USED,
									ME4000_POINTER_NOT_USED,
									ME4000_POINTER_NOT_USED,
									ulTimeOutSeconds))){
						free(psBuffer);
						return sendReturnValue(connfd, iReturnValue);
					}

					if((iReturnValue = me4000MultiSigAIStart(uiBoardNumber))){
						free(psBuffer);
						return sendReturnValue(connfd, iReturnValue);
					}

					if((iReturnValue = sendReturnValue(connfd, iReturnValue))){
						free(psBuffer);
						return iReturnValue;
					}

					if(writen(connfd, psBuffer, sizeof(short) * ulBufferSizeValues) < 0){
						syslog(LOG_ERR, "dispatch(): Cannot send measurement data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(psBuffer);
						return ME4000_SRV_ERROR_NO_SYSTEM;
					}

					free(psBuffer);
				}
				else{
					return sendReturnValue(connfd, iReturnValue);
				}

				break;
			}
		case ME4000_MULTISIG_AI_SINGLE_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiAIChannelNumber;
				unsigned int uiMuxChannelNumber;
				int iGain;
				int iTriggerMode;
				int iTriggerEdge;
				unsigned long ulTimeOutSeconds;
				short sValue;

				n = sscanf(recvline, "%i %u %u %u %i %i %i %lu",
						&function,
						&uiBoardNumber,
						&uiAIChannelNumber,
						&uiMuxChannelNumber,
						&iGain,
						&iTriggerMode,
						&iTriggerEdge,
						&ulTimeOutSeconds);
				if(n != 8)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000MultiSigAISingle(
								uiBoardNumber,
								uiAIChannelNumber,
								uiMuxChannelNumber,
								iGain,
								iTriggerMode,
								iTriggerEdge,
								ulTimeOutSeconds,
								&sValue)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %hi", iReturnValue, sValue);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_MULTISIG_AI_STOP_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigAIStop(uiBoardNumber, ME4000_VALUE_NOT_USED);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AO_OPEN_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				int iConversationMode;

				n = sscanf(recvline, "%i %u %u %i",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&iConversationMode);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigAOOpen(
						uiBoardNumber,
						iConversationMode);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AO_CLOSE_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;

				n = sscanf(recvline, "%i %u %u", &function, &uiBoardNumber, &uiPortNumber);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigAOClose(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AO_APPEND_NEW_VALUES_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiPortNumber;
				unsigned short *pusBuffer = NULL;
				unsigned long ulNumberOfValuesToAppend;
				int iExecutionMode;
				unsigned long ulNumberOfValuesAppended = 0;

				n = sscanf(recvline, "%i %u %u %lu %i",
						&function,
						&uiBoardNumber,
						&uiPortNumber,
						&ulNumberOfValuesToAppend,
						&iExecutionMode);
				if(n != 5)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = 0;
				if(ulNumberOfValuesToAppend){
					pusBuffer = malloc(sizeof(unsigned short) * ulNumberOfValuesToAppend);
					if(pusBuffer == NULL){
						syslog(LOG_ERR, "dispatch(): Cannot allocate memory for data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					n = readn(connfd, pusBuffer, sizeof(unsigned short) * ulNumberOfValuesToAppend);
					if(n < 0){
						syslog(LOG_ERR, "dispatch(): Cannot read data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(pusBuffer);
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}
					else if(n == 0){ // EOF, Connection closed by remote host
						syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
						free(pusBuffer);
						return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
					}

					if((iReturnValue = me4000MultiSigAOAppendNewValues(
									uiBoardNumber,
									pusBuffer,
									ulNumberOfValuesToAppend,
									iExecutionMode,
									&ulNumberOfValuesAppended))){
						free(pusBuffer);
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					free(pusBuffer);
				}

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %lu", iReturnValue, ulNumberOfValuesAppended);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_MULTISIG_AO_CONFIG_ID:
			{
				unsigned int uiBoardNumber;
				unsigned char *pucDemuxChanList = NULL;
				unsigned int uiDemuxChanListCount;
				unsigned long ulTicks;
				int iTriggerMode;
				int iExtTriggerEdge;

				n = sscanf(recvline, "%i %u %u %lu %i %i",
						&function,
						&uiBoardNumber,
						&uiDemuxChanListCount,
						&ulTicks,
						&iTriggerMode,
						&iExtTriggerEdge);
				if(n != 6)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = ME4000_NO_ERROR;
				if(uiDemuxChanListCount){
					pucDemuxChanList = malloc(sizeof(unsigned char) * uiDemuxChanListCount);
					if(pucDemuxChanList == NULL){
						syslog(LOG_ERR, "dispatch(): Cannot allocate memory for data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					n = readn(connfd, pucDemuxChanList, sizeof(unsigned char) * uiDemuxChanListCount);
					if(n < 0){
						syslog(LOG_ERR, "dispatch(): Cannot read data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(pucDemuxChanList);
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}
					else if(n == 0){ // EOF, Connection closed by remote host
						syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
						free(pucDemuxChanList);
						return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
					}

					if((iReturnValue = me4000MultiSigAOConfig(
									uiBoardNumber,
									pucDemuxChanList,
									uiDemuxChanListCount,
									ulTicks,
									iTriggerMode,
									iExtTriggerEdge))){
						free(pucDemuxChanList);
						return sendReturnValue(connfd, iReturnValue);
					}

					free(pucDemuxChanList);
				}

				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AO_CONTINUOUS_ID:
			{
				unsigned int uiBoardNumber;
				unsigned short *pusBuffer = NULL;
				unsigned long ulDataCount;
				unsigned long ulTimeOutSeconds;
				unsigned long ulNumberOfValuesWritten = 0;

				n = sscanf(recvline, "%i %u %lu %lu",
						&function,
						&uiBoardNumber,
						&ulDataCount,
						&ulTimeOutSeconds);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = ME4000_NO_ERROR;
				if(ulDataCount){
					pusBuffer = malloc(sizeof(unsigned short) * ulDataCount);
					if(pusBuffer == NULL){
						syslog(LOG_ERR, "dispatch(): Cannot allocate memory for data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					n = readn(connfd, pusBuffer, sizeof(unsigned short) * ulDataCount);
					if(n < 0){
						syslog(LOG_ERR, "dispatch(): Cannot read data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(pusBuffer);
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}
					else if(n == 0){ // EOF, Connection closed by remote host
						syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
						free(pusBuffer);
						return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
					}

					if((iReturnValue = me4000MultiSigAOContinuous(
									uiBoardNumber,
									pusBuffer,
									ulDataCount,
									NULL,
									NULL,
									ulTimeOutSeconds,
									&ulNumberOfValuesWritten))){
						free(pusBuffer);
						return sendReturnValue(connfd, iReturnValue);
					}

					free(pusBuffer);
				}

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %lu", iReturnValue, ulNumberOfValuesWritten);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_MULTISIG_AO_GET_STATUS_ID:
			{
				unsigned int uiBoardNumber;
				int iWaitIdle;
				int iStatus;

				n = sscanf(recvline, "%i %u %i",
						&function,
						&uiBoardNumber,
						&iWaitIdle);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				if((iReturnValue = me4000MultiSigAOGetStatus(
								uiBoardNumber,
								iWaitIdle,
								&iStatus)))
					return sendReturnValue(connfd, iReturnValue);

				snprintf(returnline, ME4000_MSG_MAXBUF, "%i %i", iReturnValue, iStatus);
				return sendReply(connfd, returnline, ME4000_MSG_MAXBUF);
			}
		case ME4000_MULTISIG_AO_RESET_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u", &function, &uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigAOReset(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AO_SINGLE_ID:
			{
				unsigned int uiBoardNumber;
				unsigned int uiDemuxChannelNumber;
				int iTriggerMode;
				int iTriggerEdge;
				unsigned long ulTimeOutSeconds;
				unsigned short usValue;

				n = sscanf(recvline, "%i %u %u %i %i %lu %hu",
						&function,
						&uiBoardNumber,
						&uiDemuxChannelNumber,
						&iTriggerMode,
						&iTriggerEdge,
						&ulTimeOutSeconds,
						&usValue);
				if(n != 7)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigAOSingle(
						uiBoardNumber,
						uiDemuxChannelNumber,
						iTriggerMode,
						iTriggerEdge,
						ulTimeOutSeconds,
						usValue);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AO_START_ID:
			{
				unsigned int uiBoardNumber;

				n = sscanf(recvline, "%i %u",
						&function,
						&uiBoardNumber);
				if(n != 2)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigAOStart(uiBoardNumber);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AO_STOP_ID:
			{
				unsigned int uiBoardNumber;
				int iStopMode;

				n = sscanf(recvline, "%i %u %i",
						&function,
						&uiBoardNumber,
						&iStopMode);
				if(n != 3)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = me4000MultiSigAOStop(uiBoardNumber, iStopMode);
				return sendReturnValue(connfd, iReturnValue);
			}
		case ME4000_MULTISIG_AO_WRAPAROUND_ID:
			{
				unsigned int uiBoardNumber;
				unsigned short *pusBuffer = NULL;
				unsigned long ulDataCount;
				unsigned long ulTimeOutSeconds;

				n = sscanf(recvline, "%i %u %lu %lu",
						&function,
						&uiBoardNumber,
						&ulDataCount,
						&ulTimeOutSeconds);
				if(n != 4)
					return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);

				iReturnValue = ME4000_NO_ERROR;
				if(ulDataCount){
					pusBuffer = malloc(sizeof(unsigned short) * ulDataCount);
					if(pusBuffer == NULL){
						syslog(LOG_ERR, "dispatch(): Cannot allocate memory for data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}

					n = readn(connfd, pusBuffer, sizeof(unsigned short) * ulDataCount);
					if(n < 0){
						syslog(LOG_ERR, "dispatch(): Cannot read data\n");
						syslog(LOG_ERR, "dispatch(): %s", strerror(errno));
						free(pusBuffer);
						return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_SYSTEM);
					}
					else if(n == 0){ // EOF, Connection closed by remote host
						syslog(LOG_ERR, "dispatch(): Connection closed by remote host\n");
						free(pusBuffer);
						return ME4000_SRV_ERROR_NO_CONNECTION_CLOSED;
					}

					iReturnValue = me4000MultiSigAOWraparound(
							uiBoardNumber,
							pusBuffer,
							ulDataCount,
							ME4000_AO_WRAPAROUND_INFINITE,
							ME4000_AO_WRAPAROUND_ASYNCHRONOUS,
							ME4000_POINTER_NOT_USED,
							ME4000_POINTER_NOT_USED,
							ulTimeOutSeconds);

					free(pusBuffer);
				}

				return sendReturnValue(connfd, iReturnValue);
			}
		default:
			return sendReturnValue(connfd, ME4000_SRV_ERROR_NO_INVALID_REQUEST);
	}

	return 0;
}



/*===========================================================================
  Signal handler to catch all zombies
  =========================================================================*/

void sig_chld(int signo){
	pid_t pid;
	int stat;

	while((pid = waitpid(-1, &stat, WNOHANG)) > 0){
	}

	return;
}


/*===========================================================================
  Main function
  =========================================================================*/


int main(int argc, char **argv){
	int listenfd, connfd;
	socklen_t clilen;
	struct sockaddr_in cliaddr, servaddr;
	pid_t childpid;
	int err;

	err = daemon(0, 0);
	if(err){
		syslog(LOG_ERR, "In daemon(): %s", strerror(errno));
		return 1;
	}

	listenfd = socket(AF_INET, SOCK_STREAM, 0);
	if(listenfd < 0){
		syslog(LOG_ERR, "In socket():");
		syslog(LOG_ERR, "%s: %s", argv[0], strerror(errno));
		return 1;
	}

	memset(&servaddr, 0, sizeof(servaddr));
	servaddr.sin_family      = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port        = htons(ME4000_SERVER_PORT);

	if(bind(listenfd, (struct sockaddr *) &servaddr, sizeof(servaddr))){
		syslog(LOG_ERR, "In bind():");
		syslog(LOG_ERR, "%s: %s", argv[0], strerror(errno));
		return 1;
	}

	if(listen(listenfd, ME4000_LISTEN_QUEUE)){
		syslog(LOG_ERR, "In listen():");
		syslog(LOG_ERR, "%s: %s", argv[0], strerror(errno));
		return 1;
	}

	if(signal(SIGCHLD, sig_chld) == SIG_ERR){
		syslog(LOG_ERR, "In signal():");
		syslog(LOG_ERR, "%s: %s", argv[0], strerror(errno));
		return 1;
	}

	while(1){
		clilen = sizeof(cliaddr);
		connfd = accept(listenfd, (struct sockaddr *) &cliaddr, &clilen);
		if(connfd < 0){
			if(errno == EINTR){
				continue;
			}
			else{
				syslog(LOG_ERR, "In accept():");
				syslog(LOG_ERR, "%s: %s", argv[0], strerror(errno));
				return 1;
			}
		}

		childpid = fork();
		if(childpid < 0){
			syslog(LOG_ERR, "In fork():");
			syslog(LOG_ERR, "%s: %s", argv[0], strerror(errno));
			return 1;
		}
		else if(childpid == 0){
			if(close(listenfd)){
				syslog(LOG_ERR, "In close(listenfd):\n");
				syslog(LOG_ERR, "%s: %s", argv[0], strerror(errno));
				return 1;
			}
			while(1){ // Serve incoming requests
				err = dispatch(connfd);
				/* Suspend on unrecoverable errors */
				if((err == ME4000_SRV_ERROR_NO_SYSTEM) || (err == ME4000_SRV_ERROR_NO_CONNECTION_CLOSED)){
					break;
				}
			}
			return 1;
		}

		if(close(connfd)){ // Release the connection
			syslog(LOG_ERR, "In close(connfd):\n");
			syslog(LOG_ERR, "%s: %s", argv[0], strerror(errno));
			return 1;
		}
	}
}
