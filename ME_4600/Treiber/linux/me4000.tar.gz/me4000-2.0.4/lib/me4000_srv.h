#ifndef ME4000_SRV_H
#define ME4000_SRV_H

#define ME4000_SRV_VERSION					0x10000

#endif
