#!/bin/sh
#
# Check if qt 3 environment is present
#

echo "Checking QT3 environment ..."

if [ ! -d /usr/lib/qt3 ]; then
	echo "QT3 library seems not to be installed !"
	exit 1
fi

if [ ! -f /usr/lib/qt3/bin/moc ]; then
	echo "Meta Object Compiler not found !"
	exit 1
fi

if [ ! -d /usr/lib/qt3/include ]; then
	echo "QT3 include path not found !"
	exit 1;
fi

if [ ! -d /usr/lib/qt3/lib ]; then
	echo "QT3 library path not found !"
	exit 1;
fi

echo "Ceck for QT3 environment was successful"
