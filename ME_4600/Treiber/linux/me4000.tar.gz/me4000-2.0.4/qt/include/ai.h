#ifndef _AI_H_
#define _AI_H_

#include <qwidget.h>
#include <qpushbutton.h>
#include <qspinbox.h>
#include <qlabel.h>
#include <qslider.h>
#include <qmessagebox.h>

#include "../include/mytypes.h"
#include "../include/receiver.h"
#include "../include/xytracewidget.h"
#include "../include/devctrl.h"


typedef struct {
  unsigned int scanDivisor;
  unsigned int chanDivisor;
  int listCycles;
  double vOffset;
  double sOffset;
  double vPerDiv;
  double sPerDiv;
  chanListEntryVec chanList;
  measurePointArrayVec measureGraphVec;
} ai_info_type;


class AI : public QWidget {
  Q_OBJECT

  public:
    AI(DevCtrl *device, QWidget *parent = 0, const char *name = 0);
    ~AI();

  signals:
    void aiScanDivisor(int);
    void aiChanDivisor(int);
    void aiListCycles(int);
    void addToChanList(chanListEntry);
    void clearChanList();
    void startCon();

  private slots:
    void clearChanListBtnPushed();
    void showChanListBtnPushed();
    void scanBoxChanged(int);
    void chanBoxChanged(int);
    void listCyclesBoxChanged(int);
    void startConBtnPushed();
    void getEntry(chanListEntry);
    void uvOffsetBoxChanged(int);
    void usOffsetBoxChanged(int);
    void uvPerDivBoxChanged(int);
    void usPerDivBoxChanged(int);

  public slots:
    void printMeasurement(measurePointArrayVec);
    void setContext();

  private:
    QPushButton *_makeChanListEntryBtn;
    QPushButton *_clearChanListBtn;
    QPushButton *_showChanListBtn;
    QSpinBox *_chanBox;
    QSpinBox *_scanBox;
    QSpinBox *_listCyclesBox;
    QPushButton *_startConBtn;
    xyTraceWidget *_xyTrace;
    QSpinBox *_uvOffsetBox;
    QSpinBox *_usOffsetBox;
    QSpinBox *_uvPerDivBox;
    QSpinBox *_usPerDivBox;

    ai_info_type _info;
    DevCtrl *_device;
};

#endif
    
