#ifndef _AIMULTIPLE_H_
#define _AIMULTIPLE_H_

#include <qwidget.h>
#include <qpushbutton.h>
#include <qspinbox.h>
#include <qlabel.h>
#include <qslider.h>
#include <qmessagebox.h>

#include "../include/mytypes.h"
#include "../../libme2600.h"
#include "../include/receiver.h"
#include "../include/xytracewidget.h"


typedef struct {
  int scanDivisor;
  int chanDivisor;
  int listCycles;
  int uvOffset;
  int usOffset;
  int uvPerDiv;
  int usPerDiv;
  chanListEntry chanEntry;
  int chanListFlag;
  measurePointArrayVec measureGraphVec;
} aimultiple_info_type;


class AIMULTIPLE : public QWidget {
  Q_OBJECT

  public:
    AIMULTIPLE(QWidget *parent = 0, const char *name = 0);
    ~AIMULTIPLE();

  signals:
    void aiScanDivisor(int);
    void aiChanDivisor(int);
    void aiListCycles(int);
    void addToChanList(chanListEntry);
    void clearChanList();
    void startCon();

  private slots:
    void clearChanListBtnPushed();
    void showChanListBtnPushed();
    void chanBoxChanged(int);
    void listCyclesBoxChanged(int);
    void startConBtnPushed();
    void getEntry(chanListEntry);
    void uvOffsetBoxChanged(int);
    void usOffsetBoxChanged(int);
    void uvPerDivBoxChanged(int);
    void usPerDivBoxChanged(int);

  public slots:
    void printMeasurement(measurePointArrayVec);
    void setDeviceNo(int);
    void setContext();

  private:
    QPushButton *_makeChanListEntryBtn;
    QPushButton *_clearChanListBtn;
    QPushButton *_showChanEntryBtn;
    QSpinBox *_chanBox;
    QSpinBox *_listCyclesBox;
    QPushButton *_startConBtn;
    xyTraceWidget *_xyTrace;
    QSpinBox *_uvOffsetBox;
    QSpinBox *_usOffsetBox;
    QSpinBox *_uvPerDivBox;
    QSpinBox *_usPerDivBox;

    aimultiple_info_type _info[4];
    int _deviceNo;
};

#endif
    
