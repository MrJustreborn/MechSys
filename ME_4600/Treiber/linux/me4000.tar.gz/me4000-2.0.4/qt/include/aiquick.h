#ifndef _AIQUICK_H_
#define _AIQUICK_H_

#include <qwidget.h>
#include <qpushbutton.h>
#include <qspinbox.h>
#include <qlabel.h>
#include <qslider.h>
#include <qmessagebox.h>

#include "../include/mytypes.h"
#include "../../libme2600.h"
#include "../include/receiver.h"
#include "../include/xytracewidget.h"


typedef struct {
  int scanDivisor;
  int chanDivisor;
  int listCycles;
  int uvOffset;
  int usOffset;
  int uvPerDiv;
  int usPerDiv;
  chanListEntry chanEntry;
  int chanListFlag;
  measurePointArrayVec measureGraphVec;
} aiquick_info_type;


class AIQUICK : public QWidget {
  Q_OBJECT

  public:
    AIQUICK(QWidget *parent = 0, const char *name = 0);
    ~AIQUICK();

  signals:
    void aiChanDivisor(int);
    void addToChanList(chanListEntry);
    void clearChanList();
    void startCon();

  private slots:
    void clearChanListBtnPushed();
    void showChanListBtnPushed();
    void chanBoxChanged(int);
    void listCyclesBoxChanged(int);
    void startConBtnPushed();
    void getEntry(chanListEntry);
    void setContext();
    void uvOffsetBoxChanged(int);
    void usOffsetBoxChanged(int);
    void uvPerDivBoxChanged(int);
    void usPerDivBoxChanged(int);

  public slots:
    void printMeasurement(measurePointArrayVec);
    void setDeviceNo(int);

  private:
    QPushButton *_makeChanListEntryBtn;
    QPushButton *_clearChanListBtn;
    QPushButton *_showChanEntryBtn;
    QSpinBox *_chanBox;
    QSpinBox *_listCyclesBox;
    QPushButton *_startConBtn;
    xyTraceWidget *_xyTrace;
    QSpinBox *_uvOffsetBox;
    QSpinBox *_usOffsetBox;
    QSpinBox *_uvPerDivBox;
    QSpinBox *_usPerDivBox;

    aiquick_info_type _info[4];
    int _deviceNo;
};

#endif
    
