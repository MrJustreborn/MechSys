#ifndef _AISINGLE_H_
#define _AISINGLE_H_


#include <qobject.h>
#include <qdialog.h>
#include <qspinbox.h>
#include <qbuttongroup.h>
#include <qlabel.h>
#include <qradiobutton.h>
#include <qpushbutton.h>
#include <qlcdnumber.h>


typedef struct {
  int channel;
  int range;
  int mode;
  double value;
} aisingle_info_type;


class AISINGLE : public QWidget {
  Q_OBJECT

  public:
    AISINGLE(QWidget *parent = 0, const char *name = 0);

  private slots:
    void rangeBtnClicked(int);
    void modeBtnClicked(int);
    void channelBoxChanged(int);
    void startBtnClicked();
    void printMeasurement(int);
    void setDeviceNo(int);

  signals:
    void startCon(int, int);

  private:
    QSpinBox *_channelBox;
    QButtonGroup *_rangeBtn;
    QButtonGroup *_modeBtn;
    QPushButton *_startBtn;
    QLCDNumber *_valueLCD;
    aisingle_info_type _info[4];
    int _deviceNo;
};


#endif
