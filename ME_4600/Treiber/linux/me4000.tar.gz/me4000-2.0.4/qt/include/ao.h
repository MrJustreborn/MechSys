#ifndef _AO_H_
#define _AO_H_

#include <qradiobutton.h>
#include <qspinbox.h>
#include <qbuttongroup.h>
#include <qpushbutton.h>
#include <qlcdnumber.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qwidget.h>
#include <qpainter.h>
#include <qslider.h>
#include <math.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <vector.h>

#include "devctrl.h"



class SinusPushButton : public QPushButton{
  Q_OBJECT
  
  public:
    SinusPushButton(QWidget *, const char *);

  protected:
    void paintEvent(QPaintEvent *);
};



class RectPushButton : public QPushButton{
  Q_OBJECT

  public:
    RectPushButton(QWidget *, const char *);

  protected:
    void paintEvent(QPaintEvent *);
};



class TriPushButton : public QPushButton{
  Q_OBJECT
  
 public:
  TriPushButton(QWidget *, const char *);

 protected:
  void paintEvent(QPaintEvent *);
};



class Function {
  public:
    Function();
    ~Function();
    int setShape(int);
    int getShape();
    int setOffset(double);
    double getOffset();
    int setAmplitude(double);
    double getAmplitude();
    int setCount(int);
    int getCount();
    unsigned short *getData();

  private:
    int _shape;
    double _amplitude;
    double _offset;
    int _count;
    unsigned short *_data;
    int calcWave();
};



class AO : public QWidget {
  Q_OBJECT

  public:
    AO(DevCtrl *device, QWidget *parent = 0, const char *name = 0, int number = 0);
    ~AO();

  private slots:
    void startStopBtnToggled(bool);
    void shapeChanged(int);
    void amplitudeChanged(int);
    void offsetChanged(int);
    void freqFactorChanged(int id);
    void freqChanged(int value);


  private:
    DevCtrl *_device;
    Function _function;
    int _number;
    double _freqFactor;
    double _freq;
    QLCDNumber *_LCDFrequency;
    QLCDNumber *_LCDAmplitude;
    QPushButton *_PushButtonStartStop;
};

#endif
    
