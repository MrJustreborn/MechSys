#ifndef _DEVCTRL_H
#define _DEVCTRL_H

#include <qmessagebox.h>
#include <qstring.h>
#include <qobject.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <errno.h>

#include "../../me4000.h"


class DevCtrl : public QObject{
  Q_OBJECT


public:
  DevCtrl(QObject *parent = 0, const char *name = 0, int boardNo = 0);
  ~DevCtrl();

  int getAoCount();
  int getAiCount();
  int getDioCount();
  int getCntCount();

  int getDeviceId();

  int dioConfig(int port, int dir);
  int dioGetByte(int port, int *byte);
  int dioSetByte(int port, int byte);
  int dioReset();

  int aoStart(int ao);
  int aoStop(int ao);
  int aoTimerSetDivisor(int ao, int divisor);
  int aoWrite(int ao, unsigned short *buf, int count);

  int aiStart();
  int aiStop();
  int aiRead(signed short *buf, int count);
  int aiConfig(unsigned long *chanList, unsigned long chanListCount, unsigned long scanDivisor, unsigned long chanDivisor);

signals:

public slots:

private:
  int _fdAI;
  int _fdAO[4];
  int _fdDIO;
  int _fdCNT;

  int _aiCount;
  int _aoCount;
  int _dioCount;
  int _cntCount;

  int _deviceID;
};

#endif
