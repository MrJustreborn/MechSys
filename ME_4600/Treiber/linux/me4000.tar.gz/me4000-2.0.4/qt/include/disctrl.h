#ifndef DISCTRL_H
#define DISCTRL_H

#include <qobject.h>
#include <qpopupmenu.h>


class DisCtrl : public QObject {
  Q_OBJECT

  public:
    DisCtrl(QPopupMenu *menu, QObject *parent = 0, const char *name = 0);
    ~DisCtrl();

    void setIdPort(int id);
    void setIdAO(int id);
    void setIdAIScan(int id);
    void setIdAIMultiple(int id);
    void setIdAIQuick(int id);
    void setIdAISingle(int id);

  signals:
    void hidePort();
    void hideAO();
    void hideAIScan();
    void hideAIMultiple();
    void hideAIQuick();
    void hideAISingle();
   
    void showPort();
    void showAO();
    void showAIScan();
    void showAIMultiple();
    void showAIQuick();
    void showAISingle();

  public slots:
    void setBoardVersion(int);

    void setPort();
    void setAO();
    void setAIScan();
    void setAIMultiple();
    void setAIQuick();
    void setAISingle();

  private:
    QPopupMenu *_menu;

    int _boardVersion;
    
    int _idPort;
    int _idAO;
    int _idAIScan;
    int _idAIMultiple;
    int _idAIQuick;
    int _idAISingle;
};

#endif



















