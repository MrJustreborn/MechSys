#ifndef _MYDIALOG_H_
#define _MYDIALOG_H_


#include <qobject.h>
#include <qdialog.h>
#include <qspinbox.h>
#include <qbuttongroup.h>
#include <qlabel.h>
#include <qradiobutton.h>
#include <qpushbutton.h>

#include "../../me4000.h"


class MyDialog : public QDialog {
  Q_OBJECT

  public:
    MyDialog();

    int getChannel();
    int getRange();
    int getMode();

  private:
    QSpinBox *_channelBox;
    QButtonGroup *_rangeBtn;
    QButtonGroup *_modeBtn;
};


#endif
