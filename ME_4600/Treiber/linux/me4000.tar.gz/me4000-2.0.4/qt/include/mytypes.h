#ifndef MYTYPES_H
#define MYTYPES_H

#include <vector.h>
#include <qarray.h>
#include <qpointarray.h>


typedef struct {
  int channel;
  int range;
  int mode;
} chanListEntry;


typedef vector<chanListEntry> chanListEntryVec;


typedef struct {
  double voltage;
  double time;
} measurePoint;


typedef vector<measurePoint> measurePointArray;


typedef vector<measurePointArray> measurePointArrayVec;

#endif
