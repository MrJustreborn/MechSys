#ifndef _PORT_H_
#define _PORT_H_

#include <qradiobutton.h>
#include <qcheckbox.h>
#include <qbuttongroup.h>
#include <qpushbutton.h>
#include <qlcdnumber.h>
#include <qwidget.h>

#include "../include/devctrl.h"

class Port : public QWidget {
  Q_OBJECT

  public:
    Port(DevCtrl *device, QWidget *parent = 0, const char *name = 0, 
	int number = 0, int dir = 0, int outByte = 0, int inByte = 0);
    ~Port();

  private slots:
    void portDirBtnGrpClicked(int);
    void portReadBtnClicked();
    void portWriteBtnGrpClicked(int);

  private:
    QButtonGroup *portDirBtnGrp;
    QPushButton *portReadBtn;
    QLCDNumber *portInByteLCD;
    QButtonGroup *portWriteBtnGrp;

    int _number;	// Port number
    int _dir;		// Port direction 0 = input, 1 = output
    int _outByte;	// Last written Byte
    int _inByte;	// Last read byte

    DevCtrl *_device;	// ME-4000 device object
};

#endif

