#ifndef _RECEIVER_H_
#define _RECEIVER_H_


#include <qobject.h>
#include <qdialog.h>
#include "mytypes.h"


class Receiver : public QObject {
  Q_OBJECT

  public:
    Receiver();

  public slots:
    void showDialog();

  signals:
    void chanLstEntry(chanListEntry);
};


#endif
