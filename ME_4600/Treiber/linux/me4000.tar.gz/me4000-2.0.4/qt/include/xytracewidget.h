#ifndef XYTRACEWIDGET_H
#define XYTRACEWIDGET_H

/* Qt includes */
#include <qpainter.h>
#include <qcolor.h>
#include <qpen.h>
#include <qpoint.h>
#include <qbrush.h>

#include <qwidget.h>
#include <qpointarray.h>
#include <qevent.h>
#include <vector.h>
#include "mytypes.h"


typedef vector<QPointArray> paintPointArrayVec;


class xyTraceWidget : public QWidget {
  Q_OBJECT

  public:
    /* Constructors */
    xyTraceWidget(QWidget *parent = 0, const char *name = 0, WFlags f = 0);
    xyTraceWidget(measurePointArrayVec &measure,
		  double vPerDiv = 1.0, 
		  double sPerDiv = 1.0, 
		  double vOffset = 0.0,
		  double sOffset = 0.0,
		  QWidget *parent = 0, 
		  const char *name = 0, 
		  WFlags f = 0);

    /* Destructor */
    ~xyTraceWidget();

    /* Inline functions */
    double getuvPerDiv(){
      return _vPerDiv;
    }
    
    double getusPerDiv(){
      return _sPerDiv;
    }
    
    double getuvOffset(){
      return _vOffset;
    }

    double getusOffset(){
      return _vOffset;
    }
    
   
  public slots:
    void setMeasureGraphVec(measurePointArrayVec &);
    void setvPerDiv(double);
    void setsPerDiv(double);
    void setvOffset(double);
    void setsOffset(double);

  protected:
    void paintEvent(QPaintEvent *);

  private:
    bool calcPaintGraphVec( measurePointArrayVec &, 
			    double vPerDiv = 1.0,
			    double sPerDiv = 1.0,
			    double vOffset = 0.0, 
			    double sOffset = 0.0);
    void paint();

    measurePointArrayVec _measureGraphVec;
    paintPointArrayVec _paintGraphVec;
    double _vPerDiv;
    double _sPerDiv;
    double _vOffset;
    double _sOffset;
};

#endif









