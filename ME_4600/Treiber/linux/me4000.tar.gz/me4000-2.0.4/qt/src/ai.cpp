#include "../include/ai.h"


AI::AI(DevCtrl *device, QWidget *parent, const char *name)
  : QWidget(parent, name)
{
  QString text;

  _device = device;

  _makeChanListEntryBtn = new QPushButton("Make Channel List Entry", this);
  _makeChanListEntryBtn->move(20, 20);
  _makeChanListEntryBtn->resize(200, 30);

  _clearChanListBtn = new QPushButton("Clear Channel List", this);
  _clearChanListBtn->move(20, 70);
  _clearChanListBtn->resize(200, 30);

  _showChanListBtn = new QPushButton("Show Channel List", this);
  _showChanListBtn->move(20, 120);
  _showChanListBtn->resize(200, 30);

  QLabel *scanLbl = new QLabel("Select divisor of Scan Timer :", this);
  scanLbl->move(20, 170);
  scanLbl->resize(200, 30);

  _scanBox = new QSpinBox(0, 0x7FFFFFFF, 1, this);
  _scanBox->move(20, 200);
  _scanBox->resize(200, 30);

  QLabel *chanLbl = new QLabel("Select divisor of Chan Timer :", this);
  chanLbl->move(20, 250);
  chanLbl->resize(200, 30);

  _chanBox = new QSpinBox(66, 0x7FFF, 1, this);
  _chanBox->move(20, 280);
  _chanBox->resize(200, 30);

  QLabel *lbl = new QLabel("Select count of cycles :", this);
  lbl->move(20, 330);
  lbl->resize(200, 30);

  _listCyclesBox = new QSpinBox(1, 0x7FFFFFFF, 1, this);
  _listCyclesBox->move(20, 360);
  _listCyclesBox->resize(200, 30);

  _startConBtn = new QPushButton("Start AI Scan", this);
  _startConBtn->move(20, 490);
  _startConBtn->resize(200, 30);

  _xyTrace = new xyTraceWidget(this);
  _xyTrace->move(250, 20);

  QLabel *uvLabel = new QLabel("Voltage Offset (uV)", this);
  uvLabel->move(250, 330);
  uvLabel->resize(300, 20);
  uvLabel->setAlignment(Qt::AlignVCenter | Qt::AlignHCenter | Qt::ExpandTabs);

  _uvOffsetBox = new QSpinBox(-10000000, 10000000, 1000000, this);
  _uvOffsetBox->setValue(0);
  _uvOffsetBox->move(250, 350);
  _uvOffsetBox->resize(300, 20);

  QLabel *usLabel = new QLabel("Time Offset (us)", this);
  usLabel->move(250, 380);
  usLabel->resize(300, 20);
  usLabel->setAlignment(Qt::AlignVCenter | Qt::AlignHCenter | Qt::ExpandTabs);

  _usOffsetBox = new QSpinBox(0, 10000000, 1000, this);
  _usOffsetBox->move(250, 400);
  _usOffsetBox->resize(300, 20);

  QLabel *uvPerDivLabel = new QLabel("uV/DIV", this);
  uvPerDivLabel->move(250, 430);
  uvPerDivLabel->resize(300, 20);
  uvPerDivLabel->setAlignment(Qt::AlignVCenter | Qt::AlignHCenter | Qt::ExpandTabs);

  _uvPerDivBox = new QSpinBox(1, 5000000, 1000000, this);
  _uvPerDivBox->setValue(1000000);
  _uvPerDivBox->move(250, 450);
  _uvPerDivBox->resize(300, 20);

  QLabel *usPerDivLabel = new QLabel("us/DIV", this);
  usPerDivLabel->move(250, 480);
  usPerDivLabel->resize(300, 20);
  usPerDivLabel->setAlignment(Qt::AlignVCenter | Qt::AlignHCenter | Qt::ExpandTabs);

  _usPerDivBox = new QSpinBox(1, 1000000, 1000, this);
  _usPerDivBox->setValue(1000000);
  _usPerDivBox->move(250, 500);
  _usPerDivBox->resize(300, 20);

  /* Channel list dialog */
  Receiver *rcvr = new Receiver();
  rcvr->connect(_makeChanListEntryBtn, SIGNAL(clicked()), rcvr, SLOT(showDialog()));
  rcvr->connect(rcvr, SIGNAL(chanLstEntry(chanListEntry)), this, SLOT(getEntry(chanListEntry)));

  /* Internal Connections */
  this->connect(_clearChanListBtn, SIGNAL(clicked()), this, SLOT(clearChanListBtnPushed()));
  this->connect(_showChanListBtn, SIGNAL(clicked()), this, SLOT(showChanListBtnPushed()));
  this->connect(_scanBox, SIGNAL(valueChanged(int)), this, SLOT(scanBoxChanged(int)));
  this->connect(_chanBox, SIGNAL(valueChanged(int)), this, SLOT(chanBoxChanged(int)));
  this->connect(_listCyclesBox, SIGNAL(valueChanged(int)), this, SLOT(listCyclesBoxChanged(int)));
  this->connect(_startConBtn, SIGNAL(clicked()), this, SLOT(startConBtnPushed()));

  _uvOffsetBox->connect(_uvOffsetBox, SIGNAL(valueChanged(int)), this, SLOT(uvOffsetBoxChanged(int)));
  _usOffsetBox->connect(_usOffsetBox, SIGNAL(valueChanged(int)), this, SLOT(usOffsetBoxChanged(int)));
  _uvPerDivBox->connect(_uvPerDivBox, SIGNAL(valueChanged(int)), this, SLOT(uvPerDivBoxChanged(int)));
  _usPerDivBox->connect(_usPerDivBox, SIGNAL(valueChanged(int)), this, SLOT(usPerDivBoxChanged(int)));

  /* Initialize global _info struct */
  _info.scanDivisor = 0;
  _info.chanDivisor = 66;
  _info.listCycles = 1;
  _info.vOffset = 0.0;
  _info.sOffset = 0.0;
  _info.vPerDiv = 1.0;
  _info.sPerDiv = 1.0;
}


AI::~AI(){}


void AI::clearChanListBtnPushed(){
  _info.chanList.clear();
}


void AI::getEntry(chanListEntry entry){
  _info.chanList.push_back(entry);
}


void AI::showChanListBtnPushed(){
  chanListEntryVec::const_iterator pos;
  int i;
  QString line;
  QString lst;

  for(pos = _info.chanList.begin(), i = 0; pos < _info.chanList.end(); pos++, i++){
    line.sprintf("Entry %d: Channel = 0x%X Range = 0x%X Mode = 0x%X\n", i, pos->channel, pos->range, pos->mode);
    lst.append(line);
  }
  if(i == 0){
    lst.append("Channel list is empty\n");
  }

  QMessageBox::information(0, "Channel List", lst);
}


void AI::scanBoxChanged(int divisor){
  _info.scanDivisor = divisor;
}


void AI::chanBoxChanged(int divisor){
  _info.chanDivisor = divisor;
}


void AI::uvOffsetBoxChanged(int offset){
  _info.vOffset = ((double) offset / 1.0E6);
  _xyTrace->setvOffset(_info.vOffset);
}


void AI::usOffsetBoxChanged(int offset){
  _info.sOffset = ((double) offset / 1.0E6);
  _xyTrace->setsOffset(_info.sOffset);
}


void AI::uvPerDivBoxChanged(int value){
  _info.vPerDiv = ((double) value / 1.0E6);
  _xyTrace->setvPerDiv(_info.vPerDiv);
}


void AI::usPerDivBoxChanged(int value){
  _info.sPerDiv = ((double) value / 1.0E6);
  _xyTrace->setsPerDiv(_info.sPerDiv);
}


void AI::listCyclesBoxChanged(int cycles){
  _info.listCycles = cycles;
}


void AI::startConBtnPushed(){
  int err;
  int i, j;
  unsigned long *lst;
  signed short *data;
  double volts, time;
  int cnt[32];

  lst = (unsigned long *) malloc(_info.chanList.size() * sizeof(unsigned int));
  for(i = 0; i < _info.chanList.size(); i++){
    lst[i] = _info.chanList[i].channel | _info.chanList[i].mode | _info.chanList[i].range;
  }
  lst[_info.chanList.size() - 1] |= ME4000_AI_LIST_LAST_ENTRY;

  err = _device->aiConfig(lst, _info.chanList.size(), _info.scanDivisor, _info.chanDivisor);
  if(err) {
    free(lst);
    return;
  }

  err = _device->aiStart();
  if(err) {
    free(lst);
    return;
  }

  data = (signed short *) malloc(_info.chanList.size() * _info.listCycles * sizeof(signed short));
  err == _device->aiRead(data, _info.chanList.size() * _info.listCycles);
  if(err) {
    free(data);
    free(lst);
    return;
  }

  err = _device->aiStop();
  if(err) {
    free(data);
    free(lst);
    return;
  }

  /* Define iterators */
  chanListEntryVec::const_iterator itChanList;
  measurePointArrayVec::const_iterator itGraphVec;
  measurePointArray::const_iterator itGraph;

  /* Determine different number of channels in channel list */
  int chanCount[32];
  memset(chanCount, 0, sizeof(int) * 32);

  for(itChanList = _info.chanList.begin(); itChanList < _info.chanList.end(); itChanList++){
    chanCount[itChanList->channel]++;
  }

  /* Object to hold the measurement results for each channel */
  measurePointArrayVec graphVec;

  /* Determine size of each graph and add to graphVec */
  for(i = 0; i < 32; i++){
    int size = chanCount[i] * _info.listCycles;
    measurePointArray graph(size);
    graphVec.push_back(graph);
  }

  memset(cnt, 0, sizeof(int) * 32);
  for(i = 0; i < _info.listCycles; i++){
    for(itChanList = _info.chanList.begin(), j = 0; itChanList < _info.chanList.end(); itChanList++, j++){
      switch(itChanList->range){
	case ME4000_AI_LIST_RANGE_BIPOLAR_10:
	  volts = 20.0 / 65535.0 * data[i * _info.chanList.size() + j];
	  break;
	case ME4000_AI_LIST_RANGE_BIPOLAR_2_5:
	  volts = 5.0 / 65535.0 * data[i * _info.chanList.size() + j];
	  break;
	case ME4000_AI_LIST_RANGE_UNIPOLAR_10:
	  volts = 10.0 / 65535.0 * data[i * _info.chanList.size() + j] + 5.0;
	  break;
	case ME4000_AI_LIST_RANGE_UNIPOLAR_2_5:
	  volts = 2.5 / 65535.0 * data[i * _info.chanList.size() + j] + 1.25;
	  break;
      }

      if(_info.scanDivisor){
	time = ((double) _info.scanDivisor / 33.0E6 * (double) i + (double) _info.chanDivisor / 33.0E6 * (double) j);
      }
      else {
	time = ((double) _info.chanList.size() * _info.chanDivisor / 33.0E6 * (double) i + (double) _info.chanDivisor / 33.0E6 * (double) j);
      }

      graphVec[itChanList->channel][cnt[itChanList->channel]].voltage = volts;
      graphVec[itChanList->channel][cnt[itChanList->channel]].time = time;
      cnt[itChanList->channel]++;
    }
  }

  _xyTrace->setMeasureGraphVec(graphVec);

  free(data);
  free(lst);
}


void AI::printMeasurement(measurePointArrayVec graphVec){
  _info.measureGraphVec = graphVec;
  _xyTrace->setMeasureGraphVec(graphVec);
}


void AI::setContext(){
  emit aiChanDivisor(_info.chanDivisor);
  emit aiScanDivisor(_info.scanDivisor);
  emit aiListCycles(_info.listCycles);

  emit clearChanList();
  chanListEntryVec::const_iterator pos;
  for(pos = _info.chanList.begin(); pos < _info.chanList.end(); pos++){
    emit addToChanList(*pos);
  }
}


