#include "../include/aimultiple.h"
#include <stdio.h>
#undef DEBUG


AIMULTIPLE::AIMULTIPLE(QWidget *parent = 0, const char *name = 0)
  : QWidget(parent, name)
{
  _makeChanListEntryBtn = new QPushButton("Make Channel List Entry", this);
  _makeChanListEntryBtn->move(20, 20);
  _makeChanListEntryBtn->resize(200, 30);

  _clearChanListBtn = new QPushButton("Clear Channel List", this);
  _clearChanListBtn->move(20, 70);
  _clearChanListBtn->resize(200, 30);

  _showChanEntryBtn = new QPushButton("Show Channel Entry", this);
  _showChanEntryBtn->move(20, 120);
  _showChanEntryBtn->resize(200, 30);

  QLabel *chanLbl = new QLabel("Select divisor of Chan Timer :", this);
  chanLbl->move(20, 250);
  chanLbl->resize(200, 30);

  _chanBox = new QSpinBox(10, 0x7FFF, 1, this);
  _chanBox->move(20, 280);
  _chanBox->resize(200, 30);

  QLabel *lbl = new QLabel("Select count of cycles :", this);
  lbl->move(20, 330);
  lbl->resize(200, 30);

  _listCyclesBox = new QSpinBox(1, 0x7FFFFFFF, 1, this);
  _listCyclesBox->move(20, 360);
  _listCyclesBox->resize(200, 30);

  _startConBtn = new QPushButton("Start AI Multiple", this);
  _startConBtn->move(20, 490);
  _startConBtn->resize(200, 30);

  _xyTrace = new xyTraceWidget(this);
  _xyTrace->move(250, 20);

  QLabel *uvLabel = new QLabel("Voltage Offset (uV)", this);
  uvLabel->move(250, 330);
  uvLabel->resize(300, 20);
  uvLabel->setAlignment(Qt::AlignVCenter | Qt::AlignHCenter | Qt::ExpandTabs);

  _uvOffsetBox = new QSpinBox(-10000000, 10000000, 1000000, this);
  _uvOffsetBox->setValue(0);
  _uvOffsetBox->move(250, 350);
  _uvOffsetBox->resize(300, 20);

  QLabel *usLabel = new QLabel("Time Offset (us)", this);
  usLabel->move(250, 380);
  usLabel->resize(300, 20);
  usLabel->setAlignment(Qt::AlignVCenter | Qt::AlignHCenter | Qt::ExpandTabs);

  _usOffsetBox = new QSpinBox(0, 10000000, 1000, this);
  _usOffsetBox->move(250, 400);
  _usOffsetBox->resize(300, 20);

  QLabel *uvPerDivLabel = new QLabel("uV/DIV", this);
  uvPerDivLabel->move(250, 430);
  uvPerDivLabel->resize(300, 20);
  uvPerDivLabel->setAlignment(Qt::AlignVCenter | Qt::AlignHCenter | Qt::ExpandTabs);

  _uvPerDivBox = new QSpinBox(1, 5000000, 1000000, this);
  _uvPerDivBox->setValue(1000000);
  _uvPerDivBox->move(250, 450);
  _uvPerDivBox->resize(300, 20);

  QLabel *usPerDivLabel = new QLabel("us/DIV", this);
  usPerDivLabel->move(250, 480);
  usPerDivLabel->resize(300, 20);
  usPerDivLabel->setAlignment(Qt::AlignVCenter | Qt::AlignHCenter | Qt::ExpandTabs);

  _usPerDivBox = new QSpinBox(1, 1000000, 1000, this);
  _usPerDivBox->setValue(1000000);
  _usPerDivBox->move(250, 500);
  _usPerDivBox->resize(300, 20);

  /* Channel list dialog */
  Receiver *rcvr = new Receiver();
  rcvr->connect(_makeChanListEntryBtn, SIGNAL(clicked()), rcvr, SLOT(showDialog()));
  rcvr->connect(rcvr, SIGNAL(chanLstEntry(chanListEntry)), this, SLOT(getEntry(chanListEntry)));

  /* Internal Connections */
  this->connect(_clearChanListBtn, SIGNAL(clicked()), this, SLOT(clearChanListBtnPushed()));
  this->connect(_showChanEntryBtn, SIGNAL(clicked()), this, SLOT(showChanListBtnPushed()));
  this->connect(_chanBox, SIGNAL(valueChanged(int)), this, SLOT(chanBoxChanged(int)));
  this->connect(_listCyclesBox, SIGNAL(valueChanged(int)), this, SLOT(listCyclesBoxChanged(int)));
  this->connect(_startConBtn, SIGNAL(clicked()), this, SLOT(startConBtnPushed()));

  _uvOffsetBox->connect(_uvOffsetBox, SIGNAL(valueChanged(int)), _xyTrace, SLOT(setuvOffset(int)));
  _usOffsetBox->connect(_usOffsetBox, SIGNAL(valueChanged(int)), _xyTrace, SLOT(setusOffset(int)));
  _uvPerDivBox->connect(_uvPerDivBox, SIGNAL(valueChanged(int)), _xyTrace, SLOT(setuvPerDiv(int)));
  _usPerDivBox->connect(_usPerDivBox, SIGNAL(valueChanged(int)), _xyTrace, SLOT(setusPerDiv(int)));

  _uvOffsetBox->connect(_uvOffsetBox, SIGNAL(valueChanged(int)), this, SLOT(uvOffsetBoxChanged(int)));
  _usOffsetBox->connect(_usOffsetBox, SIGNAL(valueChanged(int)), this, SLOT(usOffsetBoxChanged(int)));
  _uvPerDivBox->connect(_uvPerDivBox, SIGNAL(valueChanged(int)), this, SLOT(uvPerDivBoxChanged(int)));
  _usPerDivBox->connect(_usPerDivBox, SIGNAL(valueChanged(int)), this, SLOT(usPerDivBoxChanged(int)));

  /* Start with board 0 */
  _deviceNo = 0;

  /* Initialize global _info struct */
  for(int i = 0; i < 4; i++){
    _info[i].chanDivisor = 10;
    _info[i].listCycles = 1;
    _info[i].uvOffset = 0;
    _info[i].usOffset = 0;
    _info[i].uvPerDiv = 1000000;
    _info[i].usPerDiv = 1000000;
    _info[i].chanListFlag = 0;
  }
}


AIMULTIPLE::~AIMULTIPLE(){}


void AIMULTIPLE::clearChanListBtnPushed(){
  _info[_deviceNo].chanListFlag = 0;
  emit clearChanList();
}


void AIMULTIPLE::getEntry(chanListEntry entry){
  _info[_deviceNo].chanListFlag = 1;
  _info[_deviceNo].chanEntry = entry;
  emit clearChanList();
  emit addToChanList(entry);
}


void AIMULTIPLE::showChanListBtnPushed(){
  char str[100];
  QString lst;

  if(_info[_deviceNo].chanListFlag == 0){
    lst.append("Channel list is empty\n");
  }
  else{
    sprintf(str, "Entry : Channel = 0x%X Range = 0x%X Mode = 0x%X\n", _info[_deviceNo].chanEntry.channel, 
	_info[_deviceNo].chanEntry.range, _info[_deviceNo].chanEntry.mode);
    lst.append(str);
  }

  QMessageBox::information(0, "Channel List", lst);
}


void AIMULTIPLE::chanBoxChanged(int divisor){
  emit aiScanDivisor(divisor);
  emit aiChanDivisor(divisor);
  _info[_deviceNo].chanDivisor = divisor;
}


void AIMULTIPLE::listCyclesBoxChanged(int cycles){
  _info[_deviceNo].listCycles = cycles;
  emit aiListCycles(cycles);
}


void AIMULTIPLE::uvOffsetBoxChanged(int offset){
  _info[_deviceNo].uvOffset = offset;
}


void AIMULTIPLE::usOffsetBoxChanged(int offset){
  _info[_deviceNo].usOffset = offset;
}


void AIMULTIPLE::uvPerDivBoxChanged(int value){
  _info[_deviceNo].uvPerDiv = value;
}


void AIMULTIPLE::usPerDivBoxChanged(int value){
  _info[_deviceNo].usPerDiv = value;
}


void AIMULTIPLE::startConBtnPushed(){
  emit startCon();
}


void AIMULTIPLE::printMeasurement(measurePointArrayVec graphVec){
#ifdef DEBUG
  int i, j;
  measurePointArrayVec::const_iterator itGraphVec;
  measurePointArray::const_iterator itGraph;

  for(itGraphVec = graphVec.begin(), i = 0; itGraphVec < graphVec.end(); itGraphVec++, i++){
    for(itGraph = itGraphVec->begin(), j = 0; itGraph < itGraphVec->end(); itGraph++, j++){
      printf("Graph %d Point %d Voltage = %f Time = %f\n", i, j, itGraph->voltage, itGraph->time);
    }
  }
#endif

  _info[_deviceNo].measureGraphVec = graphVec;
  _xyTrace->setMeasureGraphVec(graphVec);
}


void AIMULTIPLE::setDeviceNo(int no){
  _deviceNo = no;
  _chanBox->setValue(_info[_deviceNo].chanDivisor);
  _listCyclesBox->setValue(_info[_deviceNo].listCycles);
  _uvOffsetBox->setValue(_info[_deviceNo].uvOffset);
  _usOffsetBox->setValue(_info[_deviceNo].usOffset);
  _uvPerDivBox->setValue(_info[_deviceNo].uvPerDiv);
  _usPerDivBox->setValue(_info[_deviceNo].usPerDiv);

  _xyTrace->setuvOffset(_info[_deviceNo].uvOffset);
  _xyTrace->setusOffset(_info[_deviceNo].usOffset);
  _xyTrace->setuvPerDiv(_info[_deviceNo].uvPerDiv);
  _xyTrace->setusPerDiv(_info[_deviceNo].usPerDiv);

  printMeasurement(_info[_deviceNo].measureGraphVec);
}


void AIMULTIPLE::setContext(){
  emit aiScanDivisor(_info[_deviceNo].chanDivisor);
  emit aiChanDivisor(_info[_deviceNo].chanDivisor);
  emit aiListCycles(_info[_deviceNo].listCycles);
  emit clearChanList();
  if(_info[_deviceNo].chanListFlag = 1){
    emit addToChanList(_info[_deviceNo].chanEntry);
  }
}


