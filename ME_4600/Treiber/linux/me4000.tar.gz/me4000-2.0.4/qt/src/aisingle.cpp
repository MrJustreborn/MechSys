#include "../include/aisingle.h"
#include "../../libme2600.h"
#include <stdio.h>

AISINGLE::AISINGLE(QWidget *parent = 0, const char *name = 0) : 
  QWidget(parent, name)
{
  QLabel *lbl = new QLabel("Select the ADC", this);
  lbl->move(20, 20);
  lbl->resize(200, 30);

  _channelBox = new QSpinBox(0, 15, 1, this);
  _channelBox->move(20, 50);
  _channelBox->resize(200, 30);

  _rangeBtn = new QButtonGroup("Select the output range", this, "Range Buttons");
  _rangeBtn->move(250, 30);
  _rangeBtn->resize(200, 300);

  QRadioButton *rangeMinus10 = new QRadioButton("-10 .. 10V", _rangeBtn, "Minus 10");
  QRadioButton *rangeMinus05 = new QRadioButton("-5 .. 5V", _rangeBtn, "Minus 05");
  QRadioButton *rangeMinus02 = new QRadioButton("-2.5 .. 2.5V", _rangeBtn, "Minus 02");
  QRadioButton *rangeMinus01 = new QRadioButton("-1.25 .. 1.25V", _rangeBtn, "Minus 01");
  QRadioButton *rangePlus10  = new QRadioButton("0 .. 10V", _rangeBtn, "Plus  10");
  QRadioButton *rangePlus05  = new QRadioButton("0 .. 5V", _rangeBtn, "Plus  05");
  QRadioButton *rangePlus02  = new QRadioButton("0 .. 2.5V", _rangeBtn, "Plus  02");
  QRadioButton *rangePlus01  = new QRadioButton("0 .. 1.25V", _rangeBtn, "Plus  01");

  _rangeBtn->insert(rangeMinus10, AI2600_MINUS_10);
  _rangeBtn->insert(rangeMinus05, AI2600_MINUS_5);
  _rangeBtn->insert(rangeMinus02, AI2600_MINUS_2);
  _rangeBtn->insert(rangeMinus01, AI2600_MINUS_1);
  _rangeBtn->insert(rangePlus10, AI2600_PLUS_10);
  _rangeBtn->insert(rangePlus05, AI2600_PLUS_5);
  _rangeBtn->insert(rangePlus02, AI2600_PLUS_2);
  _rangeBtn->insert(rangePlus01, AI2600_PLUS_1);

  rangeMinus10->move(10, 30);
  rangeMinus05->move(10, 60);
  rangeMinus02->move(10, 90);
  rangeMinus01->move(10, 120);
  rangePlus10->move(10, 150);
  rangePlus05->move(10, 180);
  rangePlus02->move(10, 210);
  rangePlus01->move(10, 240);

  _rangeBtn->setButton(AI2600_PLUS_10);

  _modeBtn = new QButtonGroup("Select the output mode", this, "Mode Buttons");
  _modeBtn->move(20, 100);
  _modeBtn->resize(200, 120);

  QRadioButton *modeSingle = new QRadioButton("Single Ended", _modeBtn, "Single ended");
  QRadioButton *modeDiff = new QRadioButton("Differential", _modeBtn, "Differential");

  _modeBtn->insert(modeSingle, AI2600_SINGLE_ENDED);
  _modeBtn->insert(modeDiff, AI2600_DIFFERENTIAL);

  modeSingle->move(10, 30);
  modeDiff->move(10, 60);

  _modeBtn->setButton(AI2600_SINGLE_ENDED);

  QLabel *valLabel = new QLabel("Voltage/V:", this);
  valLabel->resize(200, 30);
  valLabel->move(20, 220);

  _valueLCD = new QLCDNumber(7, this);
  _valueLCD->setMode(QLCDNumber::DEC);
  _valueLCD->resize(200, 30);
  _valueLCD->move(20, 250);
  
  _startBtn = new QPushButton("Start AI Single", this);
  _startBtn->resize(200, 30);
  _startBtn->move(20, 300);
  _startBtn->connect(_startBtn, SIGNAL(clicked()), this, SLOT(startBtnClicked()));

  /* Start with board 0 */
  _deviceNo = 0;

  for(int i = 0; i < 4; i++){
    _info[i].channel = 0;
    _info[i].range = AI2600_PLUS_10;
    _info[i].mode = AI2600_SINGLE_ENDED;
    _info[i].value = 0;
  }

  /* Internal connections */
  _rangeBtn->connect(_rangeBtn, SIGNAL(clicked(int)), this, SLOT(rangeBtnClicked(int)));
  _modeBtn->connect(_modeBtn, SIGNAL(clicked(int)), this, SLOT(modeBtnClicked(int)));
  _channelBox->connect(_channelBox, SIGNAL(valueChanged(int)), this, SLOT(channelBoxChanged(int)));
}


void AISINGLE::rangeBtnClicked(int range){
  _info[_deviceNo].range = range;
}


void AISINGLE::modeBtnClicked(int mode){
  _info[_deviceNo].mode = mode;
}


void AISINGLE::channelBoxChanged(int channel){
  _info[_deviceNo].channel = channel;
}


void AISINGLE::startBtnClicked(){
  emit startCon(_channelBox->value(), _modeBtn->id(_modeBtn->selected()) + _rangeBtn->id(_rangeBtn->selected()));

}


void AISINGLE::setDeviceNo(int no){
  _deviceNo = no;
  _rangeBtn->setButton(_info[_deviceNo].range);
  _modeBtn->setButton(_info[_deviceNo].mode);
  _channelBox->setValue(_info[_deviceNo].channel);
  _valueLCD->display(_info[_deviceNo].value);
}


void AISINGLE::printMeasurement(int value){
  double volts;

  switch(_rangeBtn->id(_rangeBtn->selected())){
    case AI2600_MINUS_10:
      volts = 20.0 / 4095.0 * (double) value - 10.0;
      break;
    case AI2600_MINUS_5:
      volts = 10.0 / 4095.0 * (double) value - 5.0;
      break;
    case AI2600_MINUS_2:
      volts = 5.0 / 4095.0 * (double) value - 2.5;
      break;
    case AI2600_MINUS_1:
      volts = 2.5 / 4095.0 * (double) value - 1.25;
      break;
    case AI2600_PLUS_10:
      volts = 10.0 / 4095.0 * (double) value;
      break;
    case AI2600_PLUS_5:
      volts = 5.0 / 4095.0 * (double) value;
      break;
    case AI2600_PLUS_2:
      volts = 2.5 / 4095.0 * (double) value; 
      break;
    case AI2600_PLUS_1:
      volts = 1.25 / 4095.0 * (double) value;
      break;
  }

  _info[_deviceNo].value = volts;
  _valueLCD->display(volts);
}

