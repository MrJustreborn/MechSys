#include "../include/ao.h"

SinusPushButton::SinusPushButton(QWidget *parent, const char *name)
  : QPushButton(parent, name)
{}



void SinusPushButton::paintEvent(QPaintEvent *event)
{
  QPushButton::paintEvent(event);
  QPainter p;
  p.begin(this);
  p.setPen(QPen(black, 2, SolidLine));
  p.drawArc(10, 10, 15, 15, 10 * 16, 160 * 16);
  p.drawArc(24, 6, 15, 15, 190 * 16, 160 * 16);
  p.end();
}
  


RectPushButton::RectPushButton(QWidget *parent, const char *name)
  : QPushButton(parent, name)
{}



void RectPushButton::paintEvent(QPaintEvent *event)
{
  QPushButton::paintEvent(event);
  QPainter p;
  p.begin(this);
  p.setPen(QPen(black, 2, SolidLine));
  p.drawLine(10, 20, 10, 10);
  p.drawLine(10, 10, 25, 10);
  p.drawLine(25, 10, 25, 20);
  p.drawLine(25, 20, 40, 20);
  p.end();
}
  
  

TriPushButton::TriPushButton(QWidget *parent = 0, const char *name = 0)
  : QPushButton(parent, name)
{}



void TriPushButton::paintEvent(QPaintEvent *event)
{
  QPushButton::paintEvent(event);
  QPainter p;
  p.begin(this);
  p.setPen(QPen(black, 2, SolidLine));
  p.drawLine(10, 20, 20, 10);
  p.drawLine(20, 10, 30, 20);
  p.drawLine(30, 20, 40, 10);
  p.end();
}
  
  

Function::Function(){
  int i;
  double part = 2 * M_PI / ME4000_AO_FIFO_COUNT;

  _shape = 0;
  _amplitude = 1;
  _offset = 0;
  _count = ME4000_AO_FIFO_COUNT;

  _data = (unsigned short *) calloc(_count, sizeof(unsigned short));

  for(i = 0; i < _count; i++){
    _data[i] = (unsigned short) ((0xCCC * sin(part * i) + 0x7FFF));
  }
}



Function::~Function(){
  free(_data);
}



int Function::setShape(int shape){
  switch(shape){
    case 0:
    case 1:
    case 2:
      break;
    default:
      return 1;
  }

  _shape = shape;
  calcWave();

  return 0;
}



int Function::getShape(){
  return _shape;
}



int Function::setOffset(double offset){
  _offset = offset;
  calcWave();
  
  return 0;
}



double Function::getOffset(){
  return _offset;
}



int Function::setAmplitude(double amplitude){
  _amplitude = amplitude;
  calcWave();
  
  return 0;
}



double Function::getAmplitude(){
  return _amplitude;
}



int Function::setCount(int count){
  if((count > ME4000_AO_FIFO_COUNT) || (count < 1)) return 1;

  _count = count;
  calcWave();
  
  return 0;
}



int Function::getCount(){
  return _count;
}



unsigned short * Function::getData(){
  return _data;
}



int Function::calcWave(){
  int i;
  int k;

  if (_shape == 0){
    double part = 2 * M_PI / _count;
    for(i = 0; i < _count; i++){
      _data[i] = (unsigned short) (_amplitude * 0xCCC * sin(part * i) + _offset * 0xCCC + 0x7FFF);
    }
  }
  else if (_shape == 1){
    for(i = 0; i < _count / 2; i++){
      _data[i] = (unsigned short) (_amplitude * 0xCCC + 0x7FFF + _offset * 0xCCC);
    }
    for(i = _count / 2; i < _count; i++){
      _data[i] = (unsigned short) (0x7FFF + _offset * 0xCCC - _amplitude * 0xCCC);
    }
  }
  else if (_shape == 2){
    double part = 4 * _amplitude * 0xCCC / _count;
    for(i = 0; i < _count / 2; i++){
      _data[i] = (unsigned short) (i * part + 0x7FFF - _amplitude * 0xCCC + _offset * 0xCCC);
    }
    for(i = _count / 2, k = 0; i < _count; i++, k++){
      _data[i] = (unsigned short) (_amplitude * 0xCCC - k * part + 0x7FFF + _offset * 0xCCC);
    }
  }
  else {
    return 1;
  }

  return 0;
}



AO::AO(DevCtrl *device, QWidget *parent, const char *name, int number)
  : QWidget(parent, name)
{
  /* ME-4000 device object */
  _device = device;
  _number = number;
  _freqFactor = 1;
  _freq = 1;

  /* Label for frequency display */
  QLabel *LblLCDFrequency = new QLabel("FREQUENCY",this);
  LblLCDFrequency->move(30,30);
  LblLCDFrequency->resize(100,30);
  LblLCDFrequency->setFrameStyle(QFrame::Box | QFrame::Raised);
  QFont FontLblLCDFrequency("Helvetica", 14, QFont::Bold);
  LblLCDFrequency->setFont(FontLblLCDFrequency);
  LblLCDFrequency->setAlignment(QLabel::AlignCenter);

  /* Label amplitude display */
  QLabel *LblLCDAmplitude = new QLabel("AMPLITUDE",this);
  LblLCDAmplitude->move(130,30);
  LblLCDAmplitude->resize(100,30);
  LblLCDAmplitude->setFrameStyle(QFrame::Box | QFrame::Raised);
  QFont FontLblLCDAmplitude("Helvetica", 14, QFont::Bold);
  LblLCDAmplitude->setFont(FontLblLCDAmplitude);
  LblLCDAmplitude->setAlignment(QLabel::AlignCenter);

  /* LCD for frequency */
  _LCDFrequency = new QLCDNumber(this);
  _LCDFrequency->move(30,60);
  _LCDFrequency->setNumDigits(5);
  _LCDFrequency->resize(100,95);
  _LCDFrequency->setSmallDecimalPoint(TRUE);
  _LCDFrequency->setSegmentStyle(QLCDNumber::Flat);

  /* LCD for amplitude */
  _LCDAmplitude = new QLCDNumber(this);
  _LCDAmplitude->move(130,60);
  _LCDAmplitude->setNumDigits(5);
  _LCDAmplitude->resize(100,95);
  _LCDAmplitude->setSmallDecimalPoint(TRUE);
  _LCDAmplitude->setSegmentStyle(QLCDNumber::Flat);

  /* Slider frequency */ 
  QSlider *SliderFrequency = new QSlider(0, 100, 1, 10, QSlider::Horizontal, this);
  SliderFrequency->resize(410, 30);
  SliderFrequency->move(270, 60);
  SliderFrequency->setTickInterval(10);
  SliderFrequency->setTickmarks(QSlider::Above);
  QFont FontFactorSliderFrequency("Helvetica", 14, QFont::Bold);

  /* Button group for factors */
  QButtonGroup *factor = new QButtonGroup(this);
  factor->setExclusive(TRUE);
  factor->setGeometry(270, 105, 410, 50);

  /* Factor 1 */
  QPushButton *Factor1SliderFrequency = new QPushButton("x1", factor);
  Factor1SliderFrequency->move(20, 10);
  Factor1SliderFrequency->resize(50, 30);
  Factor1SliderFrequency->setToggleButton(TRUE);
  Factor1SliderFrequency->setFont(FontFactorSliderFrequency);

  /* Factor 10 */
  QPushButton *Factor10SliderFrequency = new QPushButton("x10", factor);
  Factor10SliderFrequency->move(100, 10);
  Factor10SliderFrequency->resize(50, 30);
  Factor10SliderFrequency->setToggleButton(TRUE);
  Factor10SliderFrequency->setFont(FontFactorSliderFrequency);

  /* Factor 100 */
  QPushButton *Factor100SliderFrequency = new QPushButton("x100", factor);
  Factor100SliderFrequency->move(180, 10);
  Factor100SliderFrequency->resize(50, 30);
  Factor100SliderFrequency->setToggleButton(TRUE);
  Factor100SliderFrequency->setFont(FontFactorSliderFrequency);

  /* Factor 1k */
  QPushButton *Factor1kSliderFrequency = new QPushButton("x1k", factor);
  Factor1kSliderFrequency->move(260, 10);
  Factor1kSliderFrequency->resize(50, 30);
  Factor1kSliderFrequency->setToggleButton(TRUE);
  Factor1kSliderFrequency->setFont(FontFactorSliderFrequency);

  /* Factor 10k */
  QPushButton *Factor10kSliderFrequency = new QPushButton("x10k", factor);
  Factor10kSliderFrequency->move(340, 10);
  Factor10kSliderFrequency->resize(50, 30);
  Factor10kSliderFrequency->setToggleButton(TRUE);
  Factor10kSliderFrequency->setFont(FontFactorSliderFrequency);

  /* Activate sinus */
  factor->setButton(0);

  /* Label Frequency */
  QLabel *LblSliderFrequency = new QLabel("Frequency /Hz", this);
  LblSliderFrequency->move(270, 25);
  LblSliderFrequency->resize(410, 20);
  LblSliderFrequency->setAlignment(QLabel::AlignCenter);

  /* Frequency slider marks */
  QLabel *Scale0SliderFrequency = new QLabel("0", this);
  Scale0SliderFrequency->move(273, 48);
  Scale0SliderFrequency->resize(10, 10);
  QLabel *Scale1SliderFrequency = new QLabel("1", this);
  Scale1SliderFrequency->move(313, 48);
  Scale1SliderFrequency->resize(10, 10);
  QLabel *Scale2SliderFrequency = new QLabel("2", this);
  Scale2SliderFrequency->move(353, 48);
  Scale2SliderFrequency->resize(10, 10);
  QLabel *Scale3SliderFrequency = new QLabel("3", this);
  Scale3SliderFrequency->move(393, 48);
  Scale3SliderFrequency->resize(10, 10);
  QLabel *Scale4SliderFrequency = new QLabel("4", this);
  Scale4SliderFrequency->move(434, 48);
  Scale4SliderFrequency->resize(10, 10);
  QLabel *Scale5SliderFrequency = new QLabel("5", this);
  Scale5SliderFrequency->move(473, 48);
  Scale5SliderFrequency->resize(10, 10);
  QLabel *Scale6SliderFrequency = new QLabel("6", this);
  Scale6SliderFrequency->move(512, 48);
  Scale6SliderFrequency->resize(10, 10);
  QLabel *Scale7SliderFrequency = new QLabel("7", this);
  Scale7SliderFrequency->move(551, 48);
  Scale7SliderFrequency->resize(10, 10);
  QLabel *Scale8SliderFrequency = new QLabel("8", this);
  Scale8SliderFrequency->move(592, 48);
  Scale8SliderFrequency->resize(10, 10);
  QLabel *Scale9SliderFrequency = new QLabel("9", this);
  Scale9SliderFrequency->move(632, 48);
  Scale9SliderFrequency->resize(10, 10);
  QLabel *Scale10SliderFrequency = new QLabel("10", this);
  Scale10SliderFrequency->move(669, 48);
  Scale10SliderFrequency->resize(15, 10);

  /* Slider amplitude */
  QSlider *SliderAmplitude = new QSlider(0, 100, 1, 10, QSlider::Horizontal, this);
  SliderAmplitude->resize(410, 30);
  SliderAmplitude->move(270, 210);
  SliderAmplitude->setTickInterval(10);
  SliderAmplitude->setTickmarks(QSlider::Above);

  /* Amplitude slider label */
  QLabel *LblSliderAmplitude = new QLabel("Amplitude /V", this);
  LblSliderAmplitude->move(270, 175);
  LblSliderAmplitude->resize(410, 20);
  LblSliderAmplitude->setAlignment(QLabel::AlignCenter);

  /* Amplitude slider marks */
  QLabel *Scale0SliderAmplitude = new QLabel("0", this);
  Scale0SliderAmplitude->move(273, 198);
  Scale0SliderAmplitude->resize(10, 10);
  QLabel *Scale1SliderAmplitude = new QLabel("1", this);
  Scale1SliderAmplitude->move(313, 198);
  Scale1SliderAmplitude->resize(10, 10);
  QLabel *Scale2SliderAmplitude = new QLabel("2", this);
  Scale2SliderAmplitude->move(353, 198);
  Scale2SliderAmplitude->resize(10, 10);
  QLabel *Scale3SliderAmplitude = new QLabel("3", this);
  Scale3SliderAmplitude->move(393, 198);
  Scale3SliderAmplitude->resize(10, 10);
  QLabel *Scale4SliderAmplitude = new QLabel("4", this);
  Scale4SliderAmplitude->move(434, 198);
  Scale4SliderAmplitude->resize(10, 10);
  QLabel *Scale5SliderAmplitude = new QLabel("5", this);
  Scale5SliderAmplitude->move(473, 198);
  Scale5SliderAmplitude->resize(10, 10);
  QLabel *Scale6SliderAmplitude = new QLabel("6", this);
  Scale6SliderAmplitude->move(512, 198);
  Scale6SliderAmplitude->resize(10, 10);
  QLabel *Scale7SliderAmplitude = new QLabel("7", this);
  Scale7SliderAmplitude->move(551, 198);
  Scale7SliderAmplitude->resize(10, 10);
  QLabel *Scale8SliderAmplitude = new QLabel("8", this);
  Scale8SliderAmplitude->move(592, 198);
  Scale8SliderAmplitude->resize(10, 10);
  QLabel *Scale9SliderAmplitude = new QLabel("9", this);
  Scale9SliderAmplitude->move(632, 198);
  Scale9SliderAmplitude->resize(10, 10);
  QLabel *Scale10SliderAmplitude = new QLabel("10", this);
  Scale10SliderAmplitude->move(669, 198);
  Scale10SliderAmplitude->resize(15, 10);

  /* slider offset */
  QSlider *SliderOffset = new QSlider(-50, 50, 1, 0, QSlider::Horizontal, this);
  SliderOffset->resize(410, 30);
  SliderOffset->move(270, 290);
  SliderOffset->setTickInterval(10);
  SliderOffset->setTickmarks(QSlider::Above);

  /* Slider offset label */
  QLabel *LblSliderOffset = new QLabel("Offset /V", this);
  LblSliderOffset->move(270, 255);
  LblSliderOffset->resize(410, 20);
  LblSliderOffset->setAlignment(QLabel::AlignCenter);

  /* Slider offset marks */
  QLabel *Scale0SliderOffset = new QLabel("-5", this);
  Scale0SliderOffset->move(271, 278);
  Scale0SliderOffset->resize(15, 10);
  QLabel *Scale1SliderOffset = new QLabel("-4", this);
  Scale1SliderOffset->move(311, 278);
  Scale1SliderOffset->resize(15, 10);
  QLabel *Scale2SliderOffset = new QLabel("-3", this);
  Scale2SliderOffset->move(350, 278);
  Scale2SliderOffset->resize(15, 10);
  QLabel *Scale3SliderOffset = new QLabel("-2", this);
  Scale3SliderOffset->move(389, 278);
  Scale3SliderOffset->resize(15, 10);
  QLabel *Scale4SliderOffset = new QLabel("-1", this);
  Scale4SliderOffset->move(429, 278);
  Scale4SliderOffset->resize(15, 10);
  QLabel *Scale5SliderOffset = new QLabel("0", this);
  Scale5SliderOffset->move(473, 278);
  Scale5SliderOffset->resize(15, 10);
  QLabel *Scale6SliderOffset = new QLabel("1", this);
  Scale6SliderOffset->move(512, 278);
  Scale6SliderOffset->resize(15, 10);
  QLabel *Scale7SliderOffset = new QLabel("2", this);
  Scale7SliderOffset->move(552, 278);
  Scale7SliderOffset->resize(15, 10);
  QLabel *Scale8SliderOffset = new QLabel("3", this);
  Scale8SliderOffset->move(592, 278);
  Scale8SliderOffset->resize(15, 10);
  QLabel *Scale9SliderOffset = new QLabel("4", this);
  Scale9SliderOffset->move(632, 278);
  Scale9SliderOffset->resize(15, 10);
  QLabel *Scale10SliderOffset = new QLabel("5", this);
  Scale10SliderOffset->move(672, 278);
  Scale10SliderOffset->resize(15, 10);

  /* Button group for signal shape */
  QButtonGroup *signal = new QButtonGroup(this);
  signal->setExclusive(TRUE);
  signal->setGeometry(30, 180, 200, 50);

  /* Switch for sinus signal */
  SinusPushButton *ModeSinus = new SinusPushButton(signal, 0);
  ModeSinus->move(10, 10);
  ModeSinus->resize(50,30);
  ModeSinus->setToggleButton(TRUE);

  /* Switch for rectangle signal */
  RectPushButton *ModeRectangle = new RectPushButton(signal, 0);
  ModeRectangle->move(75, 10);
  ModeRectangle->resize(50,30);
  ModeRectangle->setToggleButton(TRUE);

  /* Switch for triangle signal */
  TriPushButton *ModeTriangle = new TriPushButton(signal, 0);
  ModeTriangle->move(140, 10);
  ModeTriangle->resize(50,30);
  ModeTriangle->setToggleButton(TRUE);

  /* Activate sinus */
  signal->setButton(0);

  /* Start/Stop button */
  _PushButtonStartStop  = new QPushButton("Start", this);
  _PushButtonStartStop->move(30,280);
  _PushButtonStartStop->resize(40,40);
  _PushButtonStartStop->setToggleButton(TRUE);

  /* Internal connections */
  _PushButtonStartStop->connect(_PushButtonStartStop, SIGNAL(toggled(bool)), this, SLOT(startStopBtnToggled(bool)));
  signal->connect(signal, SIGNAL(clicked(int)), this, SLOT(shapeChanged(int)));
  SliderAmplitude->connect(SliderAmplitude, SIGNAL(valueChanged(int)), this, SLOT(amplitudeChanged(int)));
  SliderOffset->connect(SliderOffset, SIGNAL(valueChanged(int)), this, SLOT(offsetChanged(int)));
  SliderFrequency->connect(SliderFrequency, SIGNAL(valueChanged(int)), this, SLOT(freqChanged(int)));
  factor->connect(factor, SIGNAL(clicked(int)), this, SLOT(freqFactorChanged(int)));

  /* Load analog output with default waveform */
  _device->aoWrite(_number, _function.getData(), _function.getCount());

  /* Set timer to default value */
  _device->aoTimerSetDivisor(_number, 8057);
  
  _LCDFrequency->display(1.0);
  _LCDAmplitude->display(1.0);
}



AO::~AO(){}



void AO::startStopBtnToggled(bool on){
  if(on){
    _device->aoWrite(_number, _function.getData(), _function.getCount());
    _device->aoStart(_number);
  }
  else{
    _device->aoStop(_number);
  }
}



void AO::shapeChanged(int id){
  _function.setShape(id);
  _device->aoStop(_number);
  _device->aoWrite(_number, _function.getData(), _function.getCount());
  if(_PushButtonStartStop->isOn()) _device->aoStart(_number);
}



void AO::amplitudeChanged(int value){
  _function.setAmplitude((double) value / 10);
  _LCDAmplitude->display((double) value / 10);
  _device->aoStop(_number);
  _device->aoWrite(_number, _function.getData(), _function.getCount());
  if(_PushButtonStartStop->isOn()) _device->aoStart(_number);
}


void AO::offsetChanged(int value){
  _function.setOffset((double) value / 10);
  _device->aoStop(_number);
  _device->aoWrite(_number, _function.getData(), _function.getCount());
  if(_PushButtonStartStop->isOn()) _device->aoStart(_number);
}



void AO::freqFactorChanged(int id){
  double ticks = 66.0;
  unsigned int iTicks;
  double count;
  double freq;

  switch(id){
    case 0:
      _freqFactor = 1.0;
      break;
    case 1:
      _freqFactor = 10.0;
      break;
    case 2:
      _freqFactor = 100.0;
      break;
    case 3:
      _freqFactor = 1000.0;
      break;
    case 4:
      _freqFactor = 10000.0;
      break;
    default:
      return;
  }

  count = (33.0E6 / (_freqFactor * _freq * ME4000_AO_MIN_TICKS));
  if(count < 16){
    _function.setCount(16);
    ticks = ME4000_AO_MIN_TICKS;
  }
  else if (count > ME4000_AO_FIFO_COUNT){
    _function.setCount(ME4000_AO_FIFO_COUNT);
    ticks = 33.0E6 / (_freqFactor * _freq * (double) _function.getCount());
  }
  else {
    _function.setCount((unsigned int) count);
    ticks = ME4000_AO_MIN_TICKS;
  }

  ticks += 0.5;
  iTicks = (unsigned int) ticks;

  _LCDFrequency->display(33.0E6 / (double) iTicks / (double) _function.getCount());
  _device->aoStop(_number);
  _device->aoTimerSetDivisor(_number, iTicks);
  _device->aoWrite(_number, _function.getData(), _function.getCount());
  if(_PushButtonStartStop->isOn()) _device->aoStart(_number);
}



void AO::freqChanged(int value){
  double ticks;
  unsigned int iTicks;
  double count;
  
  _freq = (double) value / 10.0;

  count = (33.0E6 / (_freqFactor * _freq * ME4000_AO_MIN_TICKS));
  if(count < 16){
    _function.setCount(16);
    ticks = ME4000_AO_MIN_TICKS;
  }
  else if (count > ME4000_AO_FIFO_COUNT){
    _function.setCount(ME4000_AO_FIFO_COUNT);
    ticks = 33.0E6 / (_freqFactor * _freq * (double) _function.getCount());
  }
  else {
    _function.setCount((unsigned int) count);
    ticks = ME4000_AO_MIN_TICKS;
  }

  ticks += 0.5;
  iTicks = (unsigned int) ticks;

  _LCDFrequency->display(33.0E6 / (double) iTicks / (double) _function.getCount());
  _device->aoStop(_number);
  _device->aoTimerSetDivisor(_number, iTicks);
  _device->aoWrite(_number, _function.getData(), _function.getCount());
  if(_PushButtonStartStop->isOn()) _device->aoStart(_number);
}



