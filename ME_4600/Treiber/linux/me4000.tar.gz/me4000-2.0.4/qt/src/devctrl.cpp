#include "../include/devctrl.h"

DevCtrl::DevCtrl(QObject *parent, const char *name, int boardNo)
  : QObject(parent, name) {

  QString path;
  int err;
  int i;
  me4000_user_info_t info;

  _fdAI = -1;
  _fdAO[0] = -1;
  _fdAO[1] = -1;
  _fdAO[2] = -1;
  _fdAO[3] = -1;
  _fdDIO = -1;
  _fdCNT = -1;

  _aiCount = 0;
  _aoCount = 0;
  _dioCount = 0;
  _cntCount = 0;

  /* Analog input is always available */
  path.sprintf("/dev/me4000_%d_ai_cont_sw", boardNo);
  _fdAI = open(path.latin1(), O_RDONLY, 0);
  if(_fdAI < 0){
    return;
  }

  err = ioctl(_fdAI, ME4000_GET_USER_INFO, &info);
  if(err){
    return;
  }

  for(i = 0; (i < info.ao_fifo_count) && (i < 4); i++){
    path.sprintf("/dev/me4000_%d_ao_%d_wrap", boardNo, i);
    _fdAO[i] = open(path.latin1(), O_WRONLY, 0);
  }
  
  path.sprintf("/dev/me4000_%d_dio", boardNo);
  _fdDIO = open(path.latin1(), O_RDWR, 0);

  if(info.cnt_count){
    path.sprintf("/dev/me4000_%d_cnt", boardNo);
    _fdCNT = open(path.latin1(), O_RDWR, 0);
  }

  _aiCount = info.ai_count;
  _aoCount = info.ao_fifo_count;
  _dioCount = info.dio_count;
  _cntCount = info.cnt_count;

  _deviceID = info.device_id;
}



DevCtrl::~DevCtrl(){}



int DevCtrl::aiStart(){
  int err;
  unsigned long timeout = 0;
  QString caption("me4000-qt");
  QString text("Can't start analog input:");

  err = ioctl(_fdAI, ME4000_AI_START, &timeout);
  if(err){
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  return 0;
}



int DevCtrl::aiStop(){
  int err;
  QString caption("me4000-qt");
  QString text("Can't stop analog input:");

  err = ioctl(_fdAI, ME4000_AI_IMMEDIATE_STOP);
  if(err){
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  return 0;
}



int DevCtrl::aiConfig(unsigned long *chanList, unsigned long chanListCount, unsigned long scanDivisor, unsigned long chanDivisor){
  int err;
  me4000_ai_config_t config;
  QString caption("me4000-qt");
  QString text("Can't configure analog input:");
  
  config.timer.pre_chan = 66;
  config.timer.chan = chanDivisor;
  config.timer.scan_low = scanDivisor;
  config.timer.scan_high = 0;

  config.channel_list.list = chanList;
  config.channel_list.count = chanListCount;

  config.sh = 0;

  err = ioctl(_fdAI, ME4000_AI_CONFIG, &config);
  if(err){
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  return 0;
}



int DevCtrl::aiRead(signed short *buf, int count){
  ssize_t ret;
  QString caption("me4000-qt");
  QString text("Can't read analog input:");

  ret = read(_fdAI, buf, count * 2);
  if(ret != count * 2){
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  return 0;
}



int DevCtrl::aoStart(int ao){
  int err;
  unsigned long timeout = 0;
  QString caption("me4000-qt");
  QString text("Can't start analog output:");

  if(ao < 0 || ao >= _aoCount){
    errno = EINVAL;
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  err = ioctl(_fdAO[ao], ME4000_AO_START, &timeout);
  if(err){
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  return 0;
}



int DevCtrl::aoStop(int ao){
  int err;
  QString caption("me4000-qt");
  QString text("Can't stop analog output:");

  if(ao < 0 || ao >= _aoCount){
    errno = EINVAL;
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  err = ioctl(_fdAO[ao], ME4000_AO_RESET);
  if(err){
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  return 0;
}



int DevCtrl::aoTimerSetDivisor(int ao, int divisor){
  int err;
  QString caption("me4000-qt");
  QString text("Can't set divisor analog output:");

  if(ao < 0 || ao >= _aoCount){
    errno = EINVAL;
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  err = ioctl(_fdAO[ao], ME4000_AO_TIMER_SET_DIVISOR, &divisor);
  if(err){
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  return 0;
}



int DevCtrl::aoWrite(int ao, unsigned short *buf, int count){
  int err;
  QString caption("me4000-qt");
  QString text("Can't write to analog output:");

  if(ao < 0 || ao >= _aoCount){
    errno = EINVAL;
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  err = write(_fdAO[ao], buf, count * 2);
  if(err < 0){
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  return 0;
}



int DevCtrl::dioConfig(int port, int mode){
  int err;
  me4000_dio_config_t config;
  QString caption("me4000-qt");
  QString text("Can't configure digital I/O:");

  config.port = port;
  config.mode = mode;
  config.function = 0;

  err = ioctl(_fdDIO, ME4000_DIO_CONFIG, &config);
  if(err){
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  return 0;
}



int DevCtrl::dioGetByte(int port, int *byte){
  int err;
  me4000_dio_byte_t data;
  QString caption("me4000-qt");
  QString text("Can't read byte form digital I/O:");

  data.port = port;

  err = ioctl(_fdDIO, ME4000_DIO_GET_BYTE, &data);
  if(err){
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  *byte = data.byte;
  return 0;
}



int DevCtrl::dioSetByte(int port, int byte){
  int err;
  me4000_dio_byte_t data;
  QString caption("me4000-qt");
  QString text("Can't write byte to digital I/O:");

  data.port = port;
  data.byte = byte & 0xFF;

  err = ioctl(_fdDIO, ME4000_DIO_SET_BYTE, &data);
  if(err){
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  return 0;
}



int DevCtrl::dioReset(){
  int err;
  QString caption("me4000-qt");
  QString text("Can't reset digital I/O:");

  err = ioctl(_fdDIO, ME4000_DIO_RESET);
  if(err){
    text.append(strerror(errno));
    QMessageBox::warning(0, caption, text);
    return 1;
  }

  return 0;
}



int DevCtrl::getAoCount(){
  return _aoCount;
}



int DevCtrl::getAiCount(){
  return _aiCount;
}



int DevCtrl::getDioCount(){
  return _dioCount;
}



int DevCtrl::getCntCount(){
  return _cntCount;
}



int DevCtrl::getDeviceId(){
  return _deviceID;
}

