#include "../include/disctrl.h"


DisCtrl::DisCtrl(QPopupMenu *menu, QObject *parent = 0, const char *name = 0)
  : QObject(parent, name) 
{
  _menu = menu;

  _boardVersion = 0x2000;

  _idPort = 0;
  _idAO   = 0;
  _idAIScan = 0;
  _idAIMultiple = 0;
  _idAIQuick = 0;
  _idAISingle = 0;
}

DisCtrl::~DisCtrl(){}


void DisCtrl::setIdPort(int id)
{
  _idPort = id;
}


void DisCtrl::setIdAO(int id)
{
  _idAO = id;
}


void DisCtrl::setIdAIScan(int id)
{
  _idAIScan = id;
}


void DisCtrl::setIdAIMultiple(int id)
{
  _idAIMultiple = id;
}


void DisCtrl::setIdAIQuick(int id)
{
  _idAIQuick = id;
}


void DisCtrl::setIdAISingle(int id)
{
  _idAISingle = id;
}


void DisCtrl::setBoardVersion(int version)
{

  if(version == 0x2000){
    _menu->setItemEnabled(_idAO, FALSE);
  }
  else if(version == 0x2600){
    _menu->setItemEnabled(_idAO, TRUE);
  }
  else{
    return;
  }
    
  /* To display port a is possible for every card */
  setPort();

  _boardVersion = version;
}


void DisCtrl::setPort()
{
  emit showPort();
  emit hideAO();
  emit hideAIScan();
  emit hideAIMultiple();
  emit hideAIQuick();
  emit hideAISingle();
}


void DisCtrl::setAO()
{
  emit hidePort();
  emit showAO();
  emit hideAIScan();
  emit hideAIMultiple();
  emit hideAIQuick();
  emit hideAISingle();
}


void DisCtrl::setAIScan()
{
  emit hidePort();
  emit hideAO();
  emit showAIScan();
  emit hideAIMultiple();
  emit hideAIQuick();
  emit hideAISingle();
}


void DisCtrl::setAIMultiple()
{
  emit hidePort();
  emit hideAO();
  emit hideAIScan();
  emit showAIMultiple();
  emit hideAIQuick();
  emit hideAISingle();
}


void DisCtrl::setAIQuick()
{
  emit hidePort();
  emit hideAO();
  emit hideAIScan();
  emit hideAIMultiple();
  emit showAIQuick();
  emit hideAISingle();
}


void DisCtrl::setAISingle()
{
  emit hidePort();
  emit hideAO();
  emit hideAIScan();
  emit hideAIMultiple();
  emit hideAIQuick();
  emit showAISingle();
}


