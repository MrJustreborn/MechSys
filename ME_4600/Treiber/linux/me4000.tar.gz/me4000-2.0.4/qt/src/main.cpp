/* Test program for the Meilhaus ME-4000 board.
 * ============================================
 *  
 *
 *   Copyright (C) 2002 Meilhaus Electronic GmbH (support@meilhaus.de)
 *  
 *   This file is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * Source File : main.cpp                                              
 * Destination : me4000-qt
 * Author      : GG (Guenter Gebhardt)                                 
 *                                                                     
 * File History: Version   Date       Editor   Action                  
 *---------------------------------------------------------------------
 *               1.00.00   02.06.21   GG       first release           
 *                                                                     
 *---------------------------------------------------------------------
 *                                                                     
 * Description:                                                        
 *                                                                     
 */

#include <qapplication.h>
#include <qmainwindow.h>
#include <qpopupmenu.h>
#include <qmenubar.h>
#include <qstatusbar.h>

#include <qlabel.h>
#include <qspinbox.h>
#include <qmessagebox.h>
#include <qlcdnumber.h>
#include <qwidgetstack.h>
#include <qtabbar.h>

#include "../include/devctrl.h"
#include "../include/port.h"
#include "../include/ao.h"
#include "../include/ai.h"


int main(int argc, char **argv){
  int id;
  int i;
  QString text;

  /* Initalize application */
  QApplication app(argc, argv);

  /* Create main window */
  QMainWindow *top = new QMainWindow();

  /* Set top as main widget */
  app.setMainWidget(top);

  /* Popup Menus */
  QPopupMenu *filePopup = new QPopupMenu();

  /* Tabulator bar */
  QTabBar *tabBar = new QTabBar(top, "tabBar");
  tabBar->setGeometry(0, 30, 800, 60);

  /* Menu entry for quit */
  filePopup->insertItem("&Quit", qApp, SLOT(quit()));

  /* Configure main window */
  top->setFixedSize(800, 600);
  top->menuBar()->insertItem("&File", filePopup);

  /* This is the ME-4000 device */
  DevCtrl *device = new DevCtrl();

  /* Hold all widgets in a stack */
  QWidgetStack *widgets = new QWidgetStack(top);
  widgets->setGeometry(0, 60, 800, 540);

  /* AI widget */
  AI *ai = new AI(device, NULL, NULL);
  ai->setGeometry(0, 0, 400, 400);
  text.sprintf("Analog Input");
  QTab *aiTab = new QTab(text);
  id = tabBar->insertTab(aiTab);
  tabBar->connect(tabBar, SIGNAL(selected(int)), widgets, SLOT(raiseWidget(int)));
  widgets->addWidget(ai, id);
  widgets->raiseWidget(id);

  /* AO widgets */
  for(i = 0; i < device->getAoCount(); i++){
    text.sprintf("Analog output %d", i);
    AO *ao = new AO(device, NULL, NULL, i);
    ao->setGeometry(0, 0, 400, 400);
    QTab *aoTab = new QTab(text);
    id = tabBar->insertTab(aoTab);
    tabBar->connect(tabBar, SIGNAL(selected(int)), widgets, SLOT(raiseWidget(int)));
    widgets->addWidget(ao, id);
  }

  /* Port widgets */
  for(i = 0; i < device->getDioCount(); i++){
    text.sprintf("Port %d", i);
    Port *port = new Port(device, NULL, NULL, i);
    port->setGeometry(0, 0, 400, 400);
    QTab *dioTab = new QTab(text);
    id = tabBar->insertTab(dioTab);
    tabBar->connect(tabBar, SIGNAL(selected(int)), widgets, SLOT(raiseWidget(int)));
    widgets->addWidget(port, id);
  }

  top->show();
  return app.exec();
}
