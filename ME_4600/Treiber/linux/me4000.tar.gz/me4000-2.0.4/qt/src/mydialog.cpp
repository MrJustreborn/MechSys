#include "../include/mydialog.h"

MyDialog::MyDialog() : 
  QDialog(0, "Channel list dialog", true)
{
  QLabel *lbl = new QLabel("Select the Channel", this);
  lbl->move(20, 20);
  lbl->resize(200, 30);

  _channelBox = new QSpinBox(0, 15, 1, this);
  _channelBox->move(20, 50);
  _channelBox->resize(200, 30);

  _rangeBtn = new QButtonGroup("Select the output range", this, "Range Buttons");
  _rangeBtn->move(250, 30);
  _rangeBtn->resize(200, 180);

  QRadioButton *rangeMinus10 = new QRadioButton("-10 .. 10V", _rangeBtn, "Minus 10");
  QRadioButton *rangeMinus02 = new QRadioButton("-2.5 .. 2.5V", _rangeBtn, "Minus 02");
  QRadioButton *rangePlus10  = new QRadioButton("0 .. 10V", _rangeBtn, "Plus  10");
  QRadioButton *rangePlus02  = new QRadioButton("0 .. 2.5V", _rangeBtn, "Plus  02");

  _rangeBtn->insert(rangeMinus10, ME4000_AI_LIST_RANGE_BIPOLAR_10);
  _rangeBtn->insert(rangeMinus02, ME4000_AI_LIST_RANGE_BIPOLAR_2_5);
  _rangeBtn->insert(rangePlus10, ME4000_AI_LIST_RANGE_UNIPOLAR_10);
  _rangeBtn->insert(rangePlus02, ME4000_AI_LIST_RANGE_UNIPOLAR_2_5);

  rangeMinus10->move(10, 30);
  rangeMinus02->move(10, 60);
  rangePlus10->move(10, 90);
  rangePlus02->move(10, 120);

  _rangeBtn->setButton(ME4000_AI_LIST_RANGE_BIPOLAR_10);

  _modeBtn = new QButtonGroup("Select the output mode", this, "Mode Buttons");
  _modeBtn->move(20, 100);
  _modeBtn->resize(200, 120);

  QRadioButton *modeSingle = new QRadioButton("Single Ended", _modeBtn, "Single ended");
  QRadioButton *modeDiff = new QRadioButton("Differential", _modeBtn, "Differential");

  _modeBtn->insert(modeSingle, ME4000_AI_LIST_INPUT_SINGLE_ENDED);
  _modeBtn->insert(modeDiff, ME4000_AI_LIST_INPUT_DIFFERENTIAL);

  modeSingle->move(10, 30);
  modeDiff->move(10, 60);

  _modeBtn->setButton(ME4000_AI_LIST_INPUT_SINGLE_ENDED);

  QPushButton *okButton = new QPushButton("OK", this);
  okButton->resize(80, 30);
  okButton->move(20, 250);
  okButton->connect(okButton, SIGNAL(clicked()), this, SLOT(accept()));

  QPushButton *cancelButton = new QPushButton("CANCEL", this);
  cancelButton->resize(80, 30);
  cancelButton->move(370, 250);
  cancelButton->connect(cancelButton, SIGNAL(clicked()), this, SLOT(reject()));
}

int MyDialog::getChannel(){
  return _channelBox->value();
}


int MyDialog::getRange(){
  return _rangeBtn->id(_rangeBtn->selected());
}


int MyDialog::getMode(){
  return _modeBtn->id(_modeBtn->selected());
}
