#include "../include/port.h"

Port::Port(DevCtrl *device, QWidget *parent, const char *name, int number, int dir, int outByte, int inByte)
  : QWidget(parent, name)
{
  QString text;

  text.sprintf("Port %d direction", number);
  portDirBtnGrp = new QButtonGroup(text, this);
  portDirBtnGrp->resize(120, 100);
  portDirBtnGrp->move(20, 20);
  QRadioButton *input = new QRadioButton("Input", portDirBtnGrp);
  input->move(10, 30);
  QRadioButton *output = new QRadioButton("Output", portDirBtnGrp);
  output->move(10, 60);
  portDirBtnGrp->setButton(0);

  text.sprintf("Port %d Bits 0..7", number);
  portWriteBtnGrp = new QButtonGroup(text, this);
  portWriteBtnGrp->resize(120, 200);
  portWriteBtnGrp->move(160, 20);
  portWriteBtnGrp->hide();
  QCheckBox *bit0 = new QCheckBox("BIT 0", portWriteBtnGrp);
  bit0->move(10, 20);
  QCheckBox *bit1 = new QCheckBox("BIT 1", portWriteBtnGrp);
  bit1->move(10, 40);
  QCheckBox *bit2 = new QCheckBox("BIT 2", portWriteBtnGrp);
  bit2->move(10, 60);
  QCheckBox *bit3 = new QCheckBox("BIT 3", portWriteBtnGrp);
  bit3->move(10, 80);
  QCheckBox *bit4 = new QCheckBox("BIT 4", portWriteBtnGrp);
  bit4->move(10, 100);
  QCheckBox *bit5 = new QCheckBox("BIT 5", portWriteBtnGrp);
  bit5->move(10, 120);
  QCheckBox *bit6 = new QCheckBox("BIT 6", portWriteBtnGrp);
  bit6->move(10, 140);
  QCheckBox *bit7 = new QCheckBox("BIT 7", portWriteBtnGrp);
  bit7->move(10, 160);

  portInByteLCD = new QLCDNumber(4, this);
  portInByteLCD->setMode(QLCDNumber::HEX);
  portInByteLCD->resize(120, 30);
  portInByteLCD->move(20, 140);

  text.sprintf("Read port %d", number);
  portReadBtn = new QPushButton(text, this);
  portReadBtn->resize(120, 30);
  portReadBtn->move(20, 190);

  /* Internal connections */
  portDirBtnGrp->connect(portDirBtnGrp, SIGNAL(clicked(int)), this, SLOT(portDirBtnGrpClicked(int)));
  portWriteBtnGrp->connect(portWriteBtnGrp, SIGNAL(clicked(int)), this, SLOT(portWriteBtnGrpClicked(int)));
  portReadBtn->connect(portReadBtn, SIGNAL(clicked()), this, SLOT(portReadBtnClicked()));

  /* Init global data */
  _number = number;
  _dir = dir;
  _outByte = outByte;
  _inByte = inByte;

  _device = device;
}


Port::~Port(){}


void Port::portDirBtnGrpClicked(int dir){
  if(dir){
    portWriteBtnGrp->show();
    portReadBtn->hide();
    portInByteLCD->hide();
  }
  else{
    portWriteBtnGrp->hide();
    portReadBtn->show();
    portInByteLCD->show();
  }

  _dir = dir;

  _device->dioConfig(_number, _dir);
}


void Port::portWriteBtnGrpClicked(int id){
  int i;
  QButton *btn;
  int byte = 0;

  for(i = 0; i < 8; i++){
    btn = portWriteBtnGrp->find(i);
    if(btn){
      if(btn->isOn()) byte |= (0x1 << i);
    }
  }
  _outByte = byte;

  _device->dioSetByte(_number, _outByte);
}


void Port::portReadBtnClicked(){
  _device->dioGetByte(_number, &_inByte);
  portInByteLCD->display(_inByte);
}

