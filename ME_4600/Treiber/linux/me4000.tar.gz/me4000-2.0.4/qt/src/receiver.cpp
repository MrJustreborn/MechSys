#include "../include/mytypes.h"
#include "../include/receiver.h"
#include "../include/mydialog.h"


Receiver::Receiver() : QObject() { }


void Receiver::showDialog(){
  MyDialog *dlg = new MyDialog();
  int ret;
  chanListEntry entry;

  ret = dlg->exec();

  if(ret == QDialog::Accepted){
    entry.channel = dlg->getChannel();
    entry.range = dlg->getRange();
    entry.mode = dlg->getMode();
    emit chanLstEntry(entry);
  }
  else{
    return;
  }
}

