/* Custom includes */
#include "../include/xytracewidget.h"


xyTraceWidget::xyTraceWidget(QWidget *parent, const char *name, WFlags f)  : QWidget(parent, name, f) 
{
    QColor backGround(0, 0, 0);
    setBackgroundColor(backGround);
    setFixedSize(301, 301);

    _vPerDiv = 1.0; 
    _sPerDiv = 1.0; 
    _vOffset = 0.0;
    _sOffset = 0.0;
}


xyTraceWidget::xyTraceWidget(measurePointArrayVec &measure,
			     double vPerDiv,
			     double sPerDiv, 
			     double vOffset,
			     double sOffset,
			     QWidget *parent, 
			     const char *name, 
			     WFlags f) : QWidget(parent, name, f) 
{
  QColor backGround(0, 0, 0);
  setBackgroundColor(backGround);
  setFixedSize(301, 301);
  
  _measureGraphVec = measure;
  _vPerDiv = (vPerDiv > 0) ? vPerDiv : 1.0; 
  _sPerDiv = (sPerDiv > 0) ? sPerDiv : 1.0; 
  _vOffset =  vOffset;
  _sOffset = (sOffset >= 0) ? sOffset : 0.0;
  
  calcPaintGraphVec( _measureGraphVec, 
		     _vPerDiv, 
		     _sPerDiv, 
		     _vOffset,
		     _sOffset);
}


xyTraceWidget::~xyTraceWidget(){}


void xyTraceWidget::setMeasureGraphVec(measurePointArrayVec &graphVec){
  _measureGraphVec = graphVec;
  calcPaintGraphVec(_measureGraphVec, 
		    _vPerDiv, 
		    _sPerDiv, 
		    _vOffset,
		    _sOffset);
}


void xyTraceWidget::setvPerDiv(double vPerDiv){

  _vPerDiv = (vPerDiv > 0) ? vPerDiv : 1.0;
  calcPaintGraphVec(_measureGraphVec, 
		    _vPerDiv, 
		    _sPerDiv, 
		    _vOffset,
		    _sOffset);
}


void xyTraceWidget::setsPerDiv(double sPerDiv){

  _sPerDiv = (sPerDiv > 0) ? sPerDiv : 1.0;
  calcPaintGraphVec(_measureGraphVec, 
		    _vPerDiv, 
		    _sPerDiv, 
		    _vOffset,
		    _sOffset);
}


void xyTraceWidget::setvOffset(double vOffset){

  _vOffset = vOffset;
  calcPaintGraphVec(_measureGraphVec, 
		    _vPerDiv, 
		    _sPerDiv, 
		    _vOffset,
		    _sOffset);
}


void xyTraceWidget::setsOffset(double sOffset){

  _sOffset = (sOffset >= 0) ? sOffset : 0;
  calcPaintGraphVec(_measureGraphVec, 
		    _vPerDiv, 
		    _sPerDiv, 
		    _vOffset,
		    _sOffset);
}


void xyTraceWidget::paintEvent(QPaintEvent *event){
  QPainter p(this);

  /* Define a pen */
  QColor penColor(128, 128, 128);
  uint penWidth = 3;
  QPen pen(penColor, penWidth);

  /* Define a brush */
  QColor brushColor(0, 0, 0);
  QBrush brush(brushColor);

  /* Set the proper pen and brush */
  p.setPen(pen);
  p.setBrush(brush);

  /* Prepare Grid */
  p.drawRect(0, 0, 300, 300);
  p.drawLine(150, 0, 150, 300);
  p.drawLine(0, 150, 300, 150);

  pen.setStyle(Qt::DotLine);
  pen.setWidth(1);
  p.setPen(pen);

  p.drawLine(30,  0, 30,  300);
  p.drawLine(60,  0, 60,  300);
  p.drawLine(90,  0, 90,  300);
  p.drawLine(120, 0, 120, 300);
  p.drawLine(180, 0, 180, 300);
  p.drawLine(210, 0, 210, 300);
  p.drawLine(240, 0, 240, 300);
  p.drawLine(270, 0, 270, 300);

  p.drawLine(0, 30,  300, 30);
  p.drawLine(0, 60,  300, 60);
  p.drawLine(0, 90,  300, 90);
  p.drawLine(0, 120, 300, 120);
  p.drawLine(0, 180, 300, 180);
  p.drawLine(0, 210, 300, 210);
  p.drawLine(0, 240, 300, 240);
  p.drawLine(0, 270, 300, 270);

  penColor.setRgb(255, 0, 0);
  pen.setStyle(Qt::SolidLine);
  pen.setWidth(1);
  pen.setColor(penColor);
  p.setPen(pen);

  /* Iterator */
  paintPointArrayVec::iterator itPaintGraphVec;

  for(itPaintGraphVec = _paintGraphVec.begin(); itPaintGraphVec < _paintGraphVec.end(); itPaintGraphVec++){
    p.drawPolyline(*itPaintGraphVec);
  }
}

void xyTraceWidget::paint(){
  QPainter p(this);

  /* Define a pen */
  QColor penColor(128, 128, 128);
  uint penWidth = 3;
  QPen pen(penColor, penWidth);

  /* Define a brush */
  QColor brushColor(0, 0, 0);
  QBrush brush(brushColor);

  /* Set the proper pen and brush */
  p.setPen(pen);
  p.setBrush(brush);

  /* Prepare Grid */
  p.drawRect(0, 0, 301, 301);
  p.drawLine(150, 0, 150, 300);
  p.drawLine(0, 150, 300, 150);

  pen.setStyle(Qt::DotLine);
  pen.setWidth(1);
  p.setPen(pen);

  p.drawLine(30,  0, 30,  300);
  p.drawLine(60,  0, 60,  300);
  p.drawLine(90,  0, 90,  300);
  p.drawLine(120, 0, 120, 300);
  p.drawLine(180, 0, 180, 300);
  p.drawLine(210, 0, 210, 300);
  p.drawLine(240, 0, 240, 300);
  p.drawLine(270, 0, 270, 300);

  p.drawLine(0, 30,  300, 30);
  p.drawLine(0, 60,  300, 60);
  p.drawLine(0, 90,  300, 90);
  p.drawLine(0, 120, 300, 120);
  p.drawLine(0, 180, 300, 180);
  p.drawLine(0, 210, 300, 210);
  p.drawLine(0, 240, 300, 240);
  p.drawLine(0, 270, 300, 270);

  penColor.setRgb(255, 0, 0);
  pen.setStyle(Qt::SolidLine);
  pen.setWidth(1);
  pen.setColor(penColor);
  p.setPen(pen);

  /* Iterator */
  paintPointArrayVec::iterator itPaintGraphVec;

  for(itPaintGraphVec = _paintGraphVec.begin(); itPaintGraphVec < _paintGraphVec.end(); itPaintGraphVec++){
    p.drawPolyline(*itPaintGraphVec);
  }
}

bool xyTraceWidget::calcPaintGraphVec(measurePointArrayVec &measureGraphVec, 
				     double vPerDiv,
				     double sPerDiv,
				     double vOffset, 
				     double sOffset){

  int i, j;
  
  /* Temporary arrays */
  measurePointArrayVec tmpGraphVec;
  measurePointArray tmpGraph;
  measurePoint tmpPoint;

  /* Define Iterators */
  measurePointArrayVec::iterator itGraphVec;
  measurePointArray::iterator itGraph;

  /* Calculate temporary graphs with respect to offsets before transforming to paintable ones */
  for(itGraphVec = measureGraphVec.begin(); itGraphVec < measureGraphVec.end(); itGraphVec++){
    for(itGraph = itGraphVec->begin(); itGraph < itGraphVec->end(); itGraph++){
      if(itGraph->time >= sOffset){
	tmpPoint.time = itGraph->time - sOffset;
	tmpPoint.voltage = itGraph->voltage + vOffset;
	tmpGraph.push_back(tmpPoint);
      }
    }
    tmpGraphVec.push_back(tmpGraph);
    tmpGraph.clear();
  }

  /* Temporary array */
  QPointArray tmpPaintGraph;

  /* Define iterator */
  QPointArray::Iterator itPaintGraph;


  /* We are going to generate a new _paintGraphVec, so clear the old */
  _paintGraphVec.clear();

  /* Transform into coordinate system for painting */
  for(itGraphVec = tmpGraphVec.begin(), i = 0; itGraphVec < tmpGraphVec.end(); itGraphVec++, i++){
    tmpPaintGraph.resize(itGraphVec->size());
    for(itGraph = itGraphVec->begin(), itPaintGraph = tmpPaintGraph.begin(); itGraph < itGraphVec->end(); itGraph++, itPaintGraph++){
      itPaintGraph->setX((int) ((30.0 * itGraph->time) / sPerDiv));
      itPaintGraph->setY(150 - (int) ((30.0 * itGraph->voltage) / vPerDiv));
      if(itPaintGraph->x() > 300){
	itPaintGraph->setX(300);
      }
      else if(itPaintGraph->x() < 0){
	itPaintGraph->setX(0);
      }

      if(itPaintGraph->y() > 300){
	itPaintGraph->setY(300);
      }
      else if(itPaintGraph->y() < 0){
	itPaintGraph->setY(0);
      }
    }
    _paintGraphVec.push_back(tmpPaintGraph.copy());
  }

  paint();
  return true;
}

