#!/bin/bash
#
# This script is responsible for installing a meilhaus linux driver
#
# Version 1.1
#
# Change Log:
#
# 03-11-2003
#	* First release.
#
# 04-06-2004
#	* The MODULNAME now comes without a file suffix.
#	  This is because of 2.4 kernel demand a .o suffix and 2.6 kernels a .ko suffix
#	* Let insserv do the job of init setup
#


if [ -z ${SCRIPTNAME} ] ; then
    SCRIPTNAME=rc.meilhaus
fi

if [ ! -f ${SCRIPTNAME} ] ; then
    echo "Init script ${SCRIPTNAME} is not present"
    exit 1
fi

if [ -z ${MODULENAME} ] ; then
    MODULENAME=meilhaus
fi


RVER=$(uname -r)
if [ ${RVER:0:3} = '2.4' ] ; then
	if [ ! -f ${MODULENAME}.o ] ; then
		echo "Driver module ${MODULENAME}.o is not present"
		exit 1
	fi
elif [ ${RVER:0:3} = '2.6' ] ; then
	if [ ! -f ${MODULENAME}.ko ] ; then
		echo "Driver module ${MODULENAME}.ko is not present"
		exit 1
	fi
fi


if [ -z ${HEADERNAME} ] ; then
    HEADERNAME=meilhaus.h
fi

if [ ! -f ${HEADERNAME} ] ; then
    echo "Header file ${HEADERNAME} is not present"
    exit 1
fi


# Only root is allowed to install a module
if [ $(whoami) != root ]; then
    echo "You must be root to install the device driver!"
    exit 1
fi


# Install the header file
echo "Copy header file ${HEADERNAME} to /usr/include"
cp ${HEADERNAME} /usr/include
	

# Install a copy of the driver in a kernel version independent location
if [ ! -d /lib/modules/misc ]; then
    mkdir -p /lib/modules/misc
fi

RVER=$(uname -r)
if [ ${RVER:0:3} = '2.4' ] ; then
	cp ${MODULENAME}.o /lib/modules/misc
elif [ ${RVER:0:3} = '2.6' ] ; then
	cp ${MODULENAME}.ko /lib/modules/misc
fi


#
# Install a copy of the driver in a kernel version dependent location
#
if [ -f .kver ]; then
    KVER=$(sed -e 's/-SMP//' -e 's/-MOD//' .kver)
    KVERSION=$(cat .kver)
else
    echo "Missing .kver file!  Please rebuild the driver."
    exit 1
fi

if [ -r /proc/kallsyms ]; then
	if grep -q smp_send_stop /proc/kallsyms ; then 
		RSMP='-SMP'
	fi

	if grep -q '____versions' /proc/kallsyms ; then
    		RMOD='-MOD'
	fi
elif [ -r /proc/ksyms ]; then
	if grep -q smp_ /proc/ksyms ; then 
	    RSMP='-SMP'
	fi

	if grep -q 'kfree' /proc/ksyms && ! grep -q 'kfree$' /proc/ksyms ; then
	    RMOD='-MOD'
	fi
fi

RVERSION=$(uname -r)${RMOD}${RSMP}

echo " "
echo "Installing ${SCRIPTNAME:3} driver for Linux ${KVERSION}"
echo " "
if [ ${KVERSION} != ${RVERSION} ]; then
    echo "WARNING: The current kernel is actually version ${RVERSION}."
    echo " "
fi

# Actually install the kernel module
if [ ! -d /lib/modules/${KVER}/misc ]; then 
    mkdir -p /lib/modules/${KVER}/misc
fi

RVER=$(uname -r)
if [ ${RVER:0:3} = '2.4' ] ; then
	cp ${MODULENAME}.o /lib/modules/${KVER}/misc
elif [ ${RVER:0:3} = '2.6' ] ; then
	cp ${MODULENAME}.ko /lib/modules/${KVER}/misc
fi


# Run depmod so that modprobe knows where to find stuff
/sbin/depmod -a


# Install the init script
echo "Copy init script ${SCRIPTNAME} to /etc/init.d/"
cp ${SCRIPTNAME} /etc/init.d/${SCRIPTNAME:3}

# Let do insserv the runlevel setup
echo "Setup runlevel entries"
/sbin/insserv ${SCRIPTNAME:3}

# Create symbolic link
echo "Create symbolic link /usr/sbin/rc${SCRIPTNAME:3} to /etc/init.d/${SCRIPTNAME:3}"
ln -s -f /etc/init.d/${SCRIPTNAME:3} /usr/sbin/rc${SCRIPTNAME:3}
