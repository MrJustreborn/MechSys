#!/bin/bash
#
# This script is responsible for installing a meilhaus library
#

if [ -z ${LIBRARY} ] ; then
    echo "No library to install defined."
    exit 1
fi

if [ -z ${VERSION} ] ; then
    echo "No library version defined."
    exit 1
fi

if [ ! -f ${LIBRARY}.${VERSION} ] ; then
    echo"Library ${LIBRARY}.${VERSION} not in place. Please rebuild it."
    exit 1
fi


if [ -z ${HEADERNAME} ] ; then
    HEADERNAME=lib/meilhaus.h
fi

if [ ! -f lib/${HEADERNAME} ] ; then
    echo "Header file lib/${HEADERNAME} is not present"
    exit 1
fi


LINK_NAME_VER=/usr/lib/${LIBRARY##/*/}.${VERSION:0:1}
LINK_NAME=/usr/lib/${LIBRARY##/*/}


# Only root can do the library installation
if [ $(whoami) != root ] ; then
	echo "You must be root to install the library !"
	exit 1
fi


# Install the header file
echo "Copy header file ${HEADERNAME} to /usr/include"
cp lib/${HEADERNAME} /usr/include


# Remove old links
if [ -f ${LINK_NAME_VER} ] ; then
	echo "Removing old link ${LINK_NAME_VER}"
	rm ${LINK_NAME_VER}
fi

if [ -f ${LINK_NAME} ] ; then
	echo "Removing old link ${LINK_NAME}"
	rm ${LINK_NAME}
fi


# Generate new links
echo "Generate symbolic link ${LINK_NAME_VER} to ${LIBRARY}.${VERSION}"
echo "Generate symbolic link ${LINK_NAME} to ${LIBRARY}.${VERSION}"
ln -s ${LIBRARY}.${VERSION} ${LINK_NAME_VER}
ln -s ${LIBRARY}.${VERSION} ${LINK_NAME}


# Run ldconfig
echo "Run ldconfig on directory /usr/lib"
/sbin/ldconfig /usr/lib
