#!/bin/bash
#
# Check the version of the Linux driver
#
# Version 1.1
#
# Revision History
#
# 03-11-2003
#	* First Release
#
# 29-06-2004
#	* Changes for port to kernel 2.6
#

if [ -z ${LINUX_SRC} ] ; then
    LINUX_SRC=/usr/src/linux
fi

if [ ! -d ${LINUX_SRC} ] ; then
    echo "Kernel source directory ${LINUX_SRC} does not exist"
    exit 1
fi

if [ -z ${NAME} ] ; then
    NAME=Meilhaus
fi

#
# Determine whether SMP is enabled in both the include files and in
# the currently running Kernel
#
# If the .config file exists, then the user likely has compiled a kernel.
# So believe the .config file or the Makefile authoratiatively.  
#
ISMP=''; KSMP=''; 
if test -r ${LINUX_SRC}/.config ; then
    if grep -q CONFIG_SMP=y ${LINUX_SRC}/.config ||
       grep -q "^SMP[:space:]*=[:space:]1" ${LINUX_SRC}/Makefile
    then
	ISMP='-SMP';
    fi
elif grep -q -s smp_ ${LINUX_SRC}/include/linux/modules/ksyms.ver ; then 
	ISMP='-SMP';
elif test -f /boot/kernel.h && 
     grep -q "BOOT_KERNEL_SMP 1" /boot/kernel.h ; then
	ISMP='-SMP';
fi 

if [ -r /proc/kallsyms ]; then
	if grep -q smp_send_stop /proc/kallsyms ; then 
	    KSMP='-SMP'
	fi 
elif [ -r /proc/ksyms ]; then
	if grep -q smp_ /proc/ksyms ; then 
	    KSMP='-SMP'
	fi 
fi


#
# Determine whether MODVERSIONS are enabled in both the includes file 
# and in the currently running Kernel
#
IMOD=''; KMOD='';
if /lib/cpp <<EOF | grep -q "MODVERSIONS ARE ENABLED"
#include "${LINUX_SRC}/include/linux/autoconf.h"
#ifdef CONFIG_MODVERSIONS
    MODVERSIONS ARE ENABLED
#endif
EOF
then 
    IMOD='-MOD'; 
fi 

if [ -r /proc/kallsyms ]; then
	if grep -q '____versions' /proc/kallsyms ; then 
	    KMOD='-MOD'
	fi
elif [ -r /proc/ksyms ]; then
	if grep -q 'kfree' /proc/ksyms &&  ! grep -q 'kfree$' /proc/ksyms ; then 
	    KMOD='-MOD'
	fi
fi


#
# Determine the kernel version for both the includes file and in the
# currently running kernel
#
IVER=$(echo UTS_RELEASE | cat ${LINUX_SRC}/include/linux/version.h - | \
	/lib/cpp | tail -n 1 | tr -d \"\ )${IMOD}${ISMP}
KVER=$(uname -r)${KMOD}${KSMP}

if [ -f .kver ]; then 
    OVER=$(cat .kver); 
    if [ ${OVER} != ${IVER} ]; then 
	echo "Removing previously built driver for Linux ${OVER}"; 
	make clean > /dev/null
	echo " "
    fi 
else 
	make clean > /dev/null
fi

#
# Check whether any of the built modules has unresolved symbols; if so force
# a make clean regardless of kernel version numbers
#
if which depmod >& /dev/null ; then
    for i in ${CHK_OBJS}
    do
    	if test -f ${i} && depmod ${i} | grep -q "unresolved symbol"; then
	    echo "Previously built ${i} has unresolved symbols; forcing rebuild"
	    make clean >& /dev/null
	    echo " "
        fi
    done
fi

echo ${IVER} > .kver
echo Building ${NAME} driver for Linux ${IVER}
echo " " ; 
if [ ${IVER} != ${KVER} ]; then 
    echo "WARNING: The current kernel is actually version ${KVER}." 
    echo " " 
fi
