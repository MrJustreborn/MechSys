/***************************************************************************

------------Plotter mit 2 Schrittmotoren-----------------------------------

	Team:	Marco Beck,
			Florian Bauer,
			Marvin K�ppel,
			Felix Rietsch
			& Christian Kohnert.


***************************************************************************/


//--------------Header-Dateien-----------------------------------------------------------------------------------------------

#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include "..\cbw.h"
#include <string.h>
#include <cstring>
#include <stdlib.h>
#include <iostream>
#include <fstream>
using namespace std;


//--------------Prototypen---------------------------------------------------------------------------------------------------

void ClearScreen (void);
void GetTextCursor (int *x, int *y);
void MoveCursor (int x, int y);
void MotorAnst (int byte_l, int byte_h);
void Start (void);
void Fahre (int x, int y);
void Stift (int z);
void oeffnen();
string lesen();
char *getTeil(int i);
void setTeil(char *a,int i);
void splitstring(string s);
int getPosX();
int getPosY();
void setPosX(int x);
void setPosY(int y);
void setMotorX(double x);
void setMotorY(double y);
double getMotorX();
double getMotorY();
int getSchritteX(int x);
int getSchritteY(int y);
void kreis(int x, int y, int z);


//------------globale Variablen----------------------------------------------------------------------------------------------

int xnow, ynow;														// akutelle Position
int BoardNum = 0;													// Board number = 0; fixer Wert
int PortNum1, PortNum2, Direction1, Direction2;						// Variablen f�r Ausgabe/Eingabe
int Output = 0;														// Output-Variable f�r Motoren
int OutputStift = 0;												// Output-Variable f�r Stift
int Input = 0;														// Input-Variable f�r Taster
int PowerVal, BitValue;												// Variablen zum Einlesen, ob Taster gedr�ckt
WORD DataValue;														// DataValue = Wert des eingelesenen PORTA
int ix=0, iy=0;														// Indexz�hler
int vs[4]={144,160,96,80};											// Vollschritt-Tabelle f�r Motor X auf PIN 4-7 (PORTB)
int hs[8]={9,8,10,2,6,4,5,1};										// Halbschritt-Tabelle f�r Motor Y auf PIN 0-3 (PORTB)
int byte_low, byte_high;											// Low- (Motor Y) & Highbyte (Motor X)
int x_,y_;															// Schrittvariablen
int auflKreis = 3;													// Aufl�sung Kreis in Grad


void main ()
{

//------------Variablen Deklarationen (main) -----------------------------------------------------------------------------------------

    int Row, Col;													// Variablen f�r Konsole
    float    RevLevel = (float)CURRENTREVNUM;						// ...


//-------------Declare UL Revision Levels (main) -------------------------------------------------------------------------------------

   Output = cbDeclareRevision(&RevLevel);										
   Input = cbDeclareRevision(&RevLevel);						
   OutputStift = cbDeclareRevision(&RevLevel);					

//-------------Initiate error handling (main)---------------------------------------------------------------------------------------
   
   cbErrHandling (PRINTALL, DONTSTOP);		

//-------------Vorbereiten der Konsole (main)-----------------------------------------------------------------------------------------	
   
   ClearScreen();													// set up the display screen
    printf ("Start\n\n");											// Print "Start" (Konsole)

    GetTextCursor (&Col, &Row);										// Funktionsaufruf f�r Konsolen Cursor

//-------------Konfigurieren des Inputs/Outputs (main) ---------------------------------------------------------------------------------

    /* Parameters:
            BoardNum    :the number used by CB.CFG to describe this board.
            PortNum1,2  :the input/output port
            Direction   :sets the ports for input or output */

    PortNum1 = FIRSTPORTB;											// PortNum1 = PORTB, OUTPUT (Motoren)
	PortNum2 = FIRSTPORTA;											// PortNum2 = PORTA, INPUT  (Taster)
    Direction1 = DIGITALOUT;										// Direction: OUTPUT
	Direction2 = DIGITALIN;											// Direction: INPUT

    Output = cbDConfigPort (BoardNum, PortNum1, Direction1);		// Cfg Board 0, PORTB f�r OUTPUT (MOTOREN)
	Input = cbDConfigPort (BoardNum, PortNum2, Direction2);			// Cfg Board 0, PORTA f�r INPUT (TASTER)

	MoveCursor (Col, Row + 2);										// Konsole
    MoveCursor (1, 20);												// Konsole 

//-------------Schrittzahlen--------------------------------------------------------------------------------------------------------

	x_=1000;				// Schrittanzahl x zu Ausgangsposition
	y_=0;					// Schrittanzahl y zu Ausgangsposition


//----------------------------------------------------------------------------------------------------------------------------------

	// OutputStift = cbDOut (BoardNum, PortNum2, 0);							// new: Stift heben

		//stift unten


//	Input = cbDConfigPort (BoardNum, PortNum2, Direction2);					// new: config f�r taster

	Start ();	// vor dieser Funktion keine Stift-Fkt.^!!!
	oeffnen();
	string gelesen = lesen();
	while (gelesen.compare("Null") != 0){
		splitstring(gelesen);
		gelesen = lesen();
	}
	return;
	
	/*Fahre (x_,y_);			//Referenzposition
	
	Stift (1);				//Stift senken
	
	
	Fahre (1613,456);		//Das
	Fahre (-1613,0);		//ist
	Fahre (0,-456);			//das
	Fahre (1613,0);			//Haus
	Fahre (0,456);			//vom
	Fahre (-806,304);		//Ni-
	Fahre (-806,-304);		//ko-
	Fahre (1613,-456);		//laus
	
	
	Fahre (1000,0);
	Fahre (0,1000);
	Fahre (-1000,0);
	Fahre (0,-1000);
	
	Stift(0);*/

}																	// main Ende

//------------------------funktionierendes Programm 14.05.14-------------------------------------------------------------------------

fstream myfile;

void oeffnen(){
	char defaultname[100]="beispiel.txt";
	char dateiname[100]="beispiel.txt";
	cout << "Dateiname eingeben oder Enter zum Drucken der Default Datei\n";
	cin.getline(dateiname, 99);			// Datei mit Pfadangabe eingeben
	try{
		if (strlen(dateiname)==0){		// Pr�ft ob Eingabe leer, wenn ja wird die Default Datei ge�ffnet
			myfile.open(defaultname);
		}
		else {
			myfile.open(dateiname);
		}
		if (myfile.is_open())			// Test ob die Datei ge�ffnet wurde
		  {
		    cout << "Datei geoeffnet\n";
		 }
		else {							// Wenn das �ffnen Fehlerhaft war, wird der Benutzer zur erneuten Eingabe aufgeforder
			cout << "Fehlerhafter Dateiname, Bitte neu versuchen\n";
			oeffnen(); 
		}
	}
	catch (fstream::failure e){
		cout << "Fehler beim Dateizugriff\n";
	}
}
string lesen(){
	char line[100];
	if (!myfile.eof()){					// Test ob die Datei zuende ist
		myfile.getline (line,100);		// Liest eine Zeile der Datei
		if (line!="\0"){
			return line;
		}
		else{return "Null";}
	}
	else{return "Null";}
}
char *teil[5];
char *getTeil(int i){
	return teil[i];
}

void setTeil(char *a,int i){
	char **ptrTeil;
	ptrTeil = &teil[0]+i;
	*ptrTeil = a;	
}
void splitstring(string s){
	char stri [100];
	strcpy(stri,s.c_str());
	char delimiter[]=", ";				// Abbruchkriterien f�r Stringende
	char *ptr;
	ptr = strtok(stri,delimiter);		// Zeigt auf den ersten String
	int i =0;
	while (ptr !=NULL){					// Wenn der String Daten enth�lt weiter
		setTeil(ptr,i);
		ptr = strtok(NULL,delimiter);	// Zeigt auf den darauffolgenden String
		i++;
	}
	if(strcmp(getTeil(0),"PU")==0){		
		Stift(0);						// ruft die Funktion f�r Stift hoch auf
	}
	if(strcmp(getTeil(0),"PA")==0){		
		int x = getSchritteX(atoi(getTeil(1)));
		int y = getSchritteY(atoi(getTeil(2)));
		int x1 = x-getPosX();
		int y1 = y-getPosY();
		setPosX(x);
		setPosY(y);
		Sleep(200);
		Fahre(x1,y1);					// ruft die Funktion zum Fahren auf, �bergeben werden x und y in Schritten relativ zum aktuellen Standpunkt			
	}
	if(strcmp(getTeil(0),"CS")==0){
		int x = atoi(getTeil(1));
		int y = atoi(getTeil(2));
		int z = atoi(getTeil(3));
		kreis(x,y,z);					// ruft die Kreisfunktion auf mit den Parametern Mittelpunkt (x-Koordinate,y-Koordinate) und dem zu fahrenden Radius z in 1/10 � 
	}
	if(strcmp(getTeil(0),"PD")==0){
		Stift(1);						// Stift heben
	}
}

double MotorX=0.18787;					// Umrechnung von 1/10mm in Schritte 
double MotorY=0.6565;
int PosX=0;
int PosY=0;
int getPosX(){							// aktuelle Position des Motors in Schritten
	return PosX;
}
int getPosY(){
	return PosY;
}
void setPosX(int x){					// setzt die aktuelle Position des Motors
	int *ptrPosX;
	ptrPosX = &PosX;
	*ptrPosX = x;
}
void setPosY(int y){
	int *ptrPosY;
	ptrPosY = &PosY;
	*ptrPosY = y;
}
void setMotorX(double x){				// Motorumrechnung �ndern
	double *ptrMotor;
	ptrMotor = &MotorX;
	*ptrMotor = x;
}
void setMotorY(double y){
	double *ptrMotor;
	ptrMotor = &MotorY;
	*ptrMotor = y;
}
double getMotorX(){						// Motorumrechnung lesen
	return MotorX;
}
double getMotorY(){
	return MotorY;
}
int getSchritteX(int x){				// Umrechnung von 1/10mm in Schritte
	double ret = x/MotorX;
	return (int)ret;
}
int getSchritteY(int y){
	double ret = y/MotorY;
	return (int)ret;
}

void kreis(int x, int y, int z){
	double radius = sqrt((x-getPosX()*getMotorX())*(x-getPosX()*getMotorX())+(y-getPosY()*getMotorY())*(y-getPosY()*getMotorY()));		// berechnet Radius
	double pi = 3.141592653589793238463;
	double bogenmas = auflKreis*(2*pi)/360;								// schrittweite angegeben im bogenma�, abh�ngig von der in � definierten Schrittweite
	double streckeX = getPosX()*getMotorX()-x;							// Distanz zwischen aktueller Position und Mittelpunkt in x-Richtung
	double streckeY = getPosY()*getMotorY()-y;							// Analog zu oben in y-Richtung
	double rechnebogen=atan2(streckeY,streckeX);						// Berechnet das Bogenmas f�r die aktuelle Position
	int xMitte = getSchritteX(x);										// H�lt den Wert f�r den Mittelpunkt
	int yMitte = getSchritteY(y);
	double x1,y1;
	rechnebogen = rechnebogen + bogenmas;								// Addiert zum aktuellen Standpunkt 1 Schrittweite
	while(z>=0){
		x1 = cos(rechnebogen) ;											// Berechnet die neue Position
		y1 = sin(rechnebogen) ;
		x1 = x1 * radius;
		y1 = y1 * radius;
		x = xMitte + getSchritteX((int)x1);
		y = yMitte + getSchritteY((int)y1);
		rechnebogen = rechnebogen + bogenmas;
		Fahre(x-getPosX(),y-getPosY());
		setPosX(x);
		setPosY(y);
		z-=10*auflKreis;												// Abh�ngig von der definierten Schritteweite
	}

}







void Fahre (int x, int y)
{
	double s, smax, dx, dy;											// Variablen (Z�hlen + Rechnen)
	double diff = 0.0;
	int vz_x=0, vz_y=0;												// Variablen f�r die VZ der Schritte

	if(x < 0)
	{
		x=-x;
		vz_x=1;														//1=negativ, 0=positiv
	}
	if(y < 0)
	{
		y=-y;
		vz_y=1;														//1=negativ, 0=positiv
	}
	do																// do, while
	{	
		if (x>y)													// Falls Schritte in x-Richtung > Schritte in y-Richtung								
		{
			smax = x;												// Maximale Schritte = Schritte in x-Richtung
			dy=y/smax;												// Anteil der y-Schritte pro Schritt in x-Richtung berechnen

			for (s=0.0;s<smax;s++)									// Schleife, hier evtl. noch Wegbegrenzung (Taster & maximale Schritte) einbauen
			{
				byte_high = vs[ix&3];								// Wertzuweisung f�r Motor X �ber VS-Tabelle
				if(vz_x==1)
				{
					ix--;
					xnow--;
				}
				else
				{
					ix++;											// Indexz�hler f�r Motor X inkrementieren
					xnow++;
				}
				diff += dy;											// Z�hler f�r Einsetzen der Schritte in y-Richtung
				byte_low = hs[iy&7];								// Wertzuweisung f�r Motor Y vorerst auf 0 (keine Bewegung) setzen
	

				if (diff>=1)										// Bedingung f�r Schritte in y-Richtung 
				{
					diff -=1;										// Bedingung wieder auf Ausgangszustand setzen
					if(vz_y==1)
					{
						iy--;
						ynow--;
					}
					else
					{
						iy++;										// Indexz�hler f�r Motor X inkrementieren
						ynow++;
					}
					
				}

			MotorAnst (byte_low, byte_high);						// Funktionsaufruf
			}

		}
		else														// Falls Schritte in y-Richtung > Schritte in x-Richtung
		{	
			smax = y;												// Maximale Schritte = Schritte in y-Richtung
			dx=x/smax;												// Anteil der x-Schritte pro Schritt in y-Richtung berechnen
			for (s=0.0;s<smax;s++)									// Schleife ...
			{
				byte_low = hs[iy&7];								// Wertzuweisung f�r Motor Y �ber HS-Tabelle
				if (vz_y==0)
				{
					iy++;											// Indexz�hler f�r Motor Y inkrementieren
					ynow++;
				}
				else 
				{	
					iy--;
					ynow--;
				}
				diff += dx;											// Z�hler f�r Einsetzen der Schritte in x-Richtung
				byte_high = vs[ix&3];								// Wertzuweisung f�r Motor X voerst auf 0 (keine Bewegung) setzen
				if (diff >=1)										// Bedingung f�r Schritte in x-Richtung
				{
					diff -=1;										// Bedingung wieder auf Ausgangszustand setzen
					if (vz_x==0)
					{
						ix++;										// Indexz�hler f�r Motor X inkrementieren
						xnow++;
					}
					else
					{
						ix--;
						xnow--;
					}
				}
				MotorAnst (byte_low, byte_high);				// Motoransteuerung
			}
		}
		//Sleep(300);
	} while (s<smax);
}

void Stift (int z)
{

	if (z==0) OutputStift = cbAOut (BoardNum, 0, BIP5VOLTS, 0x000);				// Stift heben
	else OutputStift = cbAOut (BoardNum, 0, BIP5VOLTS, 0xfff);					// Stift senken
	Sleep (500);
}

void MotorAnst(int byte_l, int byte_h)								// Funktionsaufruf zur Ansteuerung der Motoren �ber ein Byte
{
		int byte;													// Byte-Variable (enth�lt Bitmuster beider Motoren)
		byte = byte_l | byte_h;										// ODER-Verkn�pfung um Low- & HighByte zusammen zu f�hren
		PortNum1 = FIRSTPORTB;										// OUTPUT auf PORTB
		Output = cbDOut(BoardNum, PortNum1, byte);					// Bitmuster-Ausgabe
		Sleep(2);												
		return;
}

void Start (void)													// Startfunktion, f�hrt in Startposition	
{
	int s;
	/*for (s=0;s<1500;s++)												// 500 Schritte nach rechts fahren
	{
		byte_high = vs[ix&3];											
		ix++;
		byte_low = hs[iy&7];
		MotorAnst (byte_low, byte_high);
	}*/ 
	
		OutputStift = cbAOut (BoardNum, 0, BIP5VOLTS, 0x000);			// Stift oben
	do
	{
		
		Input = cbDIn(BoardNum, PortNum2, &DataValue);				// Einlesefunktion Taster
		PowerVal = 2;												// PORTBIT 1 = 2^1 = 2
		if ((DataValue & PowerVal)==2) BitValue = 1;				// Abfragebedingung f�r Taster; Falls ja: Bit = 1
		else BitValue = 0;											// Falls nein, Bit = 0
		byte_high = vs[ix&3];										// Solange nach links zur�ck fahren, bis der Taster gedr�ckt wird...
		ix--;
		byte_low = hs[iy&7];
		MotorAnst (byte_low, byte_high);

	}while (BitValue==0);											// Bedingung

	xnow=0;															// Aktuelle Position = Startpunkt
	ynow=0;
}


//--------------------Funktionen aus Bsp.Programm -------------------------------------------------------------------------------



/***************************************************************************
*
* Name:      ClearScreen
* Arguments: ---
* Returns:   ---
*
* Clears the screen.
*
***************************************************************************/

#define BIOS_VIDEO   0x10



void
ClearScreen (void)
{
	COORD coordOrg = {0, 0};
	DWORD dwWritten = 0;
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	if (INVALID_HANDLE_VALUE != hConsole)
		FillConsoleOutputCharacter(hConsole, ' ', 80 * 50, coordOrg, &dwWritten);

	MoveCursor(0, 0);

    return;
}


/***************************************************************************
*
* Name:      MoveCursor
* Arguments: x,y - screen coordinates of new cursor position
*
* Positions the cursor on screen.
*
***************************************************************************/


void
MoveCursor (int x, int y)
{
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

	if (INVALID_HANDLE_VALUE != hConsole)
	{
		COORD coordCursor;
		coordCursor.X = (short)x;
		coordCursor.Y = (short)y;
		SetConsoleCursorPosition(hConsole, coordCursor);
	}

    return;
}


/***************************************************************************
*
* Name:      GetTextCursor
* Arguments: x,y - screen coordinates of new cursor position
* Returns:   *x and *y
*
* Returns the current (text) cursor position.
*
***************************************************************************/

void
GetTextCursor (int *x, int *y)
{
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO csbi;

	*x = -1;
	*y = -1;
	if (INVALID_HANDLE_VALUE != hConsole)
	{
		GetConsoleScreenBufferInfo(hConsole, &csbi);
		*x = csbi.dwCursorPosition.X;
		*y = csbi.dwCursorPosition.Y;
	}

    return;
}





