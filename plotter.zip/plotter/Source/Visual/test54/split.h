#include "Kreis.cpp"
#include "Motor.cpp"
char *teil[5];
char *getTeil(int i){
	return teil[i];
}

void setTeil(char *a,int i){
	//teil[i]=a;
	char **ptrTeil;
	ptrTeil = &teil[0]+i;
	*ptrTeil = a;	
}
void splitstring(string s){
	char stri [100];
	strcpy(stri,s.c_str());
	char delimiter[]=", ";
	char *ptr;
	ptr = strtok(stri,delimiter);
	int i =0;
	while (ptr !=NULL){
		setTeil(ptr,i);
		ptr = strtok(NULL,delimiter);
		i++;
	}
	if(strcmp(getTeil(0),"PU")==0){
		//PU funktion aufrufen
	}
	if(strcmp(getTeil(0),"PA")==0){
		int x = getSchritteX(atoi(getTeil(1)));
		int y = getSchritteY(atoi(getTeil(2)));
		setPosX(x);
		setPosY(y);
		cout << x << "\t" << y << "\n";
		//PA funktion aufrufen
	}
	if(strcmp(getTeil(0),"CS")==0){
		int x = atoi(getTeil(1));
		int y = atoi(getTeil(2));
		int z = atoi(getTeil(3));
		kreis(x,y,z);
	}
	if(strcmp(getTeil(0),"PD")==0){
		//PD funktion aufrufen
	}
	
	//setMotorX(5);
}



